# Slides — Aula 13: Projeto de Compensadores de Avanço e de Atraso na Frequência

> **Documento do professor.** Formato de cada slide: **Tela** (o que aparece), **Figura** (arquivo em `imagens/`), **Roteiro falado** (o que dizer). Vídeos de apoio à preparação: tópico 3.4, vídeos 01–09 (atenção às erratas dos vídeos 07 e 08 — ver nota de aula). Lab associado: **Lab 13**.

---

### Slide 1 — Abertura

**Tela:** Aula 13: Dobrando o Bode a nosso favor — compensadores de avanço e de atraso de fase.

**Roteiro:** "O ganho puro só desliza o módulo na vertical. Hoje ele ganha companhia: compensadores que sobem a FASE onde precisamos (avanço) ou sobem o GANHO DC sem serem vistos pela dinâmica (atraso). São os mesmos circuitos RC do módulo 2, agora projetados no Bode — sem desenhar um único LGR."

---

### Slide 2 — O efeito de um zero no Bode

**Tela:** Zero em −ωz: +20 dB/déc e até +90° de fase; região de influência: ωz/5 a 5·ωz.

**Figura:** m3_fig24_efeito_zero_bode.png

**Roteiro:** "O zero é o antídoto do polo: devolve 20 dB/déc e 90°. Mas atenção à região de influência: o efeito de fase se espalha de ωz/5 a 5·ωz — duas décadas. Colocou um zero, ele fala numa faixa inteira do Bode."

---

### Slide 3 — O efeito de um polo (e do par)

**Tela:** Polo: −20 dB/déc, −90°; par zero+polo próximos: efeito confinado; ωmáx = √(ωz·ωp) — a média geométrica.

**Figuras:** m3_fig25_efeito_polo_bode.png + m3_fig26_efeito_par_bode.png

**Roteiro:** "Zero sozinho é impróprio — não existe circuito com mais zeros que polos. Então todo compensador é um PAR: zero útil + polo auxiliar. Entre os dois, o zero fala; depois do polo, silêncio. E o pico de fase acontece na média GEOMÉTRICA das frequências — em escala log, no meio do caminho. Decorem essa simetria, ela faz as contas."

---

### Slide 4 — As três fórmulas do avanço

**Tela:** C = K(Ts+1)/(αTs+1); sen φmáx = (1−α)/(1+α); ωmáx = 1/(T√α); K = √α/|G(jωc)|; gráfico φmáx × α.

**Figura:** m3_fig27_avanco_formulas.png

**Roteiro:** "Três fórmulas, três incógnitas. Quanto de fase falta → α. Onde está a nova ωc → T (pico em cima dela). Ganho para cruzar ali → K. E o gráfico mostra o limite: α pequeno demais dá fase mas custa ganho e ruído — na prática, um estágio dá até ~55°. Precisa mais? Dois estágios, como no módulo 2."

---

### Slide 5 — Receita de 6 passos

**Tela:** (1) requisitos → PM alvo e ωc alvo; (2) medir |G| e fase em ωc; (3) φ = PMalvo − PMatual; (4) α e T; (5) K; (6) SIMULAR.

**Roteiro:** "Decorem como checklist de bordo. O passo 3 tem uma pegadinha: a folga de 5 a 10 graus entra na PM ALVO — quem soma folga de novo no φ está com folga em dobro. E o passo 6 não é opcional: a trilha PM ≈ 100ζ é aproximada; a simulação é a sentença."

---

### Slide 6 — Exemplo-âncora de avanço

**Tela:** G = 0,005/[s(s+0,05)]: PM atual 23° em ωc = 0,11; φ = 17°; α = 0,54; T = 12; K = 2,1 → C = 2,1(12s+1)/(6,5s+1); simulação: Mp = 29,6 %, tr = 15,5 s.

**Figura:** m3_fig28_projeto_avanco.png

**Roteiro:** "Planta lenta de antena: queremos o triplo da velocidade sem estourar 30 % de overshoot. As contas no quadro — e a simulação fecha nos requisitos. Reparem o zero do compensador em −0,083: ele CANCELA quase o polo da planta em −0,05... não é coincidência nem exigência: é a geometria da ωc escolhida."

---

### Slide 7 — Atraso de fase: o erro estacionário some

**Tela:** G = 10/[(s+1)(s+2)]: ess = 16,7 %; par z/p = 2,2 com p = −ωc/10 = −0,27, z = −0,61; ess → 8,3 %; Mp 22,1 % → 22,7 %.

**Figura:** m3_fig29_projeto_atraso.png

**Roteiro:** "O atraso é um cavalo de Troia: um par polo/zero colado na origem. Em ωc, uma década acima, o par se CANCELA — dinâmica intacta. Em DC, vale z/p — o erro despenca. Preço: uma cauda lenta, de constante ≈ 1/|p|. É o PI disfarçado: polo quase em cima do zero, em vez de exatamente no zero."

---

### Slide 8 — Avanço + atraso: três requisitos

**Tela:** G = 1/[(s+5)(s+10)]: ωc = 27, |G| = −58,0 dB, φ = 33°; C1 = 420(0,07s+1)/(0,021s+1); C2 = (s+0,28)/(s+0,14); simulação: Mp = 7,4 %, tr = 0,075 s, ess = 0,06.

**Figura:** m3_fig30_projeto_avanco_atraso.png

**Roteiro:** "Projeto completo: o avanço entrega PM 60° na banda nova, 27 rad/s; o atraso dobra o ganho DC com polo em ωc/200 — tão longe que nem a folga de 5° sente. Resultado: os três requisitos batidos com folga. Anotem a divisão de trabalho: avanço cuida da DINÂMICA, atraso cuida do REGIME."

---

### Slide 9 — Síntese na carta de Nichols-Black

**Tela:** Três curvas na carta: G, G·Cavanço, G·Cavanço·Catraso; o avanço afasta a curva de −180°; o atraso levanta o pé.

**Figura:** m3_fig31_avanco_atraso_nb.png

**Roteiro:** "Olhem a anatomia do projeto na carta: o avanço empurra a região de cruzamento para a DIREITA, longe de −180° — é PM sendo comprada. O atraso levanta a parte BAIXA da curva, em alta fase e baixo módulo — é ganho DC. Cada compensador esculpe uma região diferente da curva. Lindo, não?"

---

### Slide 10 — Encerramento e ponte

**Tela:** Checklist: efeito de zero/polo ✓; 3 fórmulas do avanço ✓; receita de 6 passos ✓; atraso = PI disfarçado ✓; síntese na carta ✓. Próxima aula: PD, PI e PID na frequência.

**Roteiro:** "Vocês agora têm o projeto na frequência completo para compensadores de 1 estágio. Na última aula do módulo, a versão industrial: PD pelas fórmulas diretas, PI, e o PID como produto dos dois — inclusive quanto custa no atuador. Lab 13 aberto."
