# Slides — Aula 10: Resposta em Frequência e Diagrama de Bode

> **Documento do professor.** Formato de cada slide: **Tela** (o que aparece), **Figura** (arquivo em `imagens/`), **Roteiro falado** (o que dizer). Vídeos de apoio à preparação: tópico 3.1, vídeos 01–11. Lab associado: **Lab 10**.

---

### Slide 1 — Abertura

**Tela:** Módulo 03 · Aula 10: E se você não tiver o modelo? — Resposta em frequência.

**Roteiro:** "Módulos 1 e 2 partiam de uma premissa confortável: conhecemos a função de transferência. Na prática, muitas vezes NÃO conhecemos — mas podemos ligar um gerador de senoides na entrada e medir a saída. O módulo 3 inteiro nasce dessa pergunta: dá para projetar controlador medindo, sem modelar? Spoiler: dá, e é assim que a indústria trabalha."

---

### Slide 2 — O desafio sem modelo

**Tela:** Caixa-preta + gerador de senoides + osciloscópio; pergunta: "quanto vale G(jω)?"

**Roteiro:** "Entra senoide de amplitude A e frequência ω. O que sai? SEMPRE uma senoide de mesma frequência — depois do transitório. Só mudam duas coisas: amplitude e fase. Essas duas medidas SÃO o sistema naquela frequência."

---

### Slide 3 — O teorema da resposta em frequência

**Tela:** y_rp(t) = A·|G(jω)|·sen(ωt + ∠G(jω)); circuito RC: τ = 0,1034 s; tabela ω = 1, 10, 100.

**Figura:** m3_fig01_resposta_frequencia.png

**Roteiro:** "Olhem a tabela: ω = 1 rad/s passa quase inteiro (0,995, −6°); ω = 10 já corta (0,695, −46°); ω = 100 quase morre (0,096, −84°). O RC é um filtro — e a tabela inteira é UMA função de variável complexa: G(jω). No lab 10 vocês medem isso na simulação, com exatamente esses números."

---

### Slide 4 — Convenções do curso

**Tela:** dB = 20·log10|G|; fase em graus; eixo ω em escala log (décadas); esboço assintótico: quebras ±20 dB/déc; fase por retas de ωq/5 a 5·ωq.

**Roteiro:** "Três convenções para nunca mais confundir: módulo em dB é 20 log — NÃO 10 log (é amplitude, não potência). Eixo de frequência logarítmico: distâncias iguais = razões iguais. E a fase assintótica do curso: reta que começa em ωq/5 e termina em 5·ωq — erro máximo de 11 graus, nas pontas."

---

### Slide 5 — Bode de 1ª ordem: exato × assintótico

**Tela:** G = 1/(0,1034s+1): assíntotas 0 dB e −20 dB/déc; erro de 3 dB na quebra; fase exata × reta.

**Figura:** m3_fig02_bode_1a_ordem.png

**Roteiro:** "Dois erros para decorar: na quebra, o exato está 3 dB ABAIXO da assíntota — sempre 3 dB, qualquer polo real. Na fase, a reta erra no máximo 11°. Projeto de verdade usa a curva exata; o esboço é para entender e estimar — e é o que cai na prova."

---

### Slide 6 — Somando contribuições: dois polos

**Tela:** G = 100/[(s+1)(s+100)]: 40 dB de patamar; quebras em 1 e 100; declives −20, depois −40 dB/déc.

**Figura:** m3_fig03_bode_2a_polos_reais.png

**Roteiro:** "Em escala log, multiplicar funções vira SOMAR gráficos. Cada polo: −20 dB/déc e −90°. Dois polos: −40 dB/déc e −180° no final. Pergunta de prova: quanto vale o declive final com 4 polos e 1 zero? Menos 60 — cada zero devolve 20."

---

### Slide 7 — Sistema tipo 1: o integrador

**Tela:** G = 10/[s(s+2)]: sem patamar, declive −20 desde o início; fase começa em −90°.

**Figura:** m3_fig04_bode_tipo1.png

**Roteiro:** "Polo na origem = integrador: já nasce caindo −20 dB/déc e com −90° de fase. Guardem: o TIPO do sistema se lê no início do Bode — patamar plano é tipo 0, −20 é tipo 1, −40 é tipo 2. E o tipo manda no erro estacionário — módulo 1."

---

### Slide 8 — Margens de ganho e de fase

**Tela:** G = 0,95/[s(s+1)(s+5)]: ωc = 0,187 → PM = 77,3°; ωf = 2,23 → GM = 30,0 dB; e com K = 5: PM cai para 44,5°.

**Figura:** m3_fig05_margens_bode.png

**Roteiro:** "As duas distâncias que salvam projetos: PM = quanto falta de fase para −180° na frequência de cruzamento de ganho; GM = quanto de ganho posso adicionar antes de cruzar 0 dB na frequência de −180°. Ganho só move a curva de módulo na vertical — vejam como K = 5 engole 14 dB da GM e 33° da PM."

---

### Slide 9 — PM ↔ ζ: a ponte para o tempo

**Tela:** PM ≈ 100·ζ (ξ ≤ 0,65); gráfico PM × ζ; exemplos: PM 45° → Mp ≈ 22 %; PM 60° → Mp ≈ 9 %.

**Figura:** m3_fig06_pm_x_zeta.png

**Roteiro:** "Esta é a ponte do módulo: requisito é dado no tempo (Mp), projeto acontece na frequência (PM). PM dividido por 100 é ζ — regra prática, boa até ξ = 0,65. Complemento: ωn ≈ ωc — a frequência de cruzamento estima a velocidade."

---

### Slide 10 — Projeto de P pela PM

**Tela:** G = 10/[s(s+2)]: fase = −135° em ω = 2; |G(j2)| = 1,77 (4,95 dB); K = 0,56 → Mp = 23,3 %.

**Figura:** m3_fig07_projeto_P_pm.png

**Roteiro:** "A receita completa em três passos: requisito vira PM alvo; acha-se onde a fase dá essa PM — essa é a nova ωc; mede-se quanto de ganho falta e aplica-se K. No exemplo: K = 1/1,77 = 0,56, e a simulação entrega 23,3 % de overshoot — como previsto pela ponte."

---

### Slide 11 — Encerramento e ponte

**Tela:** Checklist: teorema da resposta em frequência ✓; Bode exato × assintótico ✓; margens ✓; PM ≈ 100ζ ✓; projeto de P ✓. Próxima aula: a carta de Nichols-Black.

**Roteiro:** "Hoje vocês viram que a resposta em frequência caracteriza o sistema inteiro — e que o ganho puro já projeta, deslizando o módulo. Semana que vem: um gráfico que mostra a malha FECHADA sem calcular a malha fechada — a carta de Nichols-Black — e com ela, especificações de pico de ressonância. Lab 10 está aberto."
