# Slides — Aula 14: PD, PI e PID na Frequência

> **Documento do professor.** Formato de cada slide: **Tela** (o que aparece), **Figura** (arquivo em `imagens/`), **Roteiro falado** (o que dizer). Vídeos de apoio à preparação: tópico 3.5, vídeos 01–06 (atenção às erratas dos vídeos 02 e 04 — ver nota de aula). Lab associado: **Lab 14**.

---

### Slide 1 — Abertura

**Tela:** Aula 14: O PID na frequência — as fórmulas diretas, o sinal de controle e a síntese final.

**Roteiro:** "Última aula do módulo. O PID é 90 % dos controladores da indústria — e vocês já viram ele montado por peças: o avanço é quase um PD, o atraso é quase um PI. Hoje: as fórmulas DIRETAS de kp e kd, o preço que o derivativo cobra no atuador, e o PID completo como produto de dois projetos que vocês já sabem fazer."

---

### Slide 2 — PD: as fórmulas diretas

**Tela:** PD ideal kp + kd·s: em ωc, módulo 1/|G| e fase +φ → kp = cos φ/|G(jωc)|, kd = sen φ/(ωc·|G(jωc)|); polo de filtragem em 100·ωc (−0,6°).

**Figura:** m3_fig32_pd_bode.png

**Roteiro:** "Em vez de α e T, o PD sai direto: queremos que em ωc o compensador tenha fase +φ e módulo que feche 0 dB. Dois números, duas equações, kp e kd na hora. Detalhe de engenharia: kd·s puro é impróprio — entra um polo de filtragem em 100 vezes ωc, que custa só 0,6° de fase. Toda implementação de derivativo tem esse polo: sem ele, o ruído de medição vira samba no atuador."

---

### Slide 3 — PD × avanço: mesma saída, controle MUITO diferente

**Tela:** G = 0,005/[s(s+0,05)]: PD (kp = 2,7, kd = 7,6, polo −110) × avanço (2,1(12s+1)/(6,5s+1)); saídas quase idênticas (Mp ≈ 30 %, tr ≈ 15 s); picos de controle: 836 × 3,9 — razão ≈ 215×.

**Figura:** m3_fig33_pd_x_avanco.png

**Roteiro:** "Experimento mental: dois controladores, MESMA especificação, mesma planta, saídas indistinguíveis. Agora olhem o sinal de controle: o PD dá um pico de 836, o avanço de 3,9 — DUZENTAS e quinze vezes mais. Por quê? O derivativo enxerga a quina do degrau como derivada infinita. Moral: PD teórico bonito pode ser inviável no atuador real — saturação. E saturar é sair do mundo linear: o módulo 4 começa exatamente aí."

---

### Slide 4 — PI: o atraso com polo NO zero

**Tela:** PI: C = (s+z1)/s; fase em ωc: −90°+arctg(ωc/z1) ≈ −5,7° para z1 = ωc/10; malha vira tipo 1; ess → 0; cauda lenta ≈ e^(−z1·t).

**Figura:** m3_fig34_pi_bode.png

**Roteiro:** "O PI é o atraso de fase com o polo cravado NO zero — integrador de verdade: erro estacionário zera de vez, não só melhora. O preço é o mesmo em dobro: além dos ~6° de PM, a cauda lenta agora é EXATA: o modo e^(−z1·t) arrasta a convergência final. Quem quer erro zero paga com paciência."

---

### Slide 5 — PID = PD × PI

**Tela:** Receita: PD cuida de PM e ωc (dinâmica); PI cuida de ess (regime); folga na PM alvo paga a PI; PID é o produto.

**Roteiro:** "A receita do PID é literalmente a soma das duas receitas: projete o PD para a dinâmica COM FOLGA de 5 a 10 graus na PM — é o dinheiro que paga a PI; pendure a PI com zero uma década abaixo de ωc; multiplique. A PI rouba seus 6 graus, a folga cobre, e os três requisitos saem juntos."

---

### Slide 6 — Exemplo-âncora de PID

**Tela:** G = 0,01/[(s+0,05)(s+0,07)]: ωc = 0,18; |G| = −11,2 dB; fase −143,2°; φ = 28°; kp = 3,2; kd = 9,5; polo −180; z1 = −0,018; simulação: Mp = 11,2 %, tr = 11,1 s, ess = 0.

**Figura:** m3_fig35_projeto_pid.png

**Roteiro:** "Projeto-âncora completo: PM atual 37°, alvo 65° — os 15° acima dos 50° do requisito são a folga que paga PI e polo de filtragem. Resultado na simulação: 11 % de overshoot, subida em 11 s, erro zero. Três requisitos, três verificações, um controlador — o produto de dois estágios que vocês projetaram separadamente."

---

### Slide 7 — Síntese: os três na carta

**Tela:** Carta de Nichols-Black com G, PD·G, PI·G, PID·G; leitura das regiões de atuação.

**Figura:** m3_fig36_pd_pi_pid_nb.png

**Roteiro:** "O retrato de família do módulo: o PD esculpe a região de ωc — afasta a curva de −180°, compra PM. O PI levanta o pé da curva lá embaixo — ganho infinito em DC, erro zero. O PID herda os dois gestos. Se vocês souberem LER essa figura, sabem projeto na frequência."

---

### Slide 8 — Mapa do módulo 3

**Tela:** Tabela: ferramenta × pergunta que responde — Bode (forma e margens), Nichols-Black (malha fechada), Nyquist (estabilidade e atraso), avanço/PD (dinâmica), atraso/PI (regime), PID (tudo).

**Roteiro:** "Recapitulem o arsenal: três ferramentas de ANÁLISE — Bode, carta, Nyquist — e três de SÍNTESE — avanço, atraso, PID. E as pontes que ligam os dois mundos: PM ≈ 100ζ, Mr ↔ ξ, ωc ↔ velocidade. Com isso vocês projetam sem modelo, sem LGR, medindo."

---

### Slide 9 — O que vem aí

**Tela:** Módulo 04 — Não linearidades: saturação, zona morta, histerese, relé; função descritiva; o ciclo limite; onde o mundo linear acaba.

**Roteiro:** "Lembrem do pico de 836 do PD: no atuador real, ele SATURA — e aí tudo que fizemos até aqui deixa de valer literalmente. O módulo 4 começa onde o linear acaba: o que acontece com saturação, zona morta e relé na malha? A ferramenta é a função descritiva — e o fenômeno novo é o ciclo limite: oscilação que não é estável nem instável. Tragam as dúvidas do lab 14 que a gente fecha o módulo."

---

### Slide 10 — Encerramento

**Tela:** Checklist: fórmulas do PD ✓; custo no atuador ✓; PI e cauda lenta ✓; PID = PD × PI ✓; síntese na carta ✓. Lab 14 + lista 3.

**Roteiro:** "Módulo 3 completo: da senoide no osciloscópio ao PID de três requisitos. Lab 14 aberto — vocês reproduzem TODOS os exemplos-âncora no Python, inclusive o pico de controle de 836. A lista 3 fecha a unidade, com gabarito comentado. Boa semana de provas!"
