# Slides — Aula 11: Carta de Nichols-Black e Especificação na Frequência

> **Documento do professor.** Formato de cada slide: **Tela** (o que aparece), **Figura** (arquivo em `imagens/`), **Roteiro falado** (o que dizer). Vídeos de apoio à preparação: tópico 3.2, vídeos 01–08 (atenção às erratas dos vídeos 04 e 08 — ver nota de aula). Lab associado: **Lab 11**.

---

### Slide 1 — Abertura

**Tela:** Aula 11: E a malha FECHADA, na frequência? — Pico de ressonância e a carta de Nichols-Black.

**Roteiro:** "Até aqui projetamos olhando a malha ABERTA. Mas quem o usuário vê é a malha fechada. Pergunta do dia: dá para ler o comportamento de G/(1+G) direto do gráfico de G, sem calcular a divisão? Dá — e a ferramenta tem 80 anos e continua pendurada nas paredes de empresas aeroespaciais."

---

### Slide 2 — Pico de ressonância

**Tela:** Sistema subamortecido: |T(jω)| com pico Mr em ωr; família de curvas para vários ξ; Mr = 1/(2ξ√(1−ξ²)); ωr = ωn√(1−2ξ²).

**Figura:** m3_fig08_bode_subamortecido.png

**Roteiro:** "Sistema com ξ pequeno 'grita' perto de ωn: senoide nessa frequência sai AMPLIFICADA. Pico Mr e frequência ωr têm fórmula exata para 2ª ordem — e existem só para ξ < 0,707. ξ = 0,2: pico de 8 dB, 2,5 vezes. Mediu o pico no analisador de espectro? Você mediu ξ."

---

### Slide 3 — O problema geométrico

**Tela:** Plano complexo: vetores G e 1+G; |T| = |G|/|1+G|; o ponto −1 como origem da distância.

**Roteiro:** "T = G/(1+G). No plano complexo, 1+G é o vetor que vai do ponto −1 até o ponto G(jω). Então |T| é uma RAZÃO DE DISTÂNCIAS: distância da origem dividida pela distância até −1. Toda a carta de Nichols-Black é essa geometria pré-computada."

---

### Slide 4 — A carta de Nichols-Black

**Tela:** Eixos: fase de malha aberta (graus) × módulo de malha aberta (dB); grade curva: linhas de |T| e ∠T constantes; ponto crítico (−180°, 0 dB).

**Figura:** m3_fig09_carta_nb.png

**Roteiro:** "Estrutura da carta: eixos retos são a malha ABERTA — fase na horizontal, módulo em dB na vertical. A grade encurvada é a malha FECHADA — cada curva é um valor constante de |T| ou de fase de T. Plote G, leia T. E o centro do furacão: (−180°, 0 dB) — o ponto −1 disfarçado."

---

### Slide 5 — Ajuste de ganho = translação vertical

**Tela:** Curva de G e curva de 10·G na carta: mesma forma, deslocada 20 dB para cima; muda-se a curva de |T| tangenciada.

**Figura:** m3_fig10_nb_ajuste_ganho.png

**Roteiro:** "Na carta, ganho vira translação vertical pura — a fase não se move. Isso torna o projeto de ganho VISUAL: deslize a curva até ela tangenciar a curva de Mr desejada, ou cruzar 0 dB na coluna da PM desejada. É a mesma receita da aula 10, agora com a malha fechada desenhada no fundo."

---

### Slide 6 — Leitura completa: Mr, ωr e o degrau

**Tela:** G = 2,4/[s(s+1,2)]: tangência em Mr = 3 dB; ωr ≈ ωc ≈ 1,3; ξ ≈ 0,38 → degrau com Mp = 26,7 %, tr = 1,38 s.

**Figura:** m3_fig11_nb_mr_wc.png

**Roteiro:** "Exemplo completo, ponta a ponta: curva tangencia 3 dB → Mr = 3 dB → fórmula invertida dá ξ = 0,38 → previsão de 27 % de overshoot → simulação: 26,7 %. A trilha frequência-tempo fecha perfeitamente — quando a 2ª ordem domina."

---

### Slide 7 — As relações valem sem integrador? E com 3 polos?

**Tela:** Tipo 0: G = 3/[(s+0,02)(s+1)]: PM = 33° → previsto ≈ 33 %, simulado 38,1 %. 3ª ordem: G = 60/[(s+0,02)(s+1)(s+15)]: PM = 22° → previsto ≈ 49 %, simulado 54,5 %.

**Figura:** m3_fig12_extensao_relacoes.png

**Roteiro:** "Honestidade numérica: PM ≈ 100ζ nasceu de 2ª ordem com integrador. Sem integrador: erra alguns pontos. Com 3 polos: erra alguns pontos. Erros de 5 % em Mp — aceitáveis para PROJETO, desde que você confirme por simulação no final. É o preço e a utilidade das aproximações."

---

### Slide 8 — Projeto com especificação de Mp

**Tela:** Planta de 3ª ordem: fase = −135° em ω = 0,9; |G| = −9,9 dB → K = 0,32; simulação: Mp = 24,4 %, tr = 2,0 s.

**Figura:** m3_fig13_projeto_3a_mp.png

**Roteiro:** "Mesma receita do P, agora numa planta de 3ª ordem — e aqui o ganho teve que DIMINUIR (−9,9 dB, K = 0,32). Nem todo projeto é 'aumentar ganho': às vezes a PM manda reduzir. A velocidade cai junto — tr de 2 segundos. Tudo é troca."

---

### Slide 9 — Projeto com especificação de velocidade (tp)

**Tela:** G = 0,005/[(s+0,03)(s+0,1)(s+0,5)]: K = 2,3 (+7,3 dB em ω = 0,13) → Mp = 40,8 %, tp = 23,1 s; com K = 1: 17,8 % / 34,2 s; limite do ganho puro.

**Figura:** m3_fig14_projeto_wn.png

**Roteiro:** "Requisito duplo: rápido E macio. O ganho puro acelera (tp cai de 34 para 23 s) mas cobra em overshoot (sobe de 18 para 41 %). Se os dois requisitos forem apertados juntos — o ganho puro NÃO resolve. É a demonstração por contra-exemplo de que precisamos de compensadores com forma: aulas 13 e 14."

---

### Slide 10 — Encerramento e ponte

**Tela:** Checklist: Mr e ωr ✓; carta NB ✓; translação vertical ✓; extensão das relações ✓; limites do ganho puro ✓. Próxima aula: Nyquist e atraso de transporte.

**Roteiro:** "A carta fecha a questão 'malha fechada na frequência'. Falta uma pergunta mais fundamental: COMO GARANTIR estabilidade olhando a resposta em frequência — inclusive com planta instável ou com atraso? É o critério de Nyquist, semana que vem. Lab 11 aberto: vocês montam a carta no Python e projetam nela."
