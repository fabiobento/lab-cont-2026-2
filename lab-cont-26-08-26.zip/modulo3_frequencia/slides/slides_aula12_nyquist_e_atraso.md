# Slides — Aula 12: Critério de Nyquist e Atraso de Transporte

> **Documento do professor.** Formato de cada slide: **Tela** (o que aparece), **Figura** (arquivo em `imagens/`), **Roteiro falado** (o que dizer). Vídeos de apoio à preparação: tópico 3.3, vídeos 01–09 (atenção às erratas dos vídeos 03 e 05 — ver nota de aula). Lab associado: **Lab 12**.

---

### Slide 1 — Abertura

**Tela:** Aula 12: Estabilidade lida no gráfico — o critério de Nyquist; e o vilão silencioso: o atraso de transporte.

**Roteiro:** "Routh precisa do polinômio. O LGR precisa da função de transferência. Nyquist precisa só de... medições. E funciona nos dois casos em que os outros tropeçam: planta instável em malha aberta e sistema com atraso. É o critério mais poderoso do curso — e o mais geométrico."

---

### Slide 2 — Gráfico polar

**Tela:** G = 10/[(s+1)(s+10)]: pontos ω = 0, 1, 10, ∞; começa em (0,91; 0°), morre na origem a −180°.

**Figura:** m3_fig15_polar.png

**Roteiro:** "O polar é o Bode desenhado de outro jeito: cada ponto é G(jω) em coordenadas polares, e ω vira um parâmetro ao longo da curva. Começa no ganho DC, enrola conforme a fase cai, morre na origem. Decorem: cada ponto do polar É um ponto do Bode."

---

### Slide 3 — O princípio do argumento

**Tela:** Contorno no plano-s → contorno no plano-G; N = Z − P; exemplo: 1 zero e 1 polo dentro → N = 0... caso 2 zeros e 1 polo → 1 volta horária.

**Figura:** m3_fig16_principio_argumento.png

**Roteiro:** "Cauchy, 1825: quando s percorre um contorno fechado, G(s) dá voltas em torno da origem — e a contagem é ZERO MENOS POLOS dentro do contorno. Voltas horárias = zeros excedentes. Toda a estabilidade de malha fechada é uma aplicação dessa contagem."

---

### Slide 4 — O contorno de Nyquist e a indentação

**Tela:** Semicircunferência infinita cobrindo o SPD; desvio (indentação) em torno de polos na origem; ponto crítico −1.

**Figura:** m3_fig17_contorno_nyquist.png

**Roteiro:** "Queremos contar polos de malha FECHADA no SPD: contorno = todo o semiplano direito. Polo na origem? Ele não é 'dentro' nem 'fora' — contornamos por fora com um semicírculo infinitesimal: a indentação. E as voltas contam em torno de −1, não da origem, porque o denominador é 1+G."

---

### Slide 5 — Nyquist completo

**Tela:** Ramo ω > 0 + espelho ω < 0 + fechamento pelo infinito; contagem de voltas em −1: Z = N + P.

**Figura:** m3_fig18_nyquist_completo.png

**Roteiro:** "Três pedaços: o polar de ω positivo, o espelho de ω negativo, e o fechamento — que para sistemas próprios é um ponto na origem. A fórmula Z = N + P: polos instáveis de malha fechada = voltas horárias em −1 + polos instáveis de malha aberta. Estável exige Z = 0."

---

### Slide 6 — Três vereditos

**Tela:** Painéis: 1/(s−1) com K: estável só para K > 1 (P = 1, precisa N = −1); 1/[s(s+1)(s+2)]: estável para K < 6; leitura da GM no cruzamento.

**Figura:** m3_fig19_nyquist_estabilidade.png

**Roteiro:** "Olhem o primeiro painel: planta INSTÁVEL em malha aberta, estabilizada pela malha fechada — a curva PRECISA dar uma volta anti-horária. Segundo: o cruzamento em −1/6 diz que K = 6 é o limite — e Routh confirma: s³+3s²+2s+K, K < 6. Nyquist e Routh SEMPRE concordam — um verifica o outro."

---

### Slide 7 — A margem INFERIOR de ganho

**Tela:** G = (s+2)/[(s+1)(s−5)]: cruzamento em −0,25K na frequência ω = √3; estável para K > 4; intuição invertida.

**Figura:** m3_fig20_nyquist_margem_inferior.png

**Roteiro:** "Aqui a intuição vira do avesso: ganho BAIXO desestabiliza; precisa K MAIOR que 4. Faz sentido? A planta sozinha diverge (polo em +5) — só uma realimentação forte o suficiente doma o polo. Routh confirma: s²+(K−4)s+(2K−5). Guardem a expressão 'margem inferior': existe, e aparece em prova."

---

### Slide 8 — Atraso de transporte no Bode

**Tela:** e^(−δs): módulo 1, fase −δω; G = 4/[(s+0,1)(s+1)]e^(−0,2s): PM 31,1° → 9,6°; perda = δ·ωc = 0,38 rad ≈ 22°.

**Figura:** m3_fig21_atraso_bode.png

**Roteiro:** "O atraso é o vilão perfeito: NÃO aparece no gráfico de módulo — módulo 1, sempre. Mas a fase escorre −δω, sem limite. Custo na margem de fase: δ vezes ωc, em radianos. Quanto mais rápido o sistema, MAIS o mesmo atraso custa. Controle digital: amostragem insere ≈ Ts/2 de atraso médio — é por isso que não dá para fechar malha rápida demais com Ts grande."

---

### Slide 9 — A espiral de Nyquist e o degrau

**Tela:** Nyquist com atraso: espiral infinita em torno da origem; degrau (Padé 8): Mp 41,2 % → 79 %; tr 0,95 → 1,04 s.

**Figuras:** m3_fig22_atraso_nyquist.png + m3_fig23_atraso_degrau.png

**Roteiro:** "Como a fase cai sem limite e o módulo demora a morrer, a curva enrola numa espiral infinita — cruza o eixo real infinitas vezes: múltiplas margens, cuidado com qual contar. E o efeito no tempo: o overshoot quase DUPLICA. Atraso de 0,2 s numa malha de banda 1,9 rad/s: 22 graus de PM evaporaram. No lab 12 vocês reproduzem esses números com aproximação de Padé."

---

### Slide 10 — Encerramento e ponte

**Tela:** Checklist: polar ✓; princípio do argumento ✓; Z = N + P ✓; margem inferior ✓; custo do atraso ✓. Próxima aula: compensadores de avanço e atraso na frequência.

**Roteiro:** "Fechamos o tripé de análise na frequência: Bode, Nichols, Nyquist. Agora vem a parte de síntese: até aqui, só ganho puro — e vimos os limites dele. Semana que vem, compensadores que DOBRAM o Bode a nosso favor: avanço e atraso de fase. Lab 12 aberto."
