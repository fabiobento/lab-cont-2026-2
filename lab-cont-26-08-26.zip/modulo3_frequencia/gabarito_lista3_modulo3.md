# Gabarito — Lista 3 (Módulo 03)

> **Documento do professor** — divulgar aos alunos somente após o prazo de entrega.
> Resolução detalhada, passo a passo, com referências ao local da teoria para consulta (`teoria_modulo3.md`). Valores de simulação conferidos numericamente (python-control 0.10.2).

---

## Questão 1 — Resposta em frequência

**Consulte:** teoria §3.1.3 (o teorema da resposta em frequência) e §3.1.2 (transitório × regime); Exercício 3.1.1 dos exercícios resolvidos.

**a)** O teorema garante: $y_{rp}(t) = A|G(j\omega)|\mathrm{sen}\big(\omega t + \angle G(j\omega)\big)$, com $A = 4$, $\omega = 2$ rad/s.
1. $|G(j2)| = \dfrac{12}{\sqrt{2^2+3^2}} = \dfrac{12}{\sqrt{13}} = 3{,}33$;
2. $\angle G(j2) = -\mathrm{arctg}(2/3) = -33{,}7°$;
3. $\boxed{y_{rp}(t) = 4 \times 3{,}33\mathrm{sen}(2t - 33{,}7°) = 13{,}3\mathrm{sen}(2t - 33{,}7°)}$

**b)** A expressão só vale **em regime**: a constante de tempo é $\tau = 1/3$ s → o transitório morre em $\approx 4\tau = 1{,}3$ s. Antes disso, a saída é a soma da senoide de regime com o termo transiente $Ce^{-t/\tau}$.

**c)** Para $\omega = 30$ rad/s: $|G(j30)| = \dfrac{12}{\sqrt{909}} = 0{,}398$; $\angle G(j30) = -\mathrm{arctg}(10) = -84{,}3°$ → $y_{rp}(t) = 1{,}59\mathrm{sen}(30t - 84{,}3°)$.
**Mudou:** a amplitude (caiu de 13,3 para 1,59 — o sistema filtra cada vez mais) e a defasagem (de $-33{,}7°$ para $-84{,}3°$, aproximando-se do limite de $-90°$ do polo). **Não mudou:** a frequência (sempre igual à da entrada — sistemas LTI não criam frequências) e a forma senoidal.

---

## Questão 2 — Esboço do diagrama de Bode

**Consulte:** teoria §3.1.5 (convenções), §3.1.6 (esboço assintótico de módulo, erro de 3 dB) e §3.1.7 (fase por retas de $\omega_q/5$ a $5\omega_q$); Exercício 3.1.2 dos exercícios resolvidos.

**a)** Forma de Bode: $G(s) = \dfrac{20/20}{(s+1)(s/20+1)} = \dfrac{1}{(s+1)(s/20+1)}$ → ganho de Bode $K_B = 1$ → **patamar de 0 dB**. Quebras: $\omega_{q1} = 1$ e $\omega_{q2} = 20$ rad/s.
Módulo assintótico: **0 dB** até $\omega = 1$; **−20 dB/déc** de 1 a 20; **−40 dB/déc** após 20.

**b)** Erro nas quebras (regra dos 3 dB):
- $\omega = 1$: exato $|G| = \dfrac{20}{\sqrt{2}\sqrt{401}} = 0{,}707 \to -3{,}01$ dB; assíntota: 0 dB → **erro de $-3{,}0$ dB** ✓.
- $\omega = 20$: exato $|G| = \dfrac{20}{\sqrt{401}\sqrt{800}} = 0{,}0353 \to -29{,}04$ dB; assíntota: $0 - 20\log_{10}(20) = -26{,}02$ dB → **erro de $-3{,}0$ dB** ✓.

**c)** Fase assintótica (retas de $\omega_q/5$ a $5\omega_q$): polo em 1 → reta de $0{,}2$ a $5$; polo em 20 → reta de $4$ a $100$.
- $\omega = 0{,}2$: **0°** (início da primeira reta);
- $\omega = 4$: só o polo 1 contribui: $-45°\log_{10}(4/0{,}2) = -45° \times 1{,}301 = -58{,}5°$;
- $\omega = 100$: $-90°$ (polo 1 saturado) $+ (-90°)$ (fim da reta do polo 20) $= \mathbf{-180°}$ = fase final.

**d)** Fase exata em $\omega = 20$: $-\mathrm{arctg}(20/1) - \mathrm{arctg}(20/20) = -87{,}1° - 45° = -132{,}1°$.
Assíntota: $-90° - 45°\log_{10}(20/4) = -90° - 31{,}5° = -121{,}5°$.
Erro: $-132{,}1° - (-121{,}5°) = -10{,}6° \approx \mathbf{11°}$ — o erro máximo da convenção. Ele ocorre **nas extremidades das retas** ($\omega_q/5$ e $5\omega_q$) e nas vizinhanças; no centro do intervalo entre quebras afastadas o erro é pequeno. É por esse erro limitado que o esboço assintótico é aceitável para projeto (a curva exata é usada na verificação final).

---

## Questão 3 — Margens de estabilidade e ajuste de ganho

**Consulte:** teoria §3.1.8 (PM e GM no Bode), §3.1.9 (PM ≈ 100ζ) e §3.1.10 (projeto de P pela PM); Exercícios 3.1.3 e 3.1.4 dos exercícios resolvidos.

**a)** Cruzamento de ganho: $|G(j\omega_c)| = \dfrac{2}{\omega_c\sqrt{\omega_c^2+1}\sqrt{\omega_c^2+25}} = 1$ → $\omega_c^2(\omega_c^2+1)(\omega_c^2+25) = 4$. Tentativa: $\omega = 0{,}37 \to 3{,}91$; $\omega = 0{,}38 \to 4{,}16$ → $\boxed{\omega_c \approx 0{,}37\ \mathrm{rad/s}}$.
$\angle G(j\omega_c) = -90° - \mathrm{arctg}(0{,}37) - \mathrm{arctg}(0{,}075) = -90° - 20{,}3° - 4{,}3° = -114{,}6°$ → $\boxed{\mathrm{PM} = 65{,}4°}$.

**b)** Cruzamento de fase: $-90° - \mathrm{arctg}(\omega_f) - \mathrm{arctg}(\omega_f/5) = -180°$ → os dois arctg somam $90°$ → $\omega_f = \sqrt{1 \times 5} = \sqrt{5} = 2{,}24$ rad/s.
$|G(j\omega_f)| = \dfrac{2}{2{,}24 \times \sqrt{6} \times \sqrt{30}} = \dfrac{2}{30} = 0{,}0667$ → $\boxed{\mathrm{GM} = 23{,}5\ \mathrm{dB}}$ (fator $15$ sobre o ganho da malha, ou seja, numerador total crítico $2 \times 15 = 30$).
**Routh:** característico $s^3 + 6s^2 + 5s + 2K$ → linha $s^1$: $\dfrac{6 \times 5 - 2K}{6} > 0 \Rightarrow K < 15$ ✓ — exatamente a GM calculada.

**c)** PM alvo $= 45°$: achar $\omega$ com fase $-135°$: $-90° - \mathrm{arctg}\omega - \mathrm{arctg}(\omega/5) = -135°$ → $\mathrm{arctg}\omega + \mathrm{arctg}(\omega/5) = 45°$. Pela tangente da soma: $\dfrac{\omega + \omega/5}{1 - \omega^2/5} = 1$ → $\omega^2 + 6\omega - 5 = 0$ → $\omega = -3 + \sqrt{14} = 0{,}742$ rad/s.
$|G(j0{,}742)| = \dfrac{2}{0{,}742 \times \sqrt{1{,}55} \times \sqrt{25{,}55}} = \dfrac{2}{4{,}67} = 0{,}428$ → $\boxed{K = 1/0{,}428 = 2{,}33}$ ($+1{,}3$ dB).
Estimativa: PM $= 45° \Rightarrow \zeta \approx 0{,}45 \Rightarrow M_p \approx 22\%$. (Simulação com $K = 2{,}33$: $M_p = 23{,}3\%$, $t_r = 2{,}5$ s — confere a ponte. Note que o sistema ficou **mais lento**: $\omega_c$ caiu de 0,37 para... verifique: subiu na verdade, pois $K > 1$ — compare as duas $\omega_c$ e comente.)

---

## Questão 4 — Carta de Nichols-Black e pico de ressonância

**Consulte:** teoria §3.2.1–§3.2.2 ($M_r$ e $\omega_r$ analíticos), §3.2.3 (a geometria de $T = G/(1+G)$), §3.2.4–§3.2.5 (a carta e a translação vertical), §3.2.6 (a ponte $M_r \to \zeta \to M_p$); Exercícios 3.2.1 e 3.2.2 dos exercícios resolvidos.

**a)** Parâmetros: $\omega_n = \sqrt{16} = 4$ rad/s; $2\zeta\omega_n = 2{,}4 \Rightarrow \zeta = 0{,}3$.
1. Ressonância existe ($\zeta = 0{,}3 < 0{,}707$): $\omega_r = \omega_n\sqrt{1 - 2\zeta^2} = 4\sqrt{0{,}82} = \mathbf{3{,}62}$ rad/s;
2. $M_r = \dfrac{1}{2\zeta\sqrt{1-\zeta^2}} = \dfrac{1}{0{,}6 \times 0{,}954} = \mathbf{1{,}75}$ → $20\log_{10}(1{,}75) = \mathbf{4{,}85\ \mathrm{dB}}$;
3. Ponte para o tempo: $M_p = e^{-\zeta\pi/\sqrt{1-\zeta^2}} = e^{-0{,}3\pi/0{,}954} = \mathbf{37\%}$; $t_r \approx 1{,}8/\omega_n = \mathbf{0{,}45\ \mathrm{s}}$.

**b)** $G = 1\angle{-90°} = -j$ → $1 + G = 1 - j$ → $|1+G| = \sqrt{2} = 1{,}414$ e $\angle(1+G) = -45°$.
$|T| = \dfrac{1}{1{,}414} = \mathbf{0{,}707}$ ($\mathbf{-3{,}0\ \mathrm{dB}}$); $\angle T = -90° - (-45°) = \mathbf{-45°}$.
Na carta: o ponto de malha aberta $(-90°,\ 0\ \mathrm{dB})$ está sobre a curva de $|T| = -3$ dB e a curva de fase de $T$ igual a $-45°$ — confira na figura `m3_fig09`.

**c)** Multiplicar por $K$ soma $20\log_{10}K$ ao módulo (eixo vertical) e **zero** à fase (eixo horizontal) — logo a curva inteira sobe/desce rigidamente. Como a grade da carta já contém as curvas de $|T|$ e $\angle T$ constantes, a translação revela imediatamente **qual curva de $M_r$ a malha aberta tangencia** (o pico de ressonância da malha fechada) e **em que coluna a curva cruza 0 dB** (a PM) — sem recalcular $T(s)$.

---

## Questão 5 — Critério de Nyquist

**Consulte:** teoria §3.3.4 (contorno e indentação), §3.3.5 (Z = N + P e leitura da faixa de K), §3.3.7 (custo do atraso na PM); Exercício 3.3.2 dos exercícios resolvidos.

**a)** Denominador: $(s+1)(s+3)(s+6) = s^3 + 10s^2 + 27s + 18$. Em $s = j\omega$: parte real $18 - 10\omega^2$; parte imaginária $\omega(27 - \omega^2)$.
Cruzamento com o eixo real: $\omega(27-\omega^2) = 0 \Rightarrow \omega = \sqrt{27} = 5{,}20$ rad/s; valor: $G = \dfrac{K}{18 - 10 \times 27} = \mathbf{-K/252}$.
Como $P = 0$, estabilidade exige $N = 0$: $-K/252 > -1$ → $\boxed{0 < K < 252}$.
**Routh:** $s^3 + 10s^2 + 27s + (18+K)$ → linha $s^1$: $10 \times 27 - (18+K) > 0 \Rightarrow K < 252$ ✓.

**b)** $K = 63$: $\mathrm{GM} = 20\log_{10}\dfrac{252}{63} = 20\log_{10}4 = \mathbf{12{,}0\ \mathrm{dB}}$.

**c)** Com $K = 63$, o cruzamento de ganho: $(\omega_c^2+1)(\omega_c^2+9)(\omega_c^2+36) = 63^2 = 3969$ → $\omega_c^2 \approx 5{,}6$ → $\omega_c = 2{,}36$ rad/s.
PM sem atraso: $180° - \mathrm{arctg}(2{,}36) - \mathrm{arctg}(0{,}79) - \mathrm{arctg}(0{,}39) = 180° - 67{,}0° - 38{,}3° - 21{,}4° = 53{,}3°$.
Custo do atraso: $\delta\omega_c = 0{,}1 \times 2{,}36 = 0{,}236$ rad $= 13{,}5°$ → $\boxed{\mathrm{PM} \approx 39{,}8°}$.
**A GM também muda!** Embora $|e^{-j\delta\omega}| = 1$, a fase extra derruba a frequência de cruzamento de fase $\omega_f$ — e como $|G|$ é maior em frequências mais baixas, a GM **diminui**. (Apenas a curva de módulo do Bode permanece intacta.)

---

## Questão 6 — Atraso de transporte

**Consulte:** teoria §3.3.7 (o fasor $e^{-\delta s}$: módulo 1, fase $-\delta\omega$) e §3.3.8 (a espiral de Nyquist e o custo $\delta\omega_c$ na PM); Exercício 3.3.3 dos exercícios resolvidos.

**a)** $|G(j\omega)| = \dfrac{2}{\sqrt{\omega^2+1}} \cdot \underbrace{|e^{-j0{,}5\omega}|}_{=1} = \dfrac{2}{\sqrt{\omega^2+1}}$; $\angle G(j\omega) = -\mathrm{arctg}\omega - 0{,}5\omega$ (o segundo termo em radianos). A curva de módulo não muda porque o atraso é uma **rotação pura**: $|e^{-j\delta\omega}| = |\cos\delta\omega - j\mathrm{sen}\delta\omega| = 1$ para todo $\omega$.

**b)** $\dfrac{2}{\sqrt{\omega_c^2+1}} = 1 \Rightarrow \omega_c^2 = 3 \Rightarrow \boxed{\omega_c = \sqrt{3} = 1{,}73\ \mathrm{rad/s}}$.
PM sem atraso: $180° - \mathrm{arctg}(1{,}73) = 180° - 60° = \mathbf{120°}$.

**c)** Custo: $\delta\omega_c = 0{,}5 \times 1{,}73 = 0{,}866$ rad $= 49{,}6°$ → $\boxed{\mathrm{PM} = 120° - 49{,}6° = 70{,}4°}$.

**d)** PM $= 0°$ quando o atraso consumir os $120°$: $\delta_{máx} = \dfrac{120°\ \mathrm{em\ rad}}{\omega_c} = \dfrac{2{,}094}{1{,}73} = \boxed{1{,}21\ \mathrm{s}}$.

**e)** O módulo decai apenas como $2/\omega$ (devagar), enquanto a fase cai **sem limite** ($-0{,}5\omega$ domina): a curva gira indefinidamente em torno da origem enquanto o raio encolhe — uma espiral. Cada volta completa cruza o eixo real mais duas vezes → infinitos cruzamentos (e infinitos "candidatos" a margem de ganho: conta-se sempre o cruzamento **mais próximo de $-1$**, o maior módulo).

---

## Questão 7 — Projeto de avanço de fase

**Consulte:** teoria §3.4.3–§3.4.4 (as três fórmulas do avanço) e §3.4.5 (a receita de 6 passos); Exercício 3.4.2 dos exercícios resolvidos.

**a)** Tradução (§3.1.9–§3.1.10):
- $M_p \leq 20\% \Rightarrow \zeta \geq 0{,}46 \Rightarrow \mathrm{PM} \geq 46°$; com folga de $\approx 5°$: **PM alvo $= 50°$**;
- $t_r \approx 1{,}8/\omega_c \leq 1{,}2 \Rightarrow \omega_c \geq 1{,}5$; com folga: **$\omega_c$ alvo $= 1{,}6$ rad/s**.

**b)** Receita de 6 passos:
1. Planta na $\omega_c$ alvo: $|G(j1{,}6)| = \dfrac{2}{1{,}6\sqrt{1+2{,}56}} = \dfrac{2}{1{,}6 \times 1{,}887} = 0{,}662$ ($-3{,}6$ dB);
2. $\angle G = -90° - \mathrm{arctg}(1{,}6) = -90° - 58{,}0° = -148{,}0°$ → PM atual $= 32{,}0°$;
3. Fase a avançar: $\phi = 50° - 32{,}0° = 18{,}0°$ (a folga já está na PM alvo — não somar duas vezes!);
4. $\alpha = \dfrac{1 - \mathrm{sen}18°}{1 + \mathrm{sen}18°} = \dfrac{0{,}691}{1{,}309} = 0{,}53$; $T = \dfrac{1}{1{,}6\sqrt{0{,}53}} = 0{,}86$ s; $\alpha T = 0{,}45$ s (zero em $-1{,}16$, polo em $-2{,}20$);
5. $K = \dfrac{\sqrt{\alpha}}{|G(j1{,}6)|} = \dfrac{0{,}727}{0{,}662} = 1{,}10$;
$$\boxed{C(s) = 1{,}1\dfrac{0{,}86s+1}{0{,}45s+1}}$$
6. **Simulação (obrigatória):** $M_p = 18{,}4\%$ ✓ ($\leq 20\%$), $t_r = 1{,}16$ s ✓ ($\leq 1{,}2$ s); PM compensada $= 50{,}0°$ — exata, por construção.

**c)** Estimativa: PM $= 50° \Rightarrow \zeta \approx 0{,}50 \Rightarrow M_p \approx 16\%$. A simulação deu $18{,}4\%$ — a mais, como de costume. O culpado é o **zero do compensador** (em $-1{,}16$, dentro da banda da malha fechada): pelo efeito do zero (§2.1.9), ele soma a derivada da resposta a si mesma, aumentando o overshoot em relação à 2ª ordem pura. É por isso que a folga na PM alvo existe.

---

## Questão 8 — Projeto de atraso de fase

**Consulte:** teoria §3.4.6 (o mecanismo do atraso: par perto da origem, z/p = melhoria do erro); Exercício 3.4.3 dos exercícios resolvidos.

**a)** $G(0) = 6/3 = 2$ → $k_p = 2$ → $e_{ss} = 1/(1+2) = \mathbf{33{,}3\%}$.
Dinâmica: $(\omega_c^2+1)(\omega_c^2+9) = 36 \Rightarrow \omega_c^2 = -5 + \sqrt{52} = 2{,}21 \Rightarrow \omega_c = 1{,}49$ rad/s;
PM $= 180° - \mathrm{arctg}(1{,}49) - \mathrm{arctg}(0{,}50) = 180° - 56{,}1° - 26{,}4° = \mathbf{97{,}5°}$ — folgadíssima.

**b)** Requisito: $e_{ss} \leq 0{,}1 \Rightarrow k_{pc} \geq 9 \Rightarrow z/p \geq 4{,}5$. Com folga: $z/p = 5$ → $k_{pc} = 10$ → $e_{ss} = 1/11 = 9{,}1\%$.
Polo uma década abaixo do cruzamento: $p = -\omega_c/10 = -0{,}149$; zero: $z = -5 \times 0{,}149 = -0{,}743$.
$$\boxed{C(s) = \dfrac{s + 0{,}743}{s + 0{,}149}}$$

**c)** Contribuição de fase do par em $\omega_c = 1{,}49$: $\mathrm{arctg}(1{,}49/0{,}743) - \mathrm{arctg}(1{,}49/0{,}149) = 63{,}5° - 84{,}3° = \mathbf{-20{,}8°}$.
**Atenção:** não é desprezível! Como $z/p = 5$ e $p = -\omega_c/10$, o zero cai em $-\omega_c/2$ — dentro da região de influência. O que salva o projeto é a PM atual de $97{,}5°$: a compensada fica $\approx 77°$, ainda enorme ✓. (Numa planta com PM justa, a saída é afastar o par: regra do $\omega_c/200$ — §3.4.7. Simulação: $e_{ss} = 0{,}091$ ✓, $M_p$: $6{,}0\% \to 2{,}1\%$, $t_r$: $1{,}03 \to 1{,}33$ s.)

**d)** A cauda lenta vem do modo do par: $\tau \approx 1/|p| = 1/0{,}149 \approx \mathbf{6{,}7\ \mathrm{s}}$. O resíduo é pequeno (o zero quase cancela o polo na resposta), mas a convergência final para o novo regime é visivelmente mais lenta que o transitório principal — é o preço do erro menor.

---

## Questão 9 — Projeto de PID na frequência

**Consulte:** teoria §3.5.1 (fórmulas diretas do PD), §3.5.2 (PI), §3.5.3–§3.5.4 (PID = PD × PI e o papel da folga); Exercício 3.5.3 dos exercícios resolvidos.

**a)** Velocidade: $t_r \approx 1{,}8/\omega_c \leq 0{,}7 \Rightarrow \omega_c \geq 2{,}6$ → **$\omega_c$ alvo $= 3{,}0$ rad/s** (folga de velocidade).
Overshoot: $M_p \leq 15\% \Rightarrow \zeta \geq 0{,}52 \Rightarrow \mathrm{PM} \geq 52°$; folga de $\approx 13°$ para pagar a PI ($\approx -6°$) e o polo de filtragem ($\approx -0{,}6°$), com margem: **PM alvo $= 65°$**.

**b)** Planta na $\omega_c$ alvo: $|G(j3)| = \dfrac{0{,}5}{\sqrt{9{,}25}\sqrt{13}} = \dfrac{0{,}5}{3{,}04 \times 3{,}61} = 0{,}0456$ ($-26{,}8$ dB);
$\angle G = -\mathrm{arctg}(3/0{,}5) - \mathrm{arctg}(3/2) = -80{,}5° - 56{,}3° = -136{,}8°$ → PM atual $= 43{,}2°$.
$\phi = 65° - 43{,}2° = 21{,}8°$:
$$k_p = \dfrac{\cos 21{,}8°}{0{,}0456} = \mathbf{20{,}4}; \qquad k_d = \dfrac{\mathrm{sen}21{,}8°}{3 \times 0{,}0456} = \mathbf{2{,}72}$$
Polo de filtragem em $-100\omega_c = -300$: $C_{PD}(s) = \dfrac{20{,}4 + 2{,}72s}{s/300 + 1}$.

**c)** PI: zero uma década abaixo: $z_1 = -\omega_c/10 = -0{,}3$ → $C_{PI}(s) = \dfrac{s+0{,}3}{s}$.
$$\boxed{C(s) = \dfrac{20{,}4 + 2{,}72s}{s/300 + 1}\cdot\dfrac{s+0{,}3}{s}}$$

**d)** Descontos na PM: PI em $\omega_c$: $-90° + \mathrm{arctg}(3/0{,}3) = -90° + 84{,}3° = -5{,}7°$; polo de filtragem: $-\mathrm{arctg}(3/300) = -0{,}6°$. PM efetiva $\approx 65° - 6{,}3° = \mathbf{58{,}7°}$ → $\zeta \approx 0{,}59$ → $M_p$ esperado $\approx 10\%$.
**Simulação:** $M_p = 11{,}3\%$ ✓ ($\leq 15\%$), $t_r = 0{,}67$ s ✓ ($\leq 0{,}7$ s), $y(\infty) \to 1$ → $e_{ss} = 0$ ✓ — três requisitos atendidos; PM compensada medida: $58{,}7°$, exatamente a prevista.

---

## Bônus — O maior atraso tolerável

**Consulte:** teoria §3.3.7–§3.3.8 (custo $\delta\omega_c$ na PM) e §3.1.8 (margens); Exercício 3.3.3 dos exercícios resolvidos.

1. **$\omega_c$ (independe do atraso):** $\dfrac{2}{\omega_c\sqrt{\omega_c^2+1}\sqrt{\omega_c^2+4}} = 1$ → $\omega_c^2(\omega_c^2+1)(\omega_c^2+4) = 4$. Com $x = \omega_c^2$: $x = 0{,}55 \to 3{,}88$; $x = 0{,}57 \to 4{,}09$ → $x \approx 0{,}56$ → $\omega_c = 0{,}75$ rad/s.
2. **PM sem atraso:** $180° - 90° - \mathrm{arctg}(0{,}75) - \mathrm{arctg}(0{,}375) = 90° - 36{,}9° - 20{,}6° = 32{,}5°$.
3. **Limite:** o atraso consome PM a $\delta\omega_c$ radianos; PM $= 0$ quando $\delta_{máx} = \dfrac{32{,}5° \times \pi/180}{0{,}75} = \dfrac{0{,}567}{0{,}75} \approx \boxed{0{,}76\ \mathrm{s}}$.
4. Interpretação: menos de um segundo de atraso leva essa malha ao limite — e na prática se projeta com PM de sobra (45–60°), então o atraso **realmente tolerável** é cerca da metade disso. É a lição central do atraso de transporte: **a banda de malha ($\omega_c$) é limitada pelo atraso**, não pelo atuador.
