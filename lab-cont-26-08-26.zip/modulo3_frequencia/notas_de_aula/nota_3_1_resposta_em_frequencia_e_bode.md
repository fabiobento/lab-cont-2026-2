# Nota de Aula 3.1 — Resposta em Frequência e Diagrama de Bode

> **Documento do professor** — guia de quadro, pronto para transcrição linha a linha, com falas sugeridas.
> Duração prevista: 2 h (semana 10). Lab associado: **Lab 10**.

**Mapa dos vídeos deste tópico (não mostrar aos alunos):**

| Vídeo | Título | Uso na aula |
|---|---|---|
| 01 | Motivação (Desafio do Jackman) | Abertura: projetar SEM modelo, 1 chance de fechar a malha (Q1) |
| 02 | Introdução | Contexto histórico: Bell Labs, Black/Nyquist/Bode, anos 1920–40 (Q1) |
| 03 | A resposta em frequência de sistemas LIT | Dedução de y = \|G(jω)\|·A·sen(ωt+∠G); exemplo RC nos 3 ω (Q2) |
| 04 | Visualização e Diagrama de Bode | Regra de três da fase; escala log; dB (Q2) |
| 05 | Relação entre o Bode e a FT | G(jω) por substituição; assíntota de alta frequência (Q2) |
| 06 | Bode de sistemas de 1ª ordem | Quebra, erro 3 dB, reta /5–×5, erro 11° (Q3) |
| 07 | Bode de 2ª ordem com polos reais | Soma de contribuições; 0 → −20 → −40 dB/déc (Q3) |
| 08 | Bode de 2ª ordem do tipo 1 | Começa em −20 dB/déc e −90°; ponte com ess=0 (Q3) |
| 09 | Margem de fase; efeito do ganho | Ponto crítico −1; ωc, ωf, PM, GM; translação por K (Q4) |
| 10 | PM × sobressinal | PM ≈ 100ξ; fórmula exata; exemplo ωn=1, ξ=0,5 (Q5) |
| 11 | Projeto de P pela PM | Receita K = 1/\|G\|; exemplo 10/[s(s+2)]; folga 5–10° (Q5) |

---

## Q1 — O desafio e o contexto (15 min)

**Quadro:**

```
O DESAFIO: projetar controlador P para o carrinho (entrada: tensão, saída: posição)
 requisito: overshoot de 30 %
 SEM equações diferenciais, SEM função de transferência
 UMA ÚNICA CHANCE de fechar a malha
 MAS: pode testar em MALHA ABERTA com quaisquer entradas, quantas vezes quiser

Pergunta para a turma: por onde você começaria?

CONTEXTO (anos 1920–40, Laboratórios Bell):
 amplificadores para cabos telefônicos transcontinentais
 sem computador → técnicas GRÁFICAS e EXPERIMENTAIS
 Black, Nyquist, Bode → ainda hoje entre as mais usadas na indústria

A PERGUNTA-MESTRE DO MÓDULO:
 o que aprendemos sobre um sistema medindo como ele responde a SENOIDES
 de várias frequências?  →  RESPOSTA: praticamente TUDO (inclusive o projeto)
```

**Fala sugerida:** "Até aqui, todos os nossos projetos começavam com uma função de transferência na mão. E se não houver FT? Sistema complexo demais, componentes inacessíveis, parâmetros desconhecidos. Foi o problema dos engenheiros da Bell há um século — e a solução deles é tão boa que continua sendo padrão de indústria. Nas próximas 5 semanas vocês vão aprender a ganhar essa aposta do carrinho."

---

## Q2 — Resposta em frequência: a dedução e a medição (30 min)

**Quadro (dedução — conduzir com calma, é a única dedução "pesada" da aula):**

```
G(s) = K·N(s)/Π(s−pi),  Re(pi) < 0  (estável),  entrada u(t) = A·sen(ωt)

sen(ωt) = (e^{jωt} − e^{−jωt})/2j
Y(s) = G(s)U(s) → frações parciais:
 (i) termos dos polos pi de G  → MORREM (sistema estável)
 (ii) termos dos polos da entrada (s = ±jω) → ficam para sempre

resíduo em s = jω:  a0 = A·G(jω)/2j
y(t) = a0·e^{jωt} + ā0·e^{−jωt}  (regime permanente senoidal)

★ RESULTADO (emoldurar):
 y(t) = |G(jω)| · A · sen(ωt + ∠G(jω))

 mesma frequência | amplitude × |G(jω)| | fase + ∠G(jω)|
 G(jω) = FT avaliada no eixo imaginário = RESPOSTA EM FREQUÊNCIA
```

**Quadro (exemplo RC — medir/calcular as 3 linhas com a turma):**

```
RC: G(s) = 1/(0,1034s + 1)   (R = 470 kΩ, C = 220 nF)
 |G(jω)| = 1/√((0,1034ω)² + 1)     ∠G(jω) = −arctg(0,1034ω)

 ω = 1:   |G| = 0,995   ∠G = −5,9°   → passa quase tudo
 ω = 10:  |G| = 0,695   ∠G = −46,0°  → ~70 %, atraso crescente
 ω = 100: |G| = 0,096   ∠G = −84,5°  → quase nada passa
 (projetar fig m3_fig01_resposta_frequencia.png)
```

**Quadro (da medição ao Bode):**

```
ENSAIO EXPERIMENTAL:
 módulo = amplitude da saída / amplitude da entrada
 fase: regra de três — Δt/T = |∠G|/360°

PROBLEMAS: ω cobre ordens de grandeza → eixo LOG
           |G| também → DECIBEL:  |G|dB = 20·log10|G|

DIAGRAMA DE BODE = (módulo em dB × log ω)  +  (fase em graus × log ω)
 para guardar: 1↔0 dB · 2↔+6 · 10↔+20 · √2↔+3 · 1/2↔−6 · 0,1↔−20
 multiplicar por K SOMA 20·log K (log transforma produto em soma!)
```

**Fala:** "Gravem o resultado emoldurado: senoide entra, senoide sai — mesma frequência, amplitude e fase dadas por G(jω). Se o sistema for uma caixa-preta, essa tabela É o sistema. E se tivermos a FT, é só trocar s por jω."

---

## Q3 — Esboços assintóticos (30 min)

**Quadro (projetar figs `m3_fig02`, `m3_fig03`, `m3_fig04`):**

```
1ª ORDEM: G = K/(s−p1), p1 < 0 — quebra em ωq = |p1|
 módulo: plano (20log K − 20log|p1|) → −20 dB/déc
   ERRO MÁX: −3 dB na quebra (|G(j|p1|)| = |K|/(√2·|p1|); 1/√2 = 0,707)
 fase: 0° → −90°, RETA DE |p1|/5 A 5·|p1| (−45° na quebra, tangente à exata)
   ERRO MÁX: ≈ 11° = 0,19 rad   ← CONVENÇÃO DO CURSO!
   (outros textos: /10–×10, erro 5,7°; nós usamos /5–×5)

2ª ORDEM (polos reais): módulo em dB = SOMA das contribuições
 plano → −20 (após 1ª quebra) → −40 dB/déc (após 2ª)
 fase: 0° → −90° → −180° (uma reta /5–×5 por polo)

TIPO 1: G = K/[s(s−p1)] — a quebra da origem "some no −∞"
 módulo: JÁ COMEÇA em −20 dB/déc; posicionar: em ω = 1, |G| ≈ K
 fase: COMEÇA em −90° (integrador) → −180°
 ★ PONTE COM O M01: assíntota de baixas com −20 dB/déc ou mais
   ⇔ G(0) = ∞ ⇔ ess = 0 ao degrau!
   (erro em regime = BAIXAS frequências; transitório = região do cruzamento)
```

**Atividade (5 min):** "Esbocem no caderno o Bode de $G = 5/(s+2)$: quebra, assíntotas, erro na quebra, reta da fase." → conferir: plano em $20\log 5 - 20\log 2 = 8$ dB até ω = 2; reta da fase de 0,4 a 10.

**Fala:** "Três desenhos para a vida: um polo, dois polos, integrador mais polo. Tudo no resto do módulo — e boa parte dos projetos da vida profissional — é combinação desses três tijolos."

---

## Q4 — Margem de fase e margem de ganho (25 min)

**Quadro (projetar fig `m3_fig05_margens_bode.png`):**

```
PONTO CRÍTICO: polos de MF ⇔ 1 + G(s) = 0 ⇔ G(s) = −1 (módulo 1, fase −180°)
 avaliar G(jω) = testar o limiar da estabilidade!

FREQUÊNCIAS-CHAVE:
 ωc: |G(jωc)| = 1 (0 dB)      ωf: ∠G(jωf) = −180°

★ MARGENS (emoldurar):
 PM = ∠G(jωc) + 180°         GM = −|G(jωf)|dB
 PM = "quantos graus faltam para −180° no cruzamento"
 GM = "quantos dB posso subir antes de cruzar em ωf"

EXEMPLO: G = 0,95/[s(s+1)(s+5)]
 ωc = 0,187 → PM = 77,3° ; ωf = 2,23 → GM = 30,0 dB

EFEITO DO GANHO K > 0: módulo TRANSLADA 20log K; fase INTACTA
 K > 1: ωc ↑ → PM ↓ (mais rápido, mais oscilatório)
 K < 1: ωc ↓ → PM ↑ (mais lento, mais amortecido)
 ex.: K = 5 (+14 dB) → ωc = 0,751 → PM = 44,5°
```

**Fala:** "PM e GM são distâncias do precipício. O ponto (−1) é a beirada: módulo 1 com fase −180° é a condição exata de oscilação sustentada. As margens dizem quanta 'estrada' ainda temos — e o ganho só move o carro para frente e para trás na estrada do módulo, sem mudar a da fase."

---

## Q5 — PM × sobressinal e o primeiro projeto (20 min)

**Quadro (projetar figs `m3_fig06` e `m3_fig07`):**

```
PONTE FREQUÊNCIA ↔ TEMPO (2ª ordem tipo 1: G = ωn²/[s(s+2ξωn)])
 ωc = ωn·√(√(1+4ξ⁴) − 2ξ²)   →   PM = arctg[2ξ/√(√(1+4ξ⁴) − 2ξ²)]
 curva PM × ξ ≈ RETA até ξ ≈ 0,65 (erro ~5°):
 ★ PM ≈ 100·ξ        ωn ≈ ωc
 ex.: G = 1/[s(s+1)] (ξ = 0,5): ωc = 0,786, PM = 51,8° → Mp ≈ 16 % ✓
      3G: ωc = 1,594, PM = 32,1° → Mp ≈ 38 % (simulado: 38,8 %)

PROJETO DE P PELA PM (receita):
 1. Mp → ξ → PM alvo = 100ξ (+ 5–10° DE FOLGA — regra do curso!)
 2. no Bode: achar ω onde fase = PM alvo − 180° → novo ωc
 3. K = 1/|G(jω)| nessa frequência (KdB = −|G|dB)

EXEMPLO-ÂNCORA: G = 10/[s(s+2)], Mp ≤ 20 %
 K = 1: Mp = 35,1 % ✗
 ξ = 0,456 → PM = 45° → fase −135° em ω = 2, |G| = 1,77 (4,95 dB)
 K = 1/1,77 = 0,56 → ωc = 2, PM = 45°
 simulado: Mp = 23,3 % — o custo das aproximações! (com +5° de folga: ≤ 20 %)
```

**Fala de fechamento:** "E está ganha a primeira aposta: projetamos o ganho para um requisito de overshoot sem escrever uma linha de equação diferencial e sem fechar a malha uma única vez. Se a planta for desconhecida, a tabela vem do ensaio com senoides — o procedimento é o mesmo. No lab 10 vocês vão fazer isso com as próprias mãos. E guardem a folga de 5–10°: ela é o seguro contra todas as aproximações que fizemos."

---
