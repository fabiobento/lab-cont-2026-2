# Nota de Aula 3.2 — Carta de Nichols-Black e Especificação no Domínio da Frequência

> **Documento do professor** — guia de quadro, pronto para transcrição linha a linha, com falas sugeridas.
> Duração prevista: 2 h (semana 11). Lab associado: **Lab 11**.

**Mapa dos vídeos deste tópico (não mostrar aos alunos):**

| Vídeo | Título | Uso na aula |
|---|---|---|
| 01 | Bode de 2ª ordem subamortecidos | Pico de ressonância: ωr, Mr; família em ξ (Q1) |
| 02 | Bode de MA × Bode de MF: cálculo ponto a ponto? | Fórmulas ponto a ponto; casos \|G\|≫1 e \|G\|≪1 (Q1) |
| 03 | A carta de Nichols-Black | Definição; leitura; RC e 10/[(s+1)(s+10)] (Q2) |
| 04 | Cruzamento de 0 dB e PM na carta: ajuste de ganho | Translação vertical; G=100/(s²+4s+29), K=10 (Q2) |
| 05 | PM em MA ↔ pico de ressonância em MF; ωc ↔ ωn | Âncora: G=2,4/[s(s+1,2)]; kit de tradução completo (Q3) |
| 06 | ★ NOVO V3 — estender as relações para qualquer sistema | Tipo 0 e 3ª ordem: vale com cuidado (Q3) |
| 07 | Projeto com requisito de sobressinal | G=60/[(s+0,02)(s+1)(s+15)], K=0,32 (Q4) |
| 08 | Projeto com requisito de ωn | G=0,005/[(s+0,03)(s+0,1)(s+0,5)], K=2,3; limite do ganho puro (Q5) |

**⚠ Erratas de transcrição já corrigidas no material (não propagar no quadro):** v04: "100×10.000" → KG = 1000/(s²+4s+29); v08: a planta é (s+0,1) e **não** (s+1) — confirmado por simulação (todos os âncoras do vídeo só batem com 0,1).

---

## Q1 — Pico de ressonância e a ponte MA → MF (25 min)

**Quadro (projetar fig `m3_fig08_bode_subamortecido.png`):**

```
2ª ORDEM SUBAMORTECIDA: G = ωn²/(s² + 2ξωn s + ωn²)
 perto da quebra em ωn: o módulo depende MUITO de ξ → PICO DE RESSONÂNCIA
 derivando |G(jω)| e igualando a zero:
 ★ ωr = ωn·√(1 − 2ξ²)   (só existe para ξ ≤ 0,707)
 ★ Mr = 1/(2ξ·√(1 − ξ²))
 ex.: ξ = 0,3, ωn = 1 → ωr = 0,906 rad/s, Mr = 1,75 (4,85 dB)
 ξ menor → pico maior;  ξ > 0,707 → sem pico

 PONTE: Mp (tempo) ↔ ξ ↔ Mr (frequência)
 o pico de ressonância é o "overshoot do domínio da frequência"
```

**Quadro (cálculo ponto a ponto MA → MF):**

```
T = G/(1+G) — conhecendo G(jω) tabelado, dá para calcular ponto a ponto:
 |T| = |G|/√((1+|G|cosφ)² + (|G|senφ)²)
 ∠T = φ − arctg[|G|senφ/(1+|G|cosφ)]
 casos limites: |G| ≫ 1 → T ≈ 1 (MF copia a referência)
                |G| ≪ 1 → T ≈ G (MF ≈ MA)
 ex. RC (K=1): ponto (0°; 0 dB) → |T| = 1/2 = −6 dB, ∠T = 0°
 "complicado fazer à mão para dezenas de pontos, não?" → gancho para a carta
```

**Fala:** "Nos anos 40, calcular essas fórmulas para trinta frequências era um dia de trabalho. A solução dos engenheiros da Bell foi transformar o cálculo em LEITURA DE GRÁFICO — é a carta que vem a seguir."

---

## Q2 — A carta de Nichols-Black (30 min)

**Quadro (projetar fig `m3_fig09_carta_nb.png` GRANDE):**

```
A CARTA DE NICHOLS-BLACK:
 eixos: fase de MA (graus) × módulo de MA (dB)  — o Bode fundido numa curva só
 impressos no papel: LUGARES GEOMÉTRICOS de |T| (dB) e de ∠T (graus) de MF
 uso: desenha a curva de MA (marcando frequências!) e LÊ a MF nos cruzamentos
 perde-se a referência explícita de ω → marcar pontos na curva

 leituras do exemplo RC (K = 1):
 (0°; 0 dB) → lugar de |T| = −6 dB, ∠T = 0°
 ω = 100: (−84°; −20 dB) → praticamente sobre o lugar de −20 dB (T ≈ G)

 geometria: lugares de |T| são "ilhas" em torno do ponto crítico (−180°; 0 dB)
 quanto mais perto dele, MAIOR o |T| de MF (ressonância!)
```

**Quadro (ajuste de ganho — projetar fig `m3_fig10_nb_ajuste_ganho.png`):**

```
AJUSTE DE GANHO = TRANSLAÇÃO VERTICAL PURA (a fase não muda!)
 antigamente: papel transparente arrastado sobre a carta — projeto gráfico

 ex.: G = 100/(s² + 4s + 29)
 K = 1:  cruza 0 dB com fase ≈ −154° → ωc ≈ 11 rad/s, PM ≈ 26°
 K = 10: +20 dB → cruza com fase ≈ −173° → ωc ≈ 32 rad/s, PM ≈ 7° (quase instável!)

 LEITURA DE PM NA CARTA: PM = 180° + fase no cruzamento de 0 dB
 LEITURA DE Mr: o MAIOR lugar de |T| que a curva TANGENCIA
```

**Atividade (5 min):** "Na carta projetada: se a curva tangencia o lugar de 6 dB e cruza 0 dB com fase −140°, quais são Mr, PM e a estimativa de Mp?" → Mr = 6 dB ≈ 2 → ξ ≈ 0,26; PM = 40° → ξ ≈ 0,40 (duas estimativas; discutir a diferença).

**Fala:** "A carta é um 'conversor de malha': malha aberta entra como curva, malha fechada sai como leitura. E o ajuste de ganho virou arrastar transparência — foi assim que se projetou por décadas, e é assim que se ENTENDE o que o ganho faz até hoje."

---

## Q3 — O kit de tradução completo e seus limites (25 min)

**Quadro (exemplo-âncora — projetar fig `m3_fig11_nb_mr_wc.png`):**

```
ÂNCORA: G = 2,4/[s(s+1,2)]  →  T = 2,4/(s² + 1,2s + 2,4)
 na carta: a curva TANGENCIA o lugar de 3 dB → Mr = 3 dB = 1,41
 1,41 = 1/(2ξ√(1−ξ²)) → 8ξ⁴ − 8ξ² + 1 = 0 → ξ = 0,38 (a outra raiz, 0,92, fora da faixa)
 Mp = e^(−π·0,38/√(1−0,38²)) ≈ 0,27
 no zoom: ωr ≈ ωc ≈ 1,3 rad/s ≈ ωn
 tr = (π − arccos 0,38)/(1,3·√(1−0,38²)) ≈ 1,5 s
 SIMULAÇÃO: Mp = 26,7 % (previsto 27 %!), tr = 1,38 s ✓

 ★ KIT DE TRADUÇÃO (emoldurar):
 ξ ← PM ≈ 100ξ  (caminho 1)   ou   ξ ← Mr = 1/(2ξ√(1−ξ²))  (caminho 2)
 ωn ≈ ωr ≈ ωc
 e daí: Mp, tr, tp, ts pelas fórmulas do M01
```

**Quadro (★ conteúdo novo V3 — projetar fig `m3_fig12_extensao_relacoes.png`):**

```
ATÉ ONDE VÃO AS TRADUÇÕES? (testar onde "não deveria" valer)

 TESTE 1 — 2ª ordem tipo 0: G = 3/[(s+0,02)(s+1)]
 Bode: ωc = 1,6, PM = 33° → ξ ≈ 0,33, ωn ≈ 1,6 → Mp ≈ 33 %, tr ≈ 1,2 s
 simulado: Mp = 38,1 %, tr = 1,13 s ✓ (bom!)
 (na carta: entre 3 e 6 dB → Mr ≈ 5 dB → ξ ≈ 0,3 → Mp ≈ 37 % — coerente!)

 TESTE 2 — 3ª ordem: G = 60/[(s+0,02)(s+1)(s+15)]
 Bode: ωc = 1,9, PM = 22° → ξ ≈ 0,22 → Mp ≈ 49 %, tr ≈ 1 s
 simulado: Mp = 54,5 %, tr = 0,97 s ✓ (razoável!)

 ★ REGRA CARIMBADA: PM ≈ 100ξ, Mr ↔ ξ e ωn ≈ ωc valem,
   COM CUIDADO, para QUALQUER sistema
   preço: folga de 5–10° na PM + SEMPRE conferir por simulação
```

**Fala:** "Este é o coração da semana: dois caminhos independentes para ler o amortecimento de um gráfico — e a constatação honesta de que eles funcionam além dos limites da dedução, desde que a gente cobre o seguro: folga na PM e simulação antes de entregar."

---

## Q4 — Projeto com requisito de sobressinal (20 min)

**Quadro (projetar fig `m3_fig13_projeto_3a_mp.png`):**

```
PROBLEMA: G = 60/[(s+0,02)(s+1)(s+15)]  (Mp atual = 54 %)
REQUISITO: Mp < 30 %

 1. Mp = 30 % → ξ = 0,36; folga: ξ = 0,40 (Mp = 25 %) → PM alvo = 40 + 5 = 45°
    → fase alvo = −135°
 2. no Bode: fase = −135° em ω = 0,9 rad/s, onde |G| = 9,9 dB
 3. K = −9,9 dB ≈ 0,32
 4. previsão: Mp ≈ 25 %; tr ≈ (π − arccos 0,45)/(0,9·√(1−0,45²)) ≈ 2,5 s

 SIMULAÇÃO (K = 0,32): Mp = 24,4 % ✓ (previsto 25 %!)   tr = 2,0 s
 (a estimativa de ωn foi a mais frouxa — previsto 2,5 s; mesmo assim útil)
```

**Fala:** "Reparem no fluxo: requisito no tempo → tradução para a frequência → ajuste de UM número (o ganho) → conferência no tempo. O requisito de overshoot vira requisito de PM, e a receita de ontem (§3.1.10) vale para 3ª ordem."

---

## Q5 — Projeto com requisito de velocidade e o limite do ganho puro (20 min)

**Quadro (projetar fig `m3_fig14_projeto_wn.png`):**

```
PROBLEMA: G = 0,005/[(s+0,03)(s+0,1)(s+0,5)]
 com K = 1: Mp = 17,8 %, tp = 34,2 s
REQUISITO: tp ≤ 25 s  (velocidade! a tradução é por ωn)

 1. tp = π/ωd ≤ 25 → ωd ≥ 0,126 → escolher ωn = 0,13 rad/s
 2. novo cruzamento em ωc = 0,13: |G(j0,13)| = −7,3 dB → K = +7,3 dB ≈ 2,3
 3. nessa ω: fase = −144° → PM = 36° → ξ ≈ 0,35
    confere: ωd = 0,13·√(1−0,35²) = 0,12 (≈ pedido)   Mp previsto ≈ 31 %

 SIMULAÇÃO (K = 2,3): tp = 23,1 s ✓ (< 25 s)   Mp = 40,8 % — bem acima do previsto!
```

**Quadro (a moral — preparar a ponte para a semana 13):**

```
O LIMITE DO GANHO PURO:
 um botão só (o cruzamento) — requisitos COMPATÍVEIS: tudo bem
 Mp E velocidade SIMULTÂNEOS e apertados: GANHO NÃO BASTA
 → precisamos REMODELAR a curva: compensadores de avanço e atraso (§3.4)
 e depois PD/PI/PID (§3.5)
 as estimativas também pioram em 3ª ordem → SEMPRE simular
```

**Fala de fechamento:** "Hoje o ganho puro encontrou seu teto: atendeu o tp, mas o overshoot saiu do controle — porque um único botão não controla duas variáveis. Semana que vem ganhamos os botões que faltam: avanço para o transitório, atraso para o regime. No lab 11, vocês recriam a carta, medem Mr e refazem os dois projetos de hoje com as próprias mãos."

---
