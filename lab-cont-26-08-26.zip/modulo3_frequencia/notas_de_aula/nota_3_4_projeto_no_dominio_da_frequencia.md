# Nota de Aula 3.4 — Projeto de Controladores no Domínio da Frequência

> **Documento do professor** — guia de quadro, pronto para transcrição linha a linha, com falas sugeridas.
> Duração prevista: 2 h (semana 13). Lab associado: **Lab 13**.

**Mapa dos vídeos deste tópico (não mostrar aos alunos):**

| Vídeo | Título | Uso na aula |
|---|---|---|
| 01 | Efeito de acrescentar um zero no Bode | Zero: +20 dB/déc, fase 0°→+90°; impróprio! (Q1) |
| 02 | Efeito de acrescentar um polo no Bode | Polo: efeito oposto; par é próprio (Q1) |
| 03 | Efeito de zero e depois polo | Avanço de fase; ωmáx = média geométrica (Q1) |
| 04 | Fórmulas do avanço | Dedução: sen φmáx = (1−α)/(1+α); ganho 1/√α (Q2) |
| 05 | Ajustando ωc e PM com avanço | A receita de 6 passos (Q2) |
| 06 | Exemplo de projeto de avanço | ÂNCORA: G=0,005/[s(s+0,05)], C=2,1(12s+1)/(6,5s+1) (Q3) |
| 07 | Ajustando a constante de erro | Atraso: G=10/[(s+1)(s+2)], C=(s+0,61)/(s+0,27) (Q4) |
| 08 | Projeto de avanço e atraso | ÂNCORA: G=1/[(s+5)(s+10)], C1 e C2 (Q5) |
| 09 | Avanço e atraso na carta de Nichols-Black | Síntese visual: avanço no meio, atraso nas baixas (Q5) |

**⚠ Erratas de transcrição já corrigidas no material:** v07: "p = −2,27" → **−0,27** (= ωc/10 com ωc ≈ 2,76); v08: "ωc/20" → **ωc/200** e C₂ está invertido na legenda — o correto (pela regra z = 2p do próprio vídeo e pela simulação) é **C₂ = (s+0,28)/(s+0,14)**.

---

## Q1 — Os tijolos: zero, polo e o par zero-polo (25 min)

**Quadro (projetar figs `m3_fig24`, `m3_fig25`, `m3_fig26`):**

```
TIJOLO 1 — ZERO: Gn(s)(s−z1), z1 < 0
 módulo: +20log|z1| em baixas; +20 dB/déc após |z1|
 fase: 0° → +90° (reta de |z1|/5 a 5|z1|; +45° em |z1|)
   equação da reta: φ = 90°·log(5ω/|z1|)/log 25
 → AUMENTA A PM onde a quebra estiver! MAS: zero puro = IMPRÓPRIO (não realizável)

TIJOLO 2 — POLO: Gn(s)/(s−p1) — efeito oposto (−20 dB/déc; 0° → −90°)
 zero e polo na MESMA frequência se cancelam (sem vantagem)
 polo, ou par zero-polo = PRÓPRIO → realizável

TIJOLO 3 — PAR com |z1| < |p1| (zero ANTES do polo): AVANÇO DE FASE
 módulo: custa 20log(|z1|/|p1|) em baixas; sobe +20 dB/déc; estaciona em 0 dB
 fase: "morro" com MÁXIMO NA MÉDIA GEOMÉTRICA:
 ★ ωmáx = √(|z1|·|p1|)   (média aritmética no eixo log!)
 quebras longe → pico ≈ +90°; perto → pico menor
```

**Fala:** "O ganho puro tinha um botão só. Agora temos dois tijolos de dinâmica: o zero adianta a fase (mas sozinho não existe no mundo real), o polo atrasa (mas torna o par realizável). A jogada é o par com o zero ANTES do polo: um morro de fase que posicionamos onde quisermos — o avanço de fase."

---

## Q2 — As fórmulas do avanço e a receita de 6 passos (25 min)

**Quadro (dedução — conduzir; projetar fig `m3_fig27_avanco_formulas.png`):**

```
PARAMETRIZAÇÃO: Ca(s) = (Ts+1)/(αTs+1), α < 1 (z1 = −1/T, p1 = −1/(αT))
 fase exata: φ(ω) = arctg(Tω) − arctg(αTω)
 máximo em ωmáx = 1/(T√α)  (derivar e conferir!)
 substituindo + tg(a−b): tg φmáx = (1/√α − √α)/2
 com cos φ = √(1−sen²φ):
 ★ sen φmáx = (1−α)/(1+α)   ⇔   α = (1−sen φmáx)/(1+sen φmáx)
 ganho do compensador no pico: |Ca(jωmáx)| = 1/√α  (−10log α dB)
   (o par "de brinde" LEVANTA o módulo onde adianta a fase — contabilizar no K!)
```

**Quadro (a receita — emoldurar):**

```
RECEITA DO AVANÇO (6 passos):
 1. traduzir requisitos → PM e ωc alvos (PM ≈ 100ξ + 5–10° de folga; ωn ≈ ωc)
 2. medir no Bode: fase e |G| em ωc → PM atual
 3. PM atual já basta? → SÓ GANHO ("se dá com o mais simples, por que complicar?")
 4. φmáx = PMdesejada − ∠G(jωc) − 180° ; α = (1−sen φmáx)/(1+sen φmáx)
 5. T = 1/(ωc·√α)  (pico em ωc)
 6. K = √α/|G(jωc)|   ou   KdB = 10log α − |G(jωc)|dB
 depois: SIMULAR E CONFERIR (e iterar se preciso)
```

**Fala:** "A receita é mecânica de propósito: os passos 1–2 traduzem e medem, o 3 evita trabalho desnecessário, o 4 calcula a fase que falta, o 5 posiciona o morro e o 6 paga a conta do módulo. Se decorarem uma coisa: o pico do avanço vai EM CIMA do cruzamento desejado."

---

## Q3 — Exemplo-âncora de avanço (20 min)

**Quadro (resolver TODO no quadro; projetar fig `m3_fig28_projeto_avanco.png`):**

```
PLANTA: G = 0,005/[s(s+0,05)]    REQUISITOS: tr ≤ 18 s, Mp ≤ 30 %

1. tradução: Mp = 30 % → ξ = 0,358 → usar ξ = 0,35: PM ≥ 35°; folga +5° → PM = 40°
   tr = (π−arccos 0,35)/(ωn√(1−0,35²)) ≤ 18 → ωn ≥ 0,11 → ωc = 0,11 rad/s
2. medida em 0,11: |G| ≈ −9,2 dB (0,35), fase ≈ −157° → PM atual = 23° ✗
   (só ganho não resolve: cruzar em 0,11 mantém PM = 23°)
3. φmáx = 40 + 157 − 180 = 17° → α = (1−sen17°)/(1+sen17°) = 0,54
4. T = 1/(0,11·√0,54) = 12   (αT = 6,5)
5. KdB = 10log(0,54) − (−9,2) = −2,7 + 9,2 = 6,5 dB → K = 2,1

 ★ C(s) = 2,1·(12s+1)/(6,5s+1)

CONFERÊNCIA: ωc = 0,115, PM = 40,9° ✓
 simulação MF: Mp = 29,6 % ✓ (≤ 30 %)   tr = 15,5 s ✓ (≤ 18 s)
 (guardar este compensador: ele volta na semana 14, comparado com o PD)
```

**Fala:** "Aprovado de primeira. Reparem que o projeto inteiro usou duas leituras do Bode da planta — se a planta fosse uma caixa-preta, essas leituras viriam do ensaio com senoides. A receita não muda uma vírgula."

---

## Q4 — Atraso de fase: erro em regime sem estragar o transitório (25 min)

**Quadro:**

```
PROBLEMA INVERSO: transitório BOM (ωc e PM certos), erro em regime RUIM
 erro ↔ ganho DC — subir com K levanta a curva TODA (destrói ωc e PM)

A JOGADA: inverter o par — |p| < |z| (polo ANTES do zero)
 módulo: GANHA 20log(z/p) em baixas (ganho DC × z/p!); depois do zero, volta a 0
 fase: cai entre as quebras e RETORNA a 0° (uns 5× acima da quebra do zero)
 nome: ATRASO DE FASE — efeito colateral: come alguns graus de PM
 ★ REGRA: polo em ωc/10 (ou ωc/20, ωc/200 para perturbar ainda menos)

EXEMPLO-ÂNCORA (projetar fig m3_fig29): G = 10/[(s+1)(s+2)] (tipo 0)
 kp = 5 → ess = 1/6 = 16,7 %   REQUISITO: ess ≤ 10 %
 1. folga: projetar para a METADE: ess = 1/12 = 8,3 % → kpc = 11 → z/p = 11/5 = 2,2
 2. Bode: ωc = 2,76 → p = −ωc/10 = −0,27 ; z = 2,2·0,27 = 0,61
 ★ C(s) = (s+0,61)/(s+0,27)
 3. simulação: ess 0,167 → 0,081 (metade ✓); Mp 22,1 % → 22,7 %; tr 0,65 → 0,67 s
    o transitório QUASE NÃO SENTIU
```

**Fala:** "Decorem a diferença de filosofia: no avanço, escolhemos onde o compensador AGE (o pico vai para ωc); no atraso, escolhemos onde ele NÃO age (quebras longe de ωc) — ele trabalha nas baixas frequências. Avanço = transitório; atraso = regime."

---

## Q5 — Projeto completo avanço + atraso e a síntese na carta (25 min)

**Quadro (projetar fig `m3_fig30_projeto_avanco_atraso.png`):**

```
PLANTA: G = 1/[(s+5)(s+10)]
REQUISITOS: Mp < 10 %, tr ≤ 0,1 s, ess ≤ 0,05  (o caso que o ganho puro não resolve)

ETAPA 1 — AVANÇO (transitório):
 Mp = 10 % → ξ = 0,59 → PM ≥ 59° ; tr ≤ 0,1 → ωn ≥ 27 → ωc = 27 rad/s
 em 27: fase = −149,2° (PM atual 31°), |G| = −58,0 dB
 faltam 28° + 5° PREVENDO O ATRASO → φ = 33° → α = 0,30
 T = 1/(27√0,3) = 0,07 (αT = 0,021); KdB = −5,3 + 58,0 = 52,5 → K = 420
 C1(s) = 420·(0,07s+1)/(0,021s+1)

ETAPA 2 — ATRASO (regime):
 com C1: kp = 420/50 = 8,4 → ess = 1/9,4 = 10,6 % ✗ (requisito: 5 %)
 ess = 0,05 = 1/20 → kp = 19 → razão ≈ 2 → z/p = 2
 p = −ωc/200 = −0,14 ; z = 2p = −0,28
 C2(s) = (s+0,28)/(s+0,14)
 ★ C(s) = C1(s)·C2(s)

CONFERÊNCIA (simulação): Mp = 7,4 % ✓   tr = 0,075 s ✓   ess = 0,060 ≈ 5 % ✓
```

**Quadro (síntese — projetar fig `m3_fig31_avanco_atraso_nb.png`):**

```
AS 3 CURVAS NA CARTA (a história inteira numa figura):
 azul (G): nem cruza 0 dB → lento e com erro grande
 verde (C1G): PM ≈ 60°, ωc ≈ 27 — mas erro inadequado
 vermelha (C1C2G): levantou SÓ as baixas; perto do cruzamento, verde ≡ vermelha
 ★ RESUMO: avanço mexe no MEIO (PM/ωc = transitório)
           atraso mexe nas BAIXAS (ganho DC = regime)
```

**Fala de fechamento:** "Três requisitos, três ✓ — e o segredo foi a divisão de trabalho: o avanço cuidou do meio da curva, o atraso das baixas, e os 5° de previsão pagaram o pedágio do atraso. No lab 13 vocês repetem os três projetos de hoje. Semana que vem, o capítulo final: PD, PI e PID na frequência — inclusive a verdade inconveniente sobre o sinal de controle do PD."

---
