# Nota de Aula 3.3 — Diagrama de Nyquist e Atraso de Transporte

> **Documento do professor** — guia de quadro, pronto para transcrição linha a linha, com falas sugeridas.
> Duração prevista: 2 h (semana 12). Lab associado: **Lab 12**.

**Mapa dos vídeos deste tópico (não mostrar aos alunos):**

| Vídeo | Título | Uso na aula |
|---|---|---|
| 01 | O diagrama de Nyquist (coordenadas polares) | Polar de 10/[(s+1)(s+10)] com os pontos-tabela (Q1) |
| 02 | O princípio do argumento | Vetores α, β; zero dentro: +360°; polo: −360°; N = Z − P (Q1) |
| 03 | O contorno de Nyquist e o critério | Contorno horário + indentação; 1+KG; Z = N + P (Q2) |
| 04 | Nyquist a partir do Bode | Simetria G(−jω) = conj(G); semicircunferência ∞ → origem (Q2) |
| 05 | Esboço do Nyquist a partir da FT | 3 exemplos: 1/(s+1); 1/(s−1) (ganho mínimo!); 1/[s(s+1)(s+2)] (K < 6) (Q3) |
| 06 | A margem de ganho no Nyquist | Caso paramétrico com zero e polo instável: margens inferior e superior (Q3) |
| 07 | Atraso de transporte: modelagem | y = u(t−δ) → G = Gn·e^(−δs); \|e^(−jδω)\| = 1, ∠ = −δω (Q4) |
| 08 | Efeito do atraso no Bode e no desempenho | Âncora: 4/[(s+0,1)(s+1)]·e^(−0,2s): PM 31° → 10°, Mp 41 % → 79 % (Q4) |
| 09 | ★ NOVO V3 — atraso no diagrama de Nyquist | Espiral infinita; instabilização para K grande (Q5) |

**⚠ Erratas de transcrição já corrigidas no material:** v03: o final embaralha N/M — a convenção oficial é Z = N + P (início do próprio vídeo); v05: passagem truncada sobre K₂ < 0 — o resultado final (0 < K < 1/R) está correto.

---

## Q1 — O diagrama polar e o princípio do argumento (30 min)

**Quadro (projetar fig `m3_fig15_polar.png`):**

```
3ª REPRESENTAÇÃO: DIAGRAMA POLAR — G(jω) no plano complexo, ω: 0 → ∞
 raio = |G(jω)| (LINEAR, sem dB!)   ângulo = ∠G(jω)

 ex.: G = 10/[(s+1)(s+10)]
 ω = 0: (1; 0°) | ω = 1: 0,70/−50,7° | ω = 3: 0,30/−88,3°
 ω = 10: 0,07/−129,3° | ω = 100: 0,001/−173,7° | ω→∞: origem por −180°

 para quê mais uma representação? → sustenta o critério de estabilidade
 mais geral do curso: responde "para que FAIXAS de ganho a MF é estável?"
 (mesmo com planta instável — onde Bode e Routh tropeçam)
```

**Quadro (princípio do argumento — projetar fig `m3_fig16_principio_argumento.png`; desenhar os vetores no quadro):**

```
G(s) = K(s−z1)/[(s−p1)(s−p2)] ; γ = contorno fechado (sem passar por raízes)
 ∠G(s) = ∠K + α1 − β1 − β2   (ângulos dos vetores das raízes até s)

 dando 1 volta por γ:
 raiz FORA: ângulo oscila e volta ao valor inicial → contribuição 0
 ZERO DENTRO: +360° (volta no MESMO sentido do contorno)
 POLO DENTRO: −360° (sentido contrário)

 ★ PRINCÍPIO DO ARGUMENTO: N = Z − P
 N = voltas do mapa de γ em torno da origem (no sentido do contorno)
 contar VOLTAS = contar RAÍZES dentro do contorno (sem resolver equação!)
```

**Fala:** "Decorem a regra de sinais: zero soma volta, polo subtrai. Intuição: o vetor de uma raiz cercada pelo contorno é arrastado numa volta completa quando o ponto s dá a volta — o de uma raiz de fora só 'balança' e volta. Com isso, contar voltas no desenho substitui resolver polinômios."

---

## Q2 — O contorno e o critério de Nyquist (25 min)

**Quadro (projetar fig `m3_fig17_contorno_nyquist.png`):**

```
CONTORNO DE NYQUIST: abraça o semiplano direito INTEIRO
 eixo imaginário (−j∞ → +j∞) + semicircunferência R → ∞ — sentido HORÁRIO
 POLO NA ORIGEM (tipo 1): está SOBRE o contorno → INDENTAÇÃO r → 0 pela direita

aplicar o princípio a 1 + KG:
 zeros de 1+KG = polos de MALHA FECHADA (denG + K·numG = 0)
 polos de 1+KG = polos de MALHA ABERTA
 voltas de 1+KG em torno de 0 = voltas de KG em torno de −1 = voltas de G em torno de −1/K

 ★ CRITÉRIO DE NYQUIST (emoldurar): Z = N + P
 Z = polos de MF no SPD (queremos Z = 0)
 P = polos de MA no SPD (conhecido — olhar a FT)
 N = voltas HORÁRIAS de G(jω) em torno de −1/K (anti-horária = −1)
 com P polos instáveis de MA, precisamos de P voltas ANTI-HORÁRIAS
```

**Quadro (montagem do diagrama completo):**

```
DO BODE AO NYQUIST COMPLETO:
 1. traçar o polar (ω: 0 → +∞)
 2. REFLETIR no eixo real: G(−jω) = conj(G(jω)) (coeficientes reais)
 3. semicircunferência ∞:
    estritamente própria → mapeia na ORIGEM (ângulo (gnum−gden)·90°)
    própria (graus iguais) → ponto finito no eixo real

 ex.: G = 10/[(s+1)(s+10)] (projetar fig m3_fig18)
 polar + reflexão: não circunda −1/K para nenhum K > 0 → N = 0, P = 0 → Z = 0
 estável ∀K > 0 ✓ (o LGR do M02 concorda)
```

**Fala:** "O critério se resume a uma contagem: Z = N + P. O P a gente lê na função de transferência; o N a gente CONTA no desenho; e o Z tem que ser zero. Reparem na elegância: a pergunta 'é estável?' vira geometria."

---

## Q3 — Análise de estabilidade: três exemplos e as duas margens de ganho (30 min)

**Quadro (projetar fig `m3_fig19_nyquist_estabilidade.png`; esboçar os três no quadro):**

```
EXEMPLO 1: G = 1/(s+1) — semicírculo no SPE do plano-G
 nunca circunda −1/K → estável ∀K > 0

EXEMPLO 2 (planta instável!): G = 1/(s−1), P = 1
 G(0) = −1; fase −180° → −90°: semicírculo no SPE esquerdo
 K > 1: −1/K entre −1 e 0 → 1 volta ANTI-HORÁRIA → N = −1 → Z = 0 ✓ ESTÁVEL
 K < 1: −1/K à esquerda de −1 → N = 0 → Z = 1 ✗
 ★ MORAL: planta instável de 1ª ordem exige GANHO MÍNIMO (K > |p1|)!
 (a intuição "ganho menor = mais seguro" FALHA aqui)

EXEMPLO 3 (tipo 1 — entra a indentação): G = 1/[s(s+1)(s+2)]
 indentação r → 0 mapeia em semicircunferência de raio ∞ (+90° → −90°)
 polar: −90° → −270°, cruza o eixo real onde a fase é −180°:
   −90° − arctg ω − arctg(ω/2) = −180° → ω = √2, |G| = 1/6
 0 < K < 6: −1/K à esquerda de −1/6 → N = 0 → Z = 0 ✓
 K > 6: dentro do laço → 2 voltas horárias → Z = 2 ✗
 → estável para 0 < K < 6 = ROUTH (s³+3s²+2s+K: K < 6) — duas ferramentas, mesma resposta
```

**Quadro (margens de ganho — projetar fig `m3_fig20_nyquist_margem_inferior.png`):**

```
MARGEM DE GANHO NO NYQUIST — existe limite INFERIOR!
 ex.: G = (s+2)/[(s+1)(s−5)]  (P = 1, G(0) = −0,4)
 fase: −180° → abaixo de −180° → volta a −180° (efeito do zero) → −90°
 DOIS cruzamentos do eixo real negativo: −0,4 (ω = 0) e −R = −0,25 (ω = √3)
 estável ⇔ N = −1 ⇔ 0 < 1/K < R ⇔ K > 1/R = 4
 (Routh confirma: s² + (K−4)s + (2K−5) → K > 4 ✓)
 para K na faixa estável: GM SUPERIOR = ∞; GM INFERIOR = 1/(RK)
 o Bode clássico só enxerga a superior; o Nyquist enxerga as DUAS
```

**Fala:** "Três lições para guardar: planta instável pode exigir ganho mínimo; tipo 1 traz a indentação e o raio infinito; e 'margem de ganho' pode ter PISO além de teto. E um aviso prático: os programas traçam Nyquist com escalas terríveis — quem sabe o formato esperado interpreta o gráfico; quem não sabe, vê um borrão."

---

## Q4 — Atraso de transporte: modelagem e efeito no Bode (20 min)

**Quadro:**

```
ATRASO DE TRANSPORTE: y(t) = u(t − δ) → Laplace: G(s) = Gn(s)·e^(−δs)
 no M02: aproximação de Padé (racional). NA FREQUÊNCIA: EXATO e simples:
 ★ |e^(−jδω)| = 1   (módulo INALTERADO — nem 1 dB)
 ★ ∠e^(−jδω) = −δω  (fase cai LINEARMENTE com ω — no eixo log, queda sem fim)

EXEMPLO-ÂNCORA (projetar figs m3_fig21 e m3_fig23):
 G = 4/[(s+0,1)(s+1)]·e^(−0,2s)
 sem atraso: ωc = 1,9, PM = 31° → ξ ≈ 0,31 → simulado: Mp = 41,2 %, tr = 0,95 s
 com atraso: ωc inalterado; fase cai δωc = 0,2·1,9 = 0,38 rad ≈ 22°
   → PM ≈ 9,6° → ξ ≈ 0,10 → previsto Mp ≈ 73 %
   simulado (Padé ordem 8): Mp = 78,8 %, tr = 1,05 s — o atraso QUASE DUPLICOU o overshoot
 remédio imediato: REDUZIR O GANHO (ωc ↓ → δωc ↓ → PM ↑) — ao custo de velocidade
```

**Fala:** "Uma frase para a vida: o atraso COME FASE e não come módulo — e fase é a moeda da estabilidade. Redes, transporte de material, tempo de cálculo digital: todo mundo carrega atraso. Por isso ele é uma das preocupações centrais do engenheiro de controle."

---

## Q5 — O atraso no Nyquist: a espiral (15 min)

**Quadro (projetar fig `m3_fig22_atraso_nyquist.png` GRANDE):**

```
Gn = 4/[(s+0,1)(s+1)]: fase 0° → −180°
 → Nyquist NUNCA cruza o eixo real negativo → ESTÁVEL ∀K > 0 (GM = ∞!)

com atraso e^(−0,2s): fase = ∠Gn − 0,2ω → DECRESCE SEM LIMITE
 módulo continua indo a zero → ESPIRAL COM INFINITAS VOLTAS
 onde não havia cruzamento, agora há INFINITOS

 consequência: aumentando K, em algum ponto −1/K é "engolido" por uma volta
 → 2 polos de MF no SPD (depois 4, 6, ... ∞)
 ★ o sistema estável para QUALQUER ganho é DESestabilizado por K grande
```

**Fala de fechamento:** "Fechem os olhos e guardem a espiral. Ela explica por que sistemas com atraso têm ganho máximo mesmo quando 'não deveriam' — e por que o atraso não é 'um polo a mais': é um termo transcendental com infinitas raízes escondidas. No lab 12 vocês vão gerar essa espiral e medir exatamente onde ela cruza. Semana que vem: avanço e atraso de fase — os compensadores que remodelam a curva."

---
