# Nota de Aula 3.5 — Controladores PD, PI e PID no Domínio da Frequência

> **Documento do professor** — guia de quadro, pronto para transcrição linha a linha, com falas sugeridas.
> Duração prevista: 2 h (semana 14). Lab associado: **Lab 14**.

**Mapa dos vídeos deste tópico (não mostrar aos alunos):**

| Vídeo | Título | Uso na aula |
|---|---|---|
| 01 | O controlador PD no domínio da frequência | Fórmulas diretas kp, kd; polo em 100·ωc; PD = avanço com polo no ∞ (Q1) |
| 02 | Uma consequência ruim do PD: sinais com variação abrupta | ÂNCORA: PD × avanço no mesmo problema; sinal de controle (Q2) |
| 03 | O controlador PI no domínio da frequência | PI = atraso com polo em 0; ess = 0; regra \|z1\| ≤ ωc/10 (Q3) |
| 04 | O controlador PID no domínio da frequência | ÂNCORA: projeto completo, G=0,01/[(s+0,05)(s+0,07)] (Q4) |
| 05 | Visualizando PD, PI e PID na carta de Nichols-Black | Síntese final: as 4 curvas (Q5) |

**⚠ Notas de transcrição já corrigidas no material:** v02: o pico do sinal de controle do PD é **≈ 215×** o do avanço (a fala diz "cerca de 20 vezes"; a simulação — que vale — dá 836 vs 3,9); v04/v05: o zero do PI é z1 = −0,018 → o fator é **(s + 0,018)/s** (a legenda escreve "s menos 0,018", na nossa notação C = (s−z1)/s).

---

## Q1 — O PD na frequência: fórmulas diretas (25 min)

**Quadro (deduzir as fórmulas — projetar fig `m3_fig32_pd_bode.png`):**

```
um zero puro já adianta a fase onde queremos → o mais simples:
 C(s) = kp + kd·s = kp(1 + (kd/kp)s)   (PD = proporcional + derivada do erro)

PROJETO (dedução): PM e ωc alvos; φ = PMdesejada − ∠G(jωc) − 180° (fase que falta)
 1. fase do PD em ωc: ∠C(jωc) = arctg(kd·ωc/kp) = φ
    → kd/kp = tg φ/ωc   (zero em z1 = −kp/kd = −ωc/tg φ)
 2. |C(jωc)| = √(kp² + kd²ωc²) = 1/|G(jωc)| ; dividindo e usando 1+tg²φ = 1/cos²φ:
 ★ FÓRMULAS DIRETAS (emoldurar):
   kp = cos φ/|G(jωc)|        kd = sen φ/(ωc·|G(jωc)|)

PROBLEMA: PD ideal é IMPRÓPRIO
 comparando com o avanço: α → 0 ⇒ polo −1/(αT) → −∞ ⇒ avanço degenera em PD
 ★ PD = AVANÇO COM O POLO NO INFINITO
 solução-padrão: polo de filtragem em p1 = −100·ωc
   C'(s) = (kp + kd·s)/(s/p1 + 1)
 custo em ωc = p1/100: módulo ≈ 1, fase ≈ −arctg(0,01) ≈ −0,6° (desprezível)
```

**Fala:** "As fórmulas diretas são um presente: dados φ, ωc e uma leitura de |G(jωc)|, os ganhos saem em duas linhas. E a leitura geométrica liga os mundos: PD é o avanço com o polo no infinito — o polo de filtragem é o infinito 'trazido para perto' o suficiente para ser construído."

---

## Q2 — O lado sombrio do PD: sinais abruptos (25 min)

**Quadro (refazer o problema do avanço com PD — projetar fig `m3_fig33_pd_x_avanco.png` GRANDE):**

```
MESMO PROBLEMA DO AVANÇO (semana 13): G = 0,005/[s(s+0,05)]
 Mp ≤ 30 %, tr ≤ 18 s → PM = 40°, ωc = 0,11, |G(jωc)| = 0,35, φ = 17°

 kp = cos17°/0,35 = 2,7     kd = sen17°/(0,11·0,35) = 7,6     p1 = −110
 C'(s) = (2,7 + 7,6s)/(s/110 + 1)

SIMULAÇÃO: Mp = 29,3 %, tr = 15,1 s — PRATICAMENTE IDÊNTICOS ao avanço
 (avanço: Mp = 29,6 %, tr = 15,5 s — as curvas se confundem no gráfico)

MAS... o SINAL DE CONTROLE u(t) (a tensão injetada na planta):
 avanço: pico de 3,9
 PD:     pico de 836  →  ★ ≈ 215 VEZES MAIOR!
 por quê? derivada do degrau ≈ IMPULSO — passa pelo termo kd·s
 o polo limita (sem ele: infinito), mas 7,6 × 110 continua grande demais
 → atuador SATURA (e o projeto linear deixa de valer) ou nem consegue aplicar

 ★ REGRA PRÁTICA: PD (e o D do PID) COM PARCIMÔNIA quando a referência
   muda abruptamente; na indústria, o D costuma atuar sobre a SAÍDA MEDIDA
   (suave), não sobre o erro; e muitas vezes o AVANÇO vale o trabalho extra
```

**Fala:** "Mesmo desempenho na saída, esforço de controle brutalmente diferente. O PD olha para a referência nova e dá um 'chute' de 836 volts; o avanço, com as mesmas respostas, chuta 4. É por isso que a frase do laboratório é: crianças, não tentem isso em casa — e por isso que o avanço de fase, com seus α e T trabalhosos, continua vivo."

---

## Q3 — O PI na frequência: o atraso com polo em zero (20 min)

**Quadro (projetar fig `m3_fig34_pi_bode.png`):**

```
PD = avanço com o polo no ∞. E o ATRASO LIMITE? Levar o polo do par para ZERO:
 C(s) = (s−z1)/s = kp(s−z1)/s = kp − kp·z1/s = kp + ki/s   (ki = −kp·z1)
 ★ PI = ATRASO DE FASE COM O POLO EM ZERO
 novidade: ganho DC INFINITO → tipo 1 → ess = 0 ao degrau (zero, não reduzido!)

Bode do PI: −20 dB/déc até a quebra do zero, plano depois; fase −90° → 0°
 como todo atraso: come fase perto do cruzamento → mesma regra:
 ★ |z1| = ki/kp ≤ ωc/10
```

**Fala:** "O PI é o atraso de fase levado ao limite — e o limite tem um prêmio: erro em regime exatamente zero. É o integrador trabalhando: enquanto houver erro, ele acumula ação de controle. O preço é o mesmo do atraso — alguns graus de PM — e a regra de posicionamento é idêntica."

---

## Q4 — O PID: projeto completo (30 min)

**Quadro:**

```
PID = PD (transitório, em ωc) × PI (regime, ganho infinito em baixas):
 C(s) = [(kp + kd·s)/(s/p1 + 1)] · [(s−z1)/s]
 a resposta em frequência SOMA as dos dois: PD dá a PM, kp acerta o cruzamento,
 z1 do PI fica lá embaixo (≤ ωc/10) custando só alguns graus — previstos na folga
```

**Quadro (exemplo-âncora — resolver TODO no quadro; projetar fig `m3_fig35_projeto_pid.png`):**

```
PLANTA: G = 0,01/[(s+0,05)(s+0,07)]
REQUISITOS: Mp ≤ 10 %, tr ≤ 15 s, ess = 0

1. tradução: Mp = 10 % → ξ = 0,59 → PM = 59°; folga +5° (absorve o PI) → PM = 64°
   tr ≤ 15 → ωn ≥ 0,18 → ωc = 0,18 rad/s
2. medida em 0,18: |G| = −11,2 dB (0,275); fase = −143,2° → PM atual = 36,8°
3. φ = 64 − 36,8 ≈ 28°
4. kp = cos28°/0,275 = 3,2     kd = sen28°/(0,18·0,275) = 9,5
5. polo de filtragem: p1 = −100·ωc = −180
6. zero do PI: |z1| = ωc/10 = 0,018

 ★ C(s) = [(3,2 + 9,5s)/(s/180 + 1)] · [(s + 0,018)/s]

CONFERÊNCIA: ωc = 0,181, PM = 59° (o PI custou ~5°, como previsto)
 simulação MF: Mp = 11,2 % ✓ (≈ 10 %)   tr = 11,1 s ✓   ess = 0 ✓
 TRÊS REQUISITOS, TRÊS ✓
```

**Fala:** "Reparem na economia do projeto: é o PD do Q1 mais duas decisões (o zero do PI e a folga que o cobre). E o resultado é o controlador mais usado da indústria — não por acaso: ele ataca o transitório e o regime ao mesmo tempo."

---

## Q5 — Síntese na carta e fechamento do módulo (20 min)

**Quadro (projetar fig `m3_fig36_pd_pi_pid_nb.png` GRANDE):**

```
AS 4 CURVAS NA CARTA — G = 0,01/[(s+0,05)(s+0,07)]:
 azul (G): ωc ≪ 1, PM ≈ 73° → LENTO; ganho em baixas só 9 dB → erro apreciável
 magenta (PD): PM ≈ 65°, ωc ≈ 0,18, pico ≈ 0 dB → rápido e bem amortecido
 laranja (PI): dispara para cima nas baixas (ganho → ∞, ess = 0) — mas PM CAI
 verde (PID): CONJUGA — PM quase a do PD E ganho infinito em baixas
```

**Quadro (fechamento — escrever com a turma):**

```
O QUE O MÓDULO ENTREGOU (a promessa do desafio, cumprida):
 senoides → resposta em frequência → Bode → margens
 tradução: PM ≈ 100ξ, ωn ≈ ωc (com folga de 5–10° e simulação)
 projetos SEM MODELO: P (3.1) · P com Mp/tp (3.2) · avanço/atraso (3.4)
 · PD/PI/PID (3.5) · estabilidade por Nyquist e atraso exato (3.3)
 em NENHUM passo a FT foi necessária — a tabela medida alimenta tudo

O QUE FALTA: sistemas REAIS têm não linearidades (saturação, zona morta,
 histerese...) → MÓDULO 04: quando elas destroem o projeto linear e
 quando podemos dominá-las (funções descritivas, ciclos limite, linearização)
```

**Fala de fechamento:** "Voltem à aposta da semana 10: projetar sem modelo, uma chance só. Agora vocês têm o arsenal completo — e entenderam por que, quase um século depois de Black, Nyquist e Bode, esse continua sendo o jeito que a indústria projeta controladores. No lab 14: PD, PI e PID com as próprias mãos, incluindo o sinal de controle do PD — e depois, o mundo não linear."

---
