# Slides — Aula 06: O Lugar Geométrico das Raízes (LGR)

> **Documento do professor.** Formato de cada slide: **Tela**, **Figura**, **Roteiro falado**. Vídeos de apoio à preparação: tópico 2.2, vídeos 01–12. Lab associado: **Lab 06**.

---

### Slide 1 — Abertura

**Tela:** Aula 06: O Lugar Geométrico das Raízes — o mapa de tudo que o controle P pode fazer.

**Roteiro:** "Semana passada: onde os polos devem estar. Hoje: onde eles PODEM estar. Uma ferramenta só responde — e ela é a espinha dorsal do curso."

---

### Slide 2 — Motivação: os polos andam com k

**Tela:** 1ª ordem: polo de MF = −a−k (anda no eixo real). 2ª ordem: encontro em −a/2, depois vertical. Com zero: um polo vai ao zero, outro ao infinito.

**Figura:** m2_fig10_lgr_1a_ordem.png + m2_fig11_lgr_2a_ordem.png

**Roteiro:** "Aumente o ganho e os polos de malha fechada se movem — sempre pelos mesmos caminhos. k = 0: nos polos de malha aberta. k → ∞: nos zeros ou no infinito. Esse caminho tem nome: LGR."

---

### Slide 3 — A definição

**Tela:** LGR = conjunto dos pontos que são raízes de 1 + kG(s) = 0 para algum k de 0 a ∞. Depende SÓ de G(s).

**Roteiro:** "O LGR é propriedade da planta, não do ganho. Por isso dá para esboçá-lo antes de projetar — e é por isso que ele serve para projetar."

---

### Slide 4 — Condição de ângulo

**Tela:** □ pertence ao LGR ⇔ ∠G(□) = −180°. Fase = Σ ângulos (zeros→□) − Σ ângulos (polos→□). Exemplo: 1/(s(s+6)), □ = −3+3j: 135°+45° = 180° ✓.

**Figura:** m2_fig12_condicao_angulo.png

**Roteiro:** "1 + kG = 0 significa kG = −1 — um real negativo, cuja fase é −180°. Testar um ponto é somar e subtrair ângulos de vetores. Só isso — mas use atan2, o quadrante importa."

---

### Slide 5 — Condição de módulo

**Tela:** k = (1/A)·Π dist(□→polos)/Π dist(□→zeros). Exemplos: −3+3j → k = 18; −3+4j → k = 25; −6+6j → FORA (não calcule k!).

**Figura:** m2_fig13_lgr_k18_k25.png

**Roteiro:** "Duas perguntas, duas fórmulas, sempre nessa ordem: PODE ser polo (ângulo)? COM QUAL ganho (módulo)? E o A da forma fatorada é o fermento — esqueceu, o ganho sai errado."

---

### Slide 6 — Projeto de P no plano-s

**Tela:** G = 10/(s(s+10)), Mp ≤ 5 % com menor tp: β = 46,37° → polos −5 ± 5,25j → k = 5,26 → Mp = 5,0 %, tp = 0,6 s.

**Figura:** m2_fig14_projeto_P_planos.png

**Roteiro:** "O projeto de P é a escolha de UM ponto sobre o LGR. Subir mais: pico mais rápido, overshoot furado. É um cabo de guerra sobre trilhos — o LGR são os trilhos."

---

### Slide 7 — As 8 regras de esboço (1–4)

**Tela:** 1) n ramos; 2) simetria no eixo real; 3) trechos: nº ímpar de polos+zeros reais à direita; 4) começam nos polos (k=0), terminam nos zeros ou no infinito (k→∞).

**Roteiro:** "Oito regras, zero conta de raiz. As quatro primeiras desenham o esqueleto: quantos ramos, onde estão no eixo real, de onde saem e para onde vão."

---

### Slide 8 — As 8 regras (5–8)

**Tela:** 5) assíntotas (180°+l·360°)/(n−m); 6) centroide (Σp − Σz)/(n−m); 7) cruzamento jω via Routh + auxiliar; 8) saída/entrada: d(−1/G)/ds = 0, aceitar só raízes sobre trechos.

**Roteiro:** "As quatro últimas dão o acabamento: a direção do infinito, o centro de onde elas partem, a fronteira da estabilidade e onde os polos se encontram. Routh volta aqui — ele É a fronteira."

---

### Slide 9 — Ângulo de partida

**Tela:** θ = 180° + Σ∠(zeros→p) − Σ∠(outros polos→p). Exemplo: (s+2)(s+4)/(s(s²+4)), polo +2j: θ = 71,6° → entra no SPD antes de voltar!

**Figura:** m2_fig19_angulo_partida.png

**Roteiro:** "Quando o polo de malha aberta é complexo, o ramo pode sair na direção 'errada' — inclusive para o semiplano direito. A condição de ângulo, aplicada colada no polo, dá a direção de saída."

---

### Slide 10 — Exemplo das regras 7 e 8

**Tela:** 1/((s+1)(s+2)(s+3)): Routh → k = 60, auxiliar 6s²+66 = 0 → ±j3,32; derivada → −1,42 ✓, −2,58 ✗.

**Roteiro:** "A derivada sempre cospe candidatos demais. Só valem os que caem sobre trechos do LGR — a regra 3 é a peneira."

---

### Slide 11 — Os quatro exemplos-âncora

**Tela:** A: 200/(s(s+10)(s+20)) — cruza em ±j14,1 com k = 30. B: com zero em −5 — nunca desestabiliza. C: 4ª ordem — duas saídas. D: C + zero — assíntotas mudam.

**Figura:** m2_fig15_lgr_200.png → m2_fig18_lgr_80z.png (sequência)

**Roteiro:** "Comparem A com B, C com D: o zero é ÍMÃ de ramos. Menos assíntotas, ramos puxados para a esquerda, mais estabilidade. Guardem essa intuição — semana que vem ela vira o controlador de avanço."

---

### Slide 12 — Fechamento e ponte

**Tela:** Resumo: ângulo (pertence?) + módulo (qual k?) + 8 regras (esboço). Próxima aula: deformar o LGR — avanço de fase.

**Roteiro:** "E se o LGR não passar pela região de desempenho? Não há k que resolva — o P fracassa. Solução: mudar o LGR. No Lab 06, vocês implementam ângulo e módulo e conferem os quatro exemplos."
