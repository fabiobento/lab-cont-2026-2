# Slides — Aula 08: Controlador de Atraso de Fase (e o PI)

> **Documento do professor.** Formato de cada slide: **Tela**, **Figura**, **Roteiro falado**. Vídeos de apoio à preparação: tópico 2.4, vídeos 01–06. Lab associado: **Lab 08**.

---

### Slide 1 — Abertura

**Tela:** Aula 08: Erro em regime sem destruir o transitório — o atraso de fase e o PI.

**Roteiro:** "O transitório está resolvido desde a semana passada. Hoje atacamos o outro front: o erro em regime — sem estragar o que já conseguimos."

---

### Slide 2 — O conflito erro × ganho

**Tela:** G = 10/((s+2)(s+5)): k = 8,45 (transitório ✓, erro ✗) × k = 19 (erro ✓, Mp = 44,7 % ✗). Subir o ganho MOVE os polos pelo LGR.

**Roteiro:** "Erro manda subir o ganho; o LGR pune: os polos sobem e o overshoot explode. Precisamos aumentar a constante de erro SEM mover os polos. Parece mágica — é geometria."

---

### Slide 3 — O mecanismo

**Tela:** Par polo-zero colado na origem: nos polos dominantes ≈ 1 (quase-cancelamento); em regime (s→0) = fator a/b. G = 1/(s(s+3,2)), k = 7,4 → C = 7,4(s+0,02)/(s+0,01): kv dobra, polos −1,595±2,196j (intocados) + −0,0201.

**Figura:** m2_fig26_atraso_mecanismo.png

**Roteiro:** "Lá de cima, dos polos dominantes, o par é invisível — zero em cima de polo, a borracha da semana 5. Mas em s → 0 a razão vira o fator. O transitório não sente; o erro, sim."

---

### Slide 4 — O preço: convergência lenta

**Tela:** Novo polo lento perto da origem → erro converge devagar. ess(rampa): 0,43 → 0,215.

**Figura:** m2_fig27_atraso_respostas.png

**Roteiro:** "Nada é de graça: aparece um polo lento colado no zero do atraso. O erro vai ao valor novo — mas devagar. É o preço da elegância."

---

### Slide 5 — Procedimento de projeto

**Tela:** 1) transitório primeiro; 2) fator = Kdesej/Kobtida = a/b; 3) zero em |Re(□d)|/10; 4) polo = zero/fator; 5) simule. Fatores: 2 → −1,43° → Mp 14 %; 10 → −2,55° → Mp 17 %; longe → 40 %.

**Roteiro:** "O atraso cobra pedágio: alguns graus de fase negativa. Fator grande ou par afastado: mais fase roubada, mais overshoot — mas erro converge mais rápido. Perto da origem: o contrário. Compromisso — e simulação."

---

### Slide 6 — O PI

**Tela:** C = kp + ki/s = kp(s+ki/kp)/s — atraso com o polo NA ORIGEM: fator infinito, sobe o tipo. Único que zera erro de tipo 0. "Só use PI se estritamente necessário."

**Roteiro:** "O PI é o atraso levado ao limite — e o controlador mais usado da indústria. Mas ele cobra −90° permanente de fase. Erro pequeno basta? Use atraso comum. Erro zero exigido? Aí sim, PI."

---

### Slide 7 — Projeto literal para 2ª ordem tipo 1

**Tela:** G = b/(s(s+a)), Mp = 15 % → k = a²/(1,07b), C = (a²/1,07b)(s+a/20)/(s+a/80). Variante Mp = 10 %: fator 5,3, d = a/106.

**Roteiro:** "Fizemos com letras uma vez: agora qualquer planta 2ª ordem tipo 1 é substituir valores. No lab vocês refazem com números e conferem cada passo."

---

### Slide 8 — PI para 3ª ordem tipo 0

**Tela:** G = 20/((s+1)(s+2)(s+10)): ωn = 2,46, k = 2,19, C = 2,19(s+0,123)/s → converge devagar; zero −0,73 → Mp = 16,4 % ✓.

**Figura:** m2_fig28_pi_3a_ordem.png

**Roteiro:** "Tipo 0 exigindo erro zero: só o PI. O chute do 1/10 deu convergência lenta; afastando o zero, o overshoot projetado aparece. Regra prática é chute — a simulação é o árbitro."

---

### Slide 9 — Desafio de Beakman

**Tela:** G = 20/((s−1)(s+2)(s+10)) — planta INSTÁVEL. PI com zero em −0,5: Routh → −400k²+1350k−2160 < 0 ∀k → nenhum k estabiliza!

**Figura:** m2_fig29_beakman.png

**Roteiro:** "O ramo do polo +1 fica preso no semiplano direito — Routh só confirma o que o LGR já gritava. E nem pensem que é falta de criatividade: com esse zero, não existe k. Análise ANTES de projeto. (Para os curiosos: zero em −0,123 estabiliza — mas a resposta fica horrível. Estabilidade não é desempenho.)"

---

### Slide 10 — Fechamento e ponte

**Tela:** Resumo: par colado na origem; fator; regra do 1/10; PI = último recurso. Próxima aula: tudo junto — avanço+atraso, PID e atraso de transporte.

**Roteiro:** "Temos as duas ferramentas: avanço (transitório) e atraso (regime). Semana que vem: a receita completa de 10 passos, o PID de verdade e o que fazer quando a própria física atrasa o sinal. No Lab 08, o desafio de Beakman com a prova numérica."
