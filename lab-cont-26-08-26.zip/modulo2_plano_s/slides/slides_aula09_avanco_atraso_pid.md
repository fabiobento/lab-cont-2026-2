# Slides — Aula 09: Avanço + Atraso, PID e Atraso de Transporte

> **Documento do professor.** Formato de cada slide: **Tela**, **Figura**, **Roteiro falado**. Vídeos de apoio à preparação: tópico 2.5, vídeos 01–04. Lab associado: **Lab 09**.

---

### Slide 1 — Abertura

**Tela:** Aula 09: A receita completa — avanço + atraso, PID e o atraso de transporte.

**Roteiro:** "Última aula do módulo: juntamos as duas ferramentas numa receita só, fechamos o PID e encaramos o vilão final — o tempo que a física leva para transportar o sinal."

---

### Slide 2 — A receita de bolo (10 passos)

**Tela:** 1) parâmetros de 2ª ordem; 2) □d; 3) ∠G(□d) (folga? aperte requisitos); 4) avanço ≤ 40°; 5) zero; 6) polo; 7) ganho (o A é o fermento!); 8) fator; 9) zero do atraso = |Re|/10; 10) polo + simular + ajustar.

**Roteiro:** "Bolo com cinco farinhas dá mais trabalho, não mais dificuldade — a mistura é a mesma. Planta de 5ª ordem: mais fases, mais módulos, MESMA receita. E não esqueçam do fermento: o A da forma fatorada."

---

### Slide 3 — Avanço + atraso: 1ª iteração

**Tela:** G = 200/(s(s+10)(s+20)), Mp = 16,3 %, tr = 300 ms, ess(rampa) = 0,02. □d = −4,04+7j; avanço 13,3°; cancela −10: C = 8,33(s+10)/(s+13,57)·(s+0,4)/(s+0,05) → sim: Mp = 22 % ✗.

**Roteiro:** "Seguimos a receita à risca — e o overshoot veio 22 %. Fracasso? Não: informação. O atraso roubou fase. O conserto não é mexer no atraso…"

---

### Slide 4 — 2ª iteração: a arte do projeto

**Tela:** Avanço com folga (ξ = 0,56, ωd = 7,9): avanço 31,8° → C = 13,4(s+10)/(s+20,4)·(s+0,4)/(s+0,05) → sim: Mp = 16,9 %, tr = 300 ms ✓.

**Figura:** m2_fig30_avanco_atraso.png

**Roteiro:** "…é reprojetar o AVANÇO com folga, deixando margem para o atraso roubar. Projeto de controle envolve arte — se fosse só conta, o computador fazia tudo e ninguém precisava da gente."

---

### Slide 5 — O PID

**Tela:** C = k(s+z1)(s+z2)/s = PI + PD. G = 2/((s+2)(s+5)): kp = 37,25, ki = 16,9, kd = 1,1 — e o ajuste do zero do PI: −0,46 (lento), −2 (overshoot), −1 (✓).

**Figura:** m2_fig31_pid_zeros.png

**Roteiro:** "PID é PI mais PD na mesma receita: um zero para o avanço, outro para o atraso, polo na origem. E a posição do zero do PI é o botão fino — três tentativas, três comportamentos."

---

### Slide 6 — O PID real é PI-Lead

**Tela:** C(s) = P + I/s + D·N/(1+N/s) — o derivador tem polo de filtro ⇒ PID implementado = PI + avanço.

**Roteiro:** "Nenhum CLP do mundo implementa derivador puro — pelo mesmo motivo do PD da semana 7. Quando a indústria diz PID, o que roda é um PI-Lead. Agora vocês sabem o que está dentro da caixa."

---

### Slide 7 — O atraso de transporte

**Tela:** L{x(t−τ)} = e^(−sτ)X(s). Aquecedor a gás: a água nos canos ainda está na temperatura antiga. τ = τu + τy → Ga = G·e^(−sτ).

**Roteiro:** "Sua mãe lavando louça pede +5 °C. Você ajusta — mas a água velha nos canos precisa sair primeiro. Reação química, comunicação, processamento: tudo vira o mesmo e^(−sτ)."

---

### Slide 8 — Padé e a estabilidade

**Tela:** e^(−sτ) ≈ −(s−2/τ)/(s+2/τ) — zero no SPD (fase não mínima). G = 1/(s+a): instável se k > a + 2/τ. Quanto maior o atraso, menor o k crítico.

**Figura:** m2_fig32_pade.png

**Roteiro:** "Não é aproximação de Tabajara nem do seu Creysson: é Henri Padé, e ela devolve o problema ao nosso mundo — razão de polinômios. Preço: um zero no semiplano direito. E a fronteira é exata: k = a + 2/τ — no lab vocês a reconstroem ponto a ponto."

---

### Slide 9 — O estrago e o conserto

**Tela:** G = 2/(s(s+4)), τ = 0,1, k = 10: Mp salta de 20,8 % para 48,7 %. Posição do atraso: overshoot igual, tempos diferentes.

**Roteiro:** "O mesmo ganho que dava 21 % entrega 49 % com 100 ms de atraso. E curioso: mova o atraso de lugar na malha — o overshoot não muda, os tempos sim. No lab vocês verificam as três posições."

---

### Slide 10 — Projeto compensando o atraso

**Tela:** Avanço sem atraso 13,4° + fase do atraso 24,1° = 37,5° (≤ 40° ✓) → C = 14,26(s+4)/(s+8,8) → sim: Mp = 14,3 %, tr = 0,5 s ✓.

**Figura:** m2_fig33_projeto_com_atraso.png

**Roteiro:** "O atraso rouba fase — cobramos a conta do avanço, com os 40° vigiando. Duas contas para a fase do atraso, exponencial e Padé, mesmo valor: −24,1°. Conferir pelas duas vias é higiene de engenheiro."

---

### Slide 11 — Fechamento do módulo

**Tela:** Mapa do módulo: regiões → LGR → avanço → atraso/PI → receita completa + atraso de transporte. Próximo módulo: resposta em frequência — Bode, margens, Nyquist.

**Roteiro:** "Fechamos o plano-s: vocês projetam P, PD, PI, PID, avanço, atraso e avanço-atraso — com LGR, Padé e simulação. Semana que vem, a lista 2. Depois, trocamos de óculos: do plano-s para a frequência. No Lab 09, o projeto completo com atraso."
