# Slides — Aula 05: Regiões de Desempenho no Plano-s e Aproximações

> **Documento do professor.** Formato de cada slide: **Tela** (o que aparece), **Figura** (arquivo em `imagens/`), **Roteiro falado** (o que dizer). Vídeos de apoio à preparação: tópico 2.1, vídeos 01–08. Lab associado: **Lab 05**.

---

### Slide 1 — Abertura

**Tela:** Módulo 02 · Aula 05: Onde os polos devem estar? — Regiões de desempenho no plano-s.

**Roteiro:** "No módulo 1, a pergunta era: 'dado o sistema, qual a resposta?'. Hoje ela vira do avesso: 'quero ESSA resposta — onde os polos precisam estar?'. Até o fim do módulo, tudo é geometria no plano-s."

---

### Slide 2 — Revisão relâmpago

**Tela:** Fórmulas da 2ª ordem: Mp = e^(−ξπ/√(1−ξ²))·100 %; tp = π/ωd; ts = 3/σ · 4/σ · 4,6/σ; tr(10–90 %) ≈ 1,6/ωn; tr(0–100 %) ≈ 2,4/ωn.

**Roteiro:** "Esse é o alfabeto do módulo. Duas novidades nas fórmulas de tr: as constantes 1,6 e 2,4 — e elas só valem para ξ perto de 0,5. No lab vocês vão RECRIAR o gráfico que gera essas constantes. Engenheiro não usa fórmula que não sabe de onde veio."

---

### Slide 3 — O plano-s e o mapa de polos e zeros

**Tela:** Eixo σ × jω; polo ×, zero ○; |p| = ωn; cos β = σ/ωn = ξ; FT própria × imprópria; "sistema adivinho não existe".

**Figura:** m2_fig01_mapa_polos_zeros.png

**Roteiro:** "Cada ponto do plano é um candidato a polo. Parte real manda no amortecimento, imaginária na velocidade de oscilação, módulo na frequência natural, ângulo no overshoot. Quatro leituras do mesmo ponto — decorem o desenho."

---

### Slide 4 — Overshoot vira setor

**Tela:** Mp ≤ 20 % ⇔ ξ ≥ 0,456 ⇔ β ≤ 62,9° → setor em torno do eixo real negativo.

**Figura:** m2_fig02_regiao_mp.png

**Roteiro:** "Mp só depende de ξ, e ξ é o cosseno do ângulo. Logo, requisito de overshoot é requisito de ÂNGULO: o setor. β = 0, polos reais, overshoot zero."

---

### Slide 5 — Pico e acomodação: faixa e semirreta

**Tela:** tp ≤ X ⇔ ωd ≥ π/X (faixa horizontal); ts(2 %) ≤ Y ⇔ σ ≥ 4/Y (semirreta vertical).

**Figura:** m2_fig03_regiao_tp_ts.png

**Roteiro:** "Pico só enxerga a parte imaginária; acomodação só enxerga a parte real. Cada requisito tem sua geometria — e é sempre a mais simples possível."

---

### Slide 6 — Subida: o círculo

**Tela:** tr(10–90 %) ≤ X ⇔ ωn ≥ 1,6/X; tr(0–100 %) ≤ Y ⇔ ωn ≥ 2,4/Y → fora do círculo.

**Figura:** m2_fig05_regiao_tr.png + m2_fig06_tr_aproximacoes.png

**Roteiro:** "ωn é a distância até a origem: requisito de subida é círculo. E o segundo gráfico é a honestidade das constantes: perto de ξ = 0,5, 1,6 e 2,4; longe, as curvas dependentes de ξ."

---

### Slide 7 — A região combinada

**Tela:** Interseção: β ≤ 62,9° ∩ ωd ≥ 1 ∩ σ ≥ 0,5 — exemplo Mp ≤ 20 %, tp ≤ 3,14 s, ts ≤ 8 s.

**Figura:** m2_fig04_regiao_combinada.png

**Roteiro:** "Projeto = colocar os polos dominantes dentro da interseção. Todo o resto do módulo é: como MOVER os polos até lá."

---

### Slide 8 — Aproximação de 2ª por 1ª

**Tela:** T = a/((s+1)(s+a)) → y(t) = 1 − [a/(a−1)]e^−t + [1/(a−1)]e^−at; manter o ganho DC; vale para a ≥ 5.

**Figura:** m2_fig07_aprox_2por1.png

**Roteiro:** "A regra de ouro: mexeu nos polos, preserve o ganho DC. O polo rápido morre cedo e a resposta fica com o lento — MAS o regime tem que continuar certo."

---

### Slide 9 — Aproximação de 3ª por 2ª: a regra dos 5×

**Tela:** p3 ≥ 5·|Re(par)| ⇒ comportamento de 2ª ordem; p3 = 10×: igual; 3×: sente; 1×: overshoot morre.

**Figura:** m2_fig08_aprox_3por2.png

**Roteiro:** "TODAS as nossas fórmulas são de 2ª ordem. A estratégia do curso inteiro: projete como 2ª ordem, verifique que os polos extras estão 5× longe. Não estão? Itere."

---

### Slide 10 — O efeito do zero

**Tela:** y1 = y + ẏ/a: zero perto → mais overshoot, mais rápido; zero no SPD → undershoot; zero colado em polo → quase-cancelamento.

**Figura:** m2_fig09_efeito_zero.png

**Roteiro:** "Três imagens para guardar: zero no SPE é tempero; zero no SPD é o avião que afunda antes de subir; zero em cima de polo é borracha. O módulo inteiro vai abusar dessas três."

---

### Slide 11 — Fechamento e ponte

**Tela:** Resumo: requisitos → regiões; aproximações → validade das fórmulas. Próxima aula: o LGR — como os polos andam quando o ganho varia.

**Roteiro:** "Vocês já sabem ONDE os polos devem estar. Semana que vem: o mapa de TODOS os lugares onde eles PODEM estar com controle proporcional. No Lab 05, vocês recriam os gráficos de tr e testam a regra dos 5×."
