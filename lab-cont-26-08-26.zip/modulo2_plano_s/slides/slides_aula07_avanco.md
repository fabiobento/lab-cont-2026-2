# Slides — Aula 07: Controlador de Avanço de Fase

> **Documento do professor.** Formato de cada slide: **Tela**, **Figura**, **Roteiro falado**. Vídeos de apoio à preparação: tópico 2.3, vídeos 01–08. Lab associado: **Lab 07**.

---

### Slide 1 — Abertura

**Tela:** Aula 07: Quando o P não dá — deformar o LGR com avanço de fase.

**Roteiro:** "O LGR da semana passada era um dado da planta: o P só escolhe pontos sobre ele. Hoje a gente hackeia o LGR — com um polo e um zero bem posicionados."

---

### Slide 2 — A impossibilidade do P

**Tela:** G = 4/(s(s+4)): LGR vertical em −2. ts ≤ 1 s (σ ≥ 3)? IMPOSSÍVEL. Mp ≤ 5 % E tp ≤ 1 s? Conflitantes.

**Figura:** m2_fig20_impossibilidade.png

**Roteiro:** "Não é falta de tentativa: o LGR nunca passa à esquerda de −2. Requisito fora do LGR é requisito impossível para o P — por mais k que você varra."

---

### Slide 3 — Deformando o LGR

**Tela:** Zero atrai, polo repele: "o LGR se deforma na direção do polo". Cuidado: a−b > 6 pode mandar ramos ao SPD.

**Figura:** m2_fig21_lgr_deformado.png

**Roteiro:** "Lembrem dos exemplos C e D: o zero é ímã. Com um par zero-polo, o zero puxa os ramos para a região que queremos e o polo controla a curvatura. Isso É o avanço de fase."

---

### Slide 4 — A contribuição do controlador

**Tela:** ∠C(□d) = −∠G(□d) − 180°. Exemplo: □d = −3,14+3,2j, ∠G = −209,5° → avanço de 29,5°.

**Roteiro:** "Medimos quanto falta para −180° no ponto desejado — e o par polo-zero contribui exatamente essa diferença. O nome vem daí: ele ADIANTA a fase."

---

### Slide 5 — Infinitas soluções, três padrões

**Tela:** 1) zero embaixo de □d; 2) bissetriz (mínimo ganho); 3) cancelamento (nunca o polo da origem!).

**Figura:** m2_fig22_tres_solucoes.png

**Roteiro:** "Uma equação, duas incógnitas: infinitos pares dão o mesmo avanço. Os três padrões do curso: embaixo (conta fácil), bissetriz (ganho mínimo), cancelamento (planta mais simples). Cada caso é um caso — projeto tem arte."

---

### Slide 6 — O ganho exato

**Tela:** k = (1/A)·Πdist(polos)/Πdist(zeros) com C·G. k1 = 6,77 (embaixo), k2 = 6,12 (bissetriz — menor ✓). Confira TODOS os polos de MF!

**Roteiro:** "O par polo-zero garante que □d PODE ser polo; o ganho garante que ele É. E nunca esqueçam: planta de 3ª ordem tem 3 polos de malha fechada — o terceiro pode destruir o projeto."

---

### Slide 7 — O PD e seu problema físico

**Tela:** PD: C = k(s+a) — avanço com polo no ∞. Derivador puro → degrau vira impulso → pico de trilhões de volts → saturação. Solução: PD com filtro = avanço.

**Figura:** m2_fig23_pd_filtro.png

**Roteiro:** "O PD puro é impróprio — não existe na natureza. A derivada do degrau é um impulso: o sinal de controle explode e o atuador satura. Todo PD real tem filtro — e PD com filtro é, matematicamente, um avanço de fase."

---

### Slide 8 — Projeto em dois estágios

**Tela:** G = 10/(s(s+10)): P para Mp = 20 % (k = 12,1, tp = 0,32 s) → avanço dobra velocidade: C = 48,4(s+10)/(s+20) → Mp = 20,1 %, tp = 0,16 s.

**Figura:** m2_fig24_avanco_2estagios.png

**Roteiro:** "Mesmo overshoot, metade do tempo de pico. E o cancelamento zerou a ordem extra: o sistema compensado é de 2ª ordem EXATA — por isso os números bateram perfeitos."

---

### Slide 9 — 3ª ordem e a regra dos 40°

**Tela:** G = 20(s+15)/(s(s+10)(s+20)), Mp = 25 %, tp = 150 ms → C = 26,1(s+7,4)/(s+11,2) → sim: 23,2 %, 148 ms. Avanço ≤ 40° por estágio — Fusca × Ferrari.

**Figura:** m2_fig25_avanco_3a_ordem.png

**Roteiro:** "Deu 23,2 % e não 25 %: as fórmulas são de 2ª ordem, a planta não é. E o limite dos 40° não é capricho: além dele, ganho e polo explodem. Se a planta é um Fusca, nenhum controlador a transforma em Ferrari sem custo."

---

### Slide 10 — Fechamento e ponte

**Tela:** Resumo: impossibilidade → contribuição → 3 padrões → ganho → PD real → 40°. Próxima aula: o outro problema — erro em regime. Atraso de fase e PI.

**Roteiro:** "O avanço resolve o transitório. Mas erro em regime manda subir o ganho — e subir o ganho arrasta os polos pelo LGR e desfaz o transitório. Semana que vem, o truque elegante: mexer no regime SEM mexer nos polos. No Lab 07 vocês implementam o projetar_avanco e medem o pico do PD."
