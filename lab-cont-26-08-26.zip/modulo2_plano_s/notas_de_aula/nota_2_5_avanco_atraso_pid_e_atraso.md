# Nota de Aula 2.5 — Avanço + Atraso, PID e Atraso de Transporte

> **Documento do professor** — guia de quadro, pronto para transcrição linha a linha, com falas sugeridas.
> Duração prevista: 2 h (semana 9). Lab associado: **Lab 09**.

**Mapa dos vídeos deste tópico (não mostrar aos alunos):**

| Vídeo | Título | Uso na aula |
|---|---|---|
| 01 | Projeto de Controlador de Avanço e Atraso de Fase | Receita de 10 passos; 2 iterações do projeto (Q1–Q2) |
| 02 | Projeto de Controlador PID | kp/ki/kd; ajuste do zero do PI; PID real = PI-Lead (Q3) |
| 03 | O Atraso de Transporte | e^−sτ; aquecedor a gás; Padé (Q4) |
| 04 | Projeto de Controlador com Atraso | k > a + 2/τ; fase do atraso no avanço; C = 14,26(s+4)/(s+8,8) (Q4–Q5) |

---

## Q1 — A receita de bolo completa (20 min)

**Quadro:**

```
RECEITA DE BOLO (10 passos — vale para QUALQUER ordem/tipo):
 1. requisitos → parâmetros de 2ª ordem (ξ, ωd, ωn, σ)
 2. polo desejado □d
 3. ∠G(□d):  pouco maior que −180° → vá ao passo 7
              maior com folga → APERTE os requisitos, volte ao 2
              menor que −180° → siga
 4. avanço necessário: ∠C(□d) = −∠G(□d) − 180°  (≤ 40°!)
 5. posição do ZERO do avanço (embaixo / bissetriz / cancelamento)
 6. posição do POLO para completar o avanço
 7. GANHO: k = (1/A)·Πdist(polos)/Πdist(zeros)
    — NÃO ESQUEÇA DO A (é o fermento: sem ele o bolo não cresce)
 8. requisito de regime? → constante obtida → FATOR
 9. zero do atraso/PI: chute = |Re(□d)|/10
10. polo do atraso = zero/fator. SIMULE, AVALIE, AJUSTE.

Metáfora: mais ingredientes = mais trabalho, não mais dificuldade.
```

**Fala sugerida:** "Bolo com cinco farinhas dá mais trabalho que bolo com uma — mas a mistura é a mesma. Planta de 5ª ordem com 2 zeros dá mais trabalho que a de 2ª — mais fases, mais módulos — mas a receita é ESTA, passo a passo."

---

## Q2 — Projeto de avanço e atraso: duas iterações (30 min)

**Quadro (projetar fig `m2_fig30_avanco_atraso.png`):**

```
G = 200/(s(s+10)(s+20));  Mp = 16,3 %, tr(0–100 %) = 300 ms, ess(rampa) = 0,02
 → ξ = 0,5, ωd = 7, kv = 50 → □d = −4,04 + 7j

1ª ITERAÇÃO:
 ∠G(□d) = −193,3° → avanço 13,3°; zero cancela −10 (NUNCA o da origem!)
 fase zero 49,6° → fase polo 36,3° → b = 13,57, k = 8,33
 kv obtido = 8,33·10/13,57 ≈ 6,14 → fator 8,14 → atraso (s+0,4)/(s+0,05)
 C = 8,33(s+10)/(s+13,57)·(s+0,4)/(s+0,05)
 simulação: Mp = 22 % ✗ (o atraso estragou o overshoot), tr = 328 ms

2ª ITERAÇÃO (avanço COM FOLGA para absorver o efeito do atraso):
 Mp ≈ 12 % (ξ = 0,56), tr = 275 ms → ωd = 7,9 → □d = −5,34 + 7,87j
 ∠G = −211,8° → avanço 31,8° → b = 20,4, k = 13,4 → kv = 6,6
 C = 13,4(s+10)/(s+20,4)·(s+0,4)/(s+0,05)   [mesmo atraso!]
 simulação final: Mp = 16,9 %, tr = 300 ms ✓

PARÊNTESE — e se ∠G(□d) > −180°? → o LGR já passa na região:
 APERTE os requisitos. Ex.: □d = −3+5j → −172,9° (folga demais)
 → □d = −3,3+5,5j → −178,6°, k ≈ 4,9 → polos melhores que o desejado
```

**Fala:** "Primeira tentativa: 22 % de overshoot. Fracasso? Não — informação. O atraso roubou fase, então reprojetamos o avanço com folga. Projeto de controle tem arte: se fosse só conta, o computador faria tudo e ninguém precisaria da gente."

---

## Q3 — O PID (25 min)

**Quadro (projetar fig `m2_fig31_pid_zeros.png`):**

```
PID = PI + PD:  C(s) = k(s+z1)(s+z2)/s
 zero 1 = "avanço" (PD) | zero 2 = "atraso" (PI) | polo na origem

EXEMPLO: G = 2/((s+2)(s+5));  Mp = 16,3 %, tp = 400 ms, ess(degrau) = 0
 ξ = 0,5, ωd = 7,9 → □d = −4,6 + 7,9j ; ∠G = −195,3° → avanço 15,3°
 tg(15,3°) = 7,9/(a−4,6) → a = 33,4 ; k = 1,1 ; zero PI: 0,46
 C = 1,1(s+33,4)(s+0,46)/s → kp = 37,25, ki = 16,9, kd = 1,1

AJUSTE DO ZERO DO PI (mesma planta, 3 posições):
 zero −0,46: converge DEVAGAR
 zero −2:    rápido, overshoot GRANDE demais
 zero −1:    kp = 37,8, ki = 36,7 → SATISFATÓRIO ✓

PID REAL (nenhum ambiente implementa o puro):
 C(s) = P + I/s + D·N/(1+N/s)  → o "D" tem polo de filtro em −N
 ⇒ PID real = PI-Lead (PI + avanço!)
```

**Fala:** "Decorem: quando a indústria diz PID, o que roda no CLP é um PI-Lead. O derivador puro não existe — seria impróprio, como vimos no PD."

---

## Q4 — Atraso de transporte e a aproximação de Padé (25 min)

**Quadro:**

```
PROPRIEDADE DE LAPLACE:  L{x(t−τ)} = e^(−sτ)·X(s)

EXEMPLO: o aquecedor a gás — sua mãe lavando louça pede +5 °C.
 A água NOS CANOS ainda está na temperatura antiga: ela só sente o
 ajuste quando a água nova for TRANSPORTADA até a torneira.
 (também: reação química, comunicação, processamento digital)
 τ = τu + τy  →  Ga(s) = G(s)·e^(−sτ)   [τ em SEGUNDOS — SI!]

PROBLEMA: e^−sτ não é razão de polinômios → não sabemos achar polos
SOLUÇÃO — APROXIMAÇÃO DE PADÉ (Henri Padé, matemático francês;
 não é aproximação de Tabajara nem do seu Creysson):
 e^x ≈ (2+x)/(2−x)  →  e^(−sτ) ≈ −(s − 2/τ)/(s + 2/τ)
 zero no SPD em +2/τ → fase NÃO MÍNIMA (lembra do undershoot?)

EFEITO NA ESTABILIDADE (projetar fig m2_fig32_pade.png):
 G = 1/(s+a): sem atraso, estável ∀k>0. COM atraso:
 Δ(s) = s² + (a + 2/τ − k)s + 2a/τ + 2k/τ
 INSTÁVEL SE k > a + 2/τ   — quanto MAIOR o atraso, MENOR o k crítico
```

**Quadro (análise-âncora):**

```
τ = 0,1 s, G = 2/(s(s+4)), k = 10:
 sem atraso: T = 20/(s²+4s+20) → ξ ≈ 0,447 → Mp = 20,8 %
 com atraso: denominador s³ + 24s² + 60s + 400
 polos −22,1 e −0,95 ± 4,1j → ξ = 0,223 → Mp = 48,7 % (Simulink: 49,5 %)
EXERCÍCIO (lab): atraso na malha direta × realimentação × dividido:
 overshoot IGUAL, tempos DIFERENTES.
```

---

## Q5 — Projeto de avanço compensando o atraso (20 min)

**Quadro (projetar fig `m2_fig33_projeto_com_atraso.png`):**

```
Mesma planta com τ = 0,1: requisitos tr = 0,5 s, Mp = 15 %
 1. ξ = 0,517, ωd = 4,23 → □d = −2,6 + 4,2j
 2. avanço SEM atraso: ∠G(□d) = −193,4° → 13,4°
 3. FASE DO ATRASO em □d (duas contas, mesmo resultado!):
    ∠e^(−0,1□d) = −0,1×4,2 rad = −24,1°
    Padé: ∠(−□d+20) − ∠(□d+20) = −10,5° − 13,6° = −24,1° ✓
 4. avanço TOTAL: 13,4° + 24,1° = 37,5° (dentro dos 40°!)
 5. cancela o −4: fase zero 71,6° → fase polo 34,1° → b = 8,8
 6. k = 14,26  →  C(s) = 14,26(s+4)/(s+8,8)
    simulação com atraso: Mp = 14,3 %, tr = 0,5 s ✓

POSIÇÃO DO ATRASO NA MALHA:
 na realimentação → medimos tr = 0,5 s
 entre entrada e saída → tr medido = 0,6 s (projetar para 0,4!)
 dividido → compensar TODO o atraso no overshoot, só o da malha
 direta no tempo de subida
```

**Fala:** "Fecho do módulo: o atraso rouba fase — então cobramos essa fase do avanço, com o limite dos 40° vigiando. Daqui pra frente, no próximo módulo, trocamos o plano-s pela frequência: Bode, Nyquist e margens de estabilidade. O LGR vira saudade — ou não."

---

**Ponte para o Módulo 03:** resposta em frequência, diagramas de Bode, margem de ganho e fase, Nyquist.

**Lab 09:** `ct.pade`, estabilidade × τ (reconstruir a curva k = a + 2/τ), posição do atraso na malha, projeto completo com compensação de atraso.
