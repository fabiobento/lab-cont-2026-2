# Nota de Aula 2.2 — O Lugar Geométrico das Raízes (LGR)

> **Documento do professor** — guia de quadro, pronto para transcrição linha a linha, com falas sugeridas.
> Duração prevista: 2 h (semana 6). Lab associado: **Lab 06**.

**Mapa dos vídeos deste tópico (não mostrar aos alunos):**

| Vídeo | Título | Uso na aula |
|---|---|---|
| 01 | Revisão: Controle Proporcional e a FT em Malha Fechada | u = k·e; T = kG/(1+kG) (Q1) |
| 02 | Variação de polo de Sistema de 1ª ordem em malha fechada | −a−k: o polo anda no eixo real (Q1) |
| 03 | Variação de polo de Sistema de 2ª ordem em malha fechada | −(a+kb)/(1+k); encontros em −a/2 e −(a+b)/2 (Q1) |
| 04 | O que é o Lugar Geométrico das Raízes (LGR — Root Locus) | Definição (Q1) |
| 05 | Característica comum dos Polos em Malha Fechada | Condição de ângulo (Q2) |
| 06 | Controle Proporcional Usando o LGR | Condição de módulo; k = 18, k = 25; −6+6j fora (Q2) |
| 07 | Exemplo de Projeto de Controle Proporcional no Plano-s | 10/[s(s+10)], k = 5,26 (Q3) |
| 08 | Quantidade de Ramos do LGR e Trechos Sobre o Eixo Real | Regras 1–3 (Q4) |
| 09 | Começo e Término dos Ramos e Assíntotas do LGR | Regras 4–6 (Q4) |
| 10 | Cruzamento com o Eixo Imaginário e Pontos de Saída/Entrada | Regras 7–8; k = 60, ±j√11, −1,42 (Q4) |
| 11 | Esboço de LGR para Sistema de 3ª Ordem | Exemplos A e B (Q5) |
| 12 | Esboço de LGR para Sistema de 4ª Ordem | Exemplos C e D (Q5) |

---

## Q1 — Motivação: para onde vão os polos quando k varia? (25 min)

**Quadro:**

```
CONTROLE P (revisão):  u = k·e   →   T(s) = kG / (1 + kG)
Polos de MF = raízes de  1 + kG(s) = 0

1ª ORDEM:  G = 1/(s+a)  →  T = k/(s + a + k)
 polo de MF: −a−k → anda para a ESQUERDA no eixo real quando k cresce
 (1 polo, 0 zeros → o polo vai ao infinito)

2ª ORDEM COM ZERO:  G = (s+b)/((s+a)(s+c))... primeiro o caso simples:
 G = 1/(s(s+a)) → T = k/(s² + a s + k)
 polos: reais distintos (k pequeno) → ENCONTRO em −a/2 (k = a²/4)
        → par complexo subindo/descendo na VERTICAL em −a/2

 COM zero: T = k(s+b)/(s² + (a+k)s + kb)
 k → ∞: um polo → −b (o ZERO!), outro → −∞
 encontro dos dois polos reais em −(a+b)/2... (caso 2 polos 1 zero)
```

**Quadro (a definição):**

```
LGR = LUGAR GEOMÉTRICO DAS RAÍZES
 = o caminho percorrido pelos polos de MALHA FECHADA
   quando k varia de 0 a ∞, com G(s) fixa
O LGR depende SÓ de G(s) — polos e zeros de malha aberta
Esboçável SEM calcular raízes para cada k → as 8 regras (Q4)
```

**Fala sugerida:** "No módulo 1 a gente escolhia k e aceitava o resultado. Agora a pergunta é: quais resultados são POSSÍVEIS? O LGR é o mapa de todas as possibilidades do controle proporcional — e, como veremos, de qualquer controlador."

---

## Q2 — Condição de ângulo e condição de módulo (30 min)

**Quadro (projetar fig `m2_fig12_condicao_angulo.png`):**

```
1 + kG(□) = 0  ⇔  kG(□) = −1  (real negativo!)

CONDIÇÃO DE ÂNGULO:  ∠G(□) = −180° (+ l·360°)
 ∠G(□) = Σ ângulos dos vetores (zeros → □) − Σ ângulos (polos → □)
 (atan2 — cuidado com o quadrante!)

Ex.: G = 1/(s(s+6)),  □ = −3+3j
 vetor do polo 0: 135° | vetor do polo −6: 45°
 ∠G = −(135+45) = −180° ✓ → PERTENCE ao LGR

CONDIÇÃO DE MÓDULO:  k = (1/A) · Π dist(□→polos) / Π dist(□→zeros)
 A = ganho da forma fatorada — NÃO ESQUEÇA DO A!
```

**Quadro (as três contas-âncora — projetar fig `m2_fig13_lgr_k18_k25.png`):**

```
G = 1/(s(s+6)):
 □ = −3+3j: fases 135+45 = 180° ✓ → k = √18·√18 = 18
 □ = −3+4j: fases 126,9+53,1 = 180° ✓ → k = 5·5 = 25
 □ = −6+6j: fases 135+90 = 225° ✗ → NÃO pertence: não há k que ponha
            polo ali. Não adianta calcular ganho!
```

**Fala:** "A condição de ângulo responde 'esse ponto PODE ser polo de malha fechada?'. A de módulo responde 'com QUAL ganho?'. Duas perguntas, duas fórmulas — sempre nessa ordem."

---

## Q3 — Projeto de controle P no plano-s (20 min)

**Quadro (projetar fig `m2_fig14_projeto_P_planos.png`):**

```
ENUNCIADO: G = 10/(s(s+10));  Mp ≤ 5 % com o MENOR tp possível

1. Mp ≤ 5 % ⇒ ξ ≥ 0,69 ⇒ β ≤ arccos(0,69) = 46,37°
2. LGR de 1/(s(s+10)): vertical em −5 após o encontro (k = 25)
   → subir no LGR até o LIMITE do setor:
   polos escolhidos: −5 ± j·5·tg(46,37°) = −5 ± 5,25j
3. módulo: k = |□d|·|□d+10| / 10 = 7,25 × 7,25 / 10 ≈ 5,26
4. T = 52,6/(s²+10s+52,6);  ωd = 5,25 → tp = π/5,25 ≈ 0,6 s
   simulação: Mp = 5,0 % ✓
```

**Fala:** "Subir mais no LGR diminuiria o tp, mas furaria o overshoot. Subir menos atrasa o pico. O projeto de P é a escolha de UM PONTO sobre o LGR — sem o LGR, isso seria tentativa e erro cega."

---

## Q4 — As oito regras de esboço (25 min)

**Quadro (tabela-resumo; detalhar regras 7 e 8 com o exemplo):**

```
G(s) = A·Π(s+zi)/Π(s+pj),  n polos, m zeros
1. n ramos (um por polo de MA)          2. simetria no eixo real
3. eixo real: ponto no LGR se à DIREITA houver nº ÍMPAR de polos+zeros reais
4. ramos COMEÇAM (k=0) nos polos, TERMINAM (k→∞) nos zeros;
   n−m ramos vão ao INFINITO
5. assíntotas: ângulos (180°+l·360°)/(n−m)
   n−m=2 → ±90° | n−m=3 → 60°,180°,300° | n−m=4 → ±45°,±135°
6. centroide: σa = (Σpolos − Σzeros)/(n−m)
7. cruzamento do eixo jω: ROUTH (k que zera a linha s¹) + equação auxiliar
8. saída/entrada no eixo real: d(−1/G)/ds = 0 — aceitar SÓ raízes sobre trechos

ÂNGULO DE PARTIDA de polo complexo:
 θ = 180° + Σ∠(zeros→p) − Σ∠(outros polos→p)
 ex.: G = (s+2)(s+4)/(s(s²+4)), polo +2j:
 θ = 180° + (45°+26,6°) − (90°+90°) = 71,6° → entra no SPD antes de voltar!
 (projetar fig m2_fig19_angulo_partida.png)
```

**Quadro (exemplo das regras 7 e 8):**

```
G = 1/((s+1)(s+2)(s+3))  →  característico: s³ + 6s² + 11s + (6+k)
Routh: linha s¹ = (66−(6+k))/6 = 0 → k = 60
       auxiliar: 6s² + 66 = 0 → s = ±j√11 ≈ ±3,32j  (cruzamento)
Saída: −1/G = −(s³+6s²+11s+6) → derivada −(3s²+12s+11) = 0
       → s = −1,42 ✓ (trecho (−2,−1))   s = −2,58 ✗ (fora — descartar)
```

---

## Q5 — Quatro exemplos-âncora de esboço (20 min)

**Quadro (projetar figs 15–18, um de cada vez):**

```
A) G = 200/(s(s+10)(s+20))           [fig15]
 trechos (−10,0) e (−∞,−20); 3 assíntotas ±60°/180°; centroide −10
 Routh → k = 30; auxiliar 30s²+6000=0 → cruzamento ±j14,1
 saída: 3s²+60s+200=0 → −4,23 ✓ (−15,77 ✗)

B) G = 200(s+5)/(s(s+10)(s+15))      [fig16]
 trechos (−5,0) e (−15,−10); n−m=2 assíntotas ±90°; centroide −10
 Routh → NENHUM cruzamento: NUNCA desestabiliza!
 saída: s³+20s²+125s+375=0 → −12,3

C) G = 400/(s(s+2)(s+10)(s+20))      [fig17]
 4 ramos; trechos (−2,0) e (−20,−10); assíntotas ±45°,±135°; centroide −8
 auxiliar s²+12,5=0 → cruzamento ±j3,5
 saídas: s³+24s²+130s+100=0 → −0,92 e −16,5 (DUAS saídas!)

D) G = 80(s+5)/(s(s+2)(s+10)(s+20))  [fig18]
 mesma planta + zero em −5: n−m=3 assíntotas ±60°/180°; centroide −9
 CONCLUSÃO: o zero PUXA os ramos para perto de si → mais estabilidade
```

**Fala:** "Comparem A com B, C com D: o zero é um ímã de ramos. Essa intuição — zero atrai, polo repele — é o que vai fundamentar o projeto do controlador de avanço na próxima aula."

---

**Ponte:** "Se o LGR não passa pela região de desempenho, o controle P falha. Solução: DEFORMAR o LGR acrescentando polo e zero — o controlador de avanço de fase."

**Lab 06:** `ct.rlocus`, implementar `angulo_G(G, ponto)` e `ganho_LGR(G, ponto)`, verificar os 4 exemplos-âncora.
