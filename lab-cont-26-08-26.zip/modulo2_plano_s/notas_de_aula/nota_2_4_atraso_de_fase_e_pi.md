# Nota de Aula 2.4 — Controlador de Atraso de Fase (e o PI)

> **Documento do professor** — guia de quadro, pronto para transcrição linha a linha, com falas sugeridas.
> Duração prevista: 2 h (semana 8). Lab associado: **Lab 08**.

**Mapa dos vídeos deste tópico (não mostrar aos alunos):**

| Vídeo | Título | Uso na aula |
|---|---|---|
| 01 | Alteração dos Polos Causada pelo Ajuste da Constante de Erro | Erro × ganho: subir k estraga o transitório (Q1) |
| 02 | Aumentando a Constante de Erro sem Afetar os Polos em MF | O mecanismo do atraso: 1/[s(s+3,2)], k = 7,4 (Q2) |
| 03 | Projetando o Controlador de Atraso de Fase | Procedimento: fator, regra do 1/10 (Q3) |
| 04 | Controlador PI — Proporcional e Integral | PI = atraso com polo na origem (Q4) |
| 05 | Projeto de Atraso de Fase para Sistema de 2ª Ordem Tipo 1 | Projeto literal b/[s(s+a)], Mp = 15 % (Q4) |
| 06 | Projeto de PI para Sistema de 3ª Ordem do Tipo 0 | C = 2,19(s+0,123)/s; desafio da planta instável (Q5) |

---

## Q1 — Erro em regime × ganho: o conflito (20 min)

**Quadro:**

```
Erro em regime depende das CONSTANTES DE ERRO → dependem do GANHO
 (tipo 0: kp = lim C·G | tipo 1: kv = lim s·C·G | ess = 1/(1+kp), 1/kv...)

CONFLITO: o k que dá bom TRANSITÓRIO quase nunca dá bom ERRO
Ex.: G = 10/((s+2)(s+5)):
 k = 8,45 → transitório ótimo, erro grande demais
 k = 19   → erro aceitável, transitório estragado (polos subiram no LGR!)
Subir o ganho MOVE os polos de MF ao longo do LGR.
Queremos: MESMOS polos, constante de erro MAIOR. Como?
```

**Fala sugerida:** "O avanço resolveu o transitório. Agora o problema é outro: erro em regime manda subir o ganho, e subir o ganho arrasta os polos pelo LGR e estraga o transitório. Precisamos de um truque que aumente a constante de erro SEM mexer nos polos."

---

## Q2 — O mecanismo do atraso de fase (25 min)

**Quadro (projetar figs `m2_fig26_atraso_mecanismo.png` e `m2_fig27_atraso_respostas.png`):**

```
EXEMPLO-ÂNCORA: G = 1/(s(s+3,2)), P com k = 7,4
 T = 7,4/(s²+3,2s+7,4) → polos −1,6 ± 2,2j → ξ = 0,59, ωn = 2,72
 kv = 7,4/3,2 ≈ 2,31 → ess(rampa) = 1/2,31 = 0,43

TRUQUE: C(s) = k·(s+2b)/(s+b)  — par polo-zero COLADO NA ORIGEM
 na frequência dos polos dominantes: (s+2b)/(s+b) ≈ 1 → NADA muda
 em regime (s → 0): (0+2b)/(0+b) = 2 → kv DOBRA!

EXEMPLO: 2b = 0,02 → C = 7,4(s+0,02)/(s+0,01)
 polos de MF: −1,595 ± 2,196j (praticamente os mesmos!) e −0,0201
 novo polo LENTO perto da origem → resposta demora mais a acomodar
 kv = 2·2,31 → ess(rampa) = 0,215 (metade) ✓

ATRASO DE FASE: a > b > 0 (zero mais longe da origem que o polo)
 "atraso" = contribui pequena fase NEGATIVA (preço que pagamos)
```

**Fala:** "Genial e simples: um par polo-zero tão perto da origem que, lá de cima, dos polos dominantes, os dois se enxergam como um só — quase-cancelamento. Mas em regime, s→0, a razão vira o fator a/b. O transitório não sente; o erro, sim."

---

## Q3 — Procedimento de projeto do atraso (20 min)

**Quadro:**

```
1. Projete o transitório primeiro (P ou avanço) → □d, k, constante obtida
2. FATOR = constante desejada / constante obtida = a/b
3. Escolha o ZERO: bom chute = 1/10 da |Re(□d)|
4. POLO = zero / fator (mais perto da origem ainda)
5. Simule: contribuição de fase do par ≈ −1° a −3° → overshoot sobe um pouco

Exemplos (planta 1/(s(s+3,2)), k = 7,4, polos −1,6 ± 2,2j, zero em −0,16):
 sem atraso: Mp = 10 %
 fator 2  → polo −0,08  → fase do par = −1,43° → Mp = 14 %
 fator 10 → polo −0,016 → fase do par = −2,55° → Mp = 17 %
 fator 10 com par AFASTADO, (s+0,8)/(s+0,08) → Mp = 40 % (!),
   mas o erro converge bem mais rápido → solução de compromisso
 (fator grande ou par afastado ⇒ mais fase roubada ⇒ mais overshoot)
Compensar o overshoot? → avanço com folga (reprojeto) — semana que vem!
```

---

## Q4 — O PI e o projeto literal para 2ª ordem tipo 1 (30 min)

**Quadro:**

```
PI: C(s) = kp + ki/s = kp(s + ki/kp)/s  =  ATRASO COM O POLO NA ORIGEM
 fator infinito! tipo do sistema SOBE 1 → o ÚNICO que zera erro de
 tipo 0 ao degrau
PREÇO: fase −90° permanente + zero a posicionar; estraga mais o
 transitório que o atraso comum.
 REGRA PRÁTICA: "só use PI se for ESTRITAMENTE NECESSÁRIO"
 (erro nulo exigido). Erro pequeno basta? → atraso de fase comum.

PROJETO LITERAL (vale para qualquer a, b):  G = b/(s(s+a)), Mp = 15 %
 → ξ = 0,517; polos sobre o LGR (vertical −a/2): tg β = ωd/(a/2)
 ωn = 1,07·a/2·(1/0,517)...  resultados prontos:
 k = a²/(1,07b)   →   C(s) = (a²/1,07b)·(s + a/20)/(s + a/80)
 variante Mp = 10 %: fator 5,3, zero d = a/106
```

**Fala:** "Esse projeto literal é o que vocês vão refazer no lab com números concretos — depois de fazer uma vez com letras, qualquer planta 2ª ordem tipo 1 vira receita."

---

## Q5 — PI para 3ª ordem tipo 0 e o desafio (25 min)

**Quadro (projetar fig `m2_fig28_pi_3a_ordem.png`):**

```
G = 20/((s+1)(s+2)(s+10))  (tipo 0!) ; requisitos: Mp = 16,3 %, ess = 0
 ξ = 0,5; escolhemos ωn = 2,46 → par −1,23 ± 2,13j
 3º polo da planta em −10,54 (longe: dominância ok)
 k pelo módulo = 2,19 ; zero do PI: chute 0,123 (1/10 de 1,23)
 C(s) = 2,19·(s + 0,123)/s
 simulação: erro → 0 ✓ (convergência lenta — o zero poderia ir a 0,73,
 com mais overshoot: de novo a arte do ajuste)
```

**Quadro (projetar fig `m2_fig29_beakman.png` — o desafio):**

```
DESAFIO (para casa): G = 20/((s−1)(s+2)(s+10))  — PLANTA INSTÁVEL (polo em +1)
 Tente o PI com zero em −0,5. Esboce o LGR: o ramo do polo +1 fica
 preso no semiplano direito. Routh: linha s¹ = −400k²+1350k−2160 < 0 ∀k
 ⇒ com esse zero, NENHUM k estabiliza.
 Curiosidade: com o zero em −0,123 estabiliza (1,22 < k < 4,44) — mas a
 resposta fica péssima. Estabilidade ≠ desempenho; e nem toda planta tem
 solução com qualquer controlador: ANÁLISE ANTES DE PROJETO!
```

**Fala:** "Deixo o desafio: mesma receita, planta instável. Quando não conseguirem — e não vão conseguir — quero que provem por quê. Engenheiro que projeta sem analisar primeiro é cozinheiro que tempera sem provar."

---

**Ponte:** "Transitório (avanço) + regime (atraso) juntos, o PID completo, e o que fazer quando a própria física atrasa o sinal: atraso de transporte e a aproximação de Padé."

**Lab 08:** `projetar_atraso(G, sd, fator)`, efeito do fator no overshoot, o desafio da planta instável com prova de Routh numérica.
