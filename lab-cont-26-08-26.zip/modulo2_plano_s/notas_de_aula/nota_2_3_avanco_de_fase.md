# Nota de Aula 2.3 — Controlador de Avanço de Fase

> **Documento do professor** — guia de quadro, pronto para transcrição linha a linha, com falas sugeridas.
> Duração prevista: 2 h (semana 7). Lab associado: **Lab 07**.

**Mapa dos vídeos deste tópico (não mostrar aos alunos):**

| Vídeo | Título | Uso na aula |
|---|---|---|
| 01 | Impossibilidade de Obter o Tempo de Acomodação Desejado com Controle P | 4/[s(s+4)], ts ≤ 1 s impossível (Q1) |
| 02 | Visualizando o Efeito do Acréscimo de um Zero e um Polo no LGR | O LGR se deforma na direção do polo (Q1) |
| 03 | Calculando a Contribuição do Controlador | ∠C(□d) = −∠G(□d) − 180° (Q2) |
| 04 | Infinitas Soluções, Soluções Mais Adotadas | 3 padrões: embaixo, bissetriz, cancelamento (Q3) |
| 05 | A Necessidade do Ganho Exato | k1 = 6,77, k2 = 6,12 (Q3) |
| 06 | O Controlador PD, Proporcional-Diferencial | PD = avanço com polo no ∞; pico infinito; filtro (Q4) |
| 07 | Projeto para Sistema de 2ª Ordem do Tipo 1 | C = 48,4(s+10)/(s+20) (Q4) |
| 08 | Projeto para Sistema de 3ª Ordem | C = 26,1(s+7,4)/(s+11,2); regra dos 40° (Q5) |

---

## Q1 — A impossibilidade do P e a deformação do LGR (25 min)

**Quadro (projetar fig `m2_fig20_impossibilidade.png`):**

```
G = 4/(s(s+4))  →  LGR: vertical em −2 após o encontro
REQUISITO: ts(5 %) ≤ 1 s ⇒ σ ≥ 3
 ⇒ IMPOSSÍVEL com P: o LGR nunca passa à esquerda de −2

Requisitos conflitantes mesmo "alcançáveis": Mp ≤ 5 % E tp ≤ 1 s
 ξ ≥ 0,69 → β ≤ 46,37° → polos −2 ± j·2·tg(46,37°) = −2 ± 2,1j
 → ωd = 2,1 → tp = π/2,1 = 1,5 s > 1 s ✗
CONCLUSÃO: com P, os polos de MF só podem estar SOBRE o LGR da planta.
 Para sair dele, precisamos DEFORMAR o LGR.
```

**Quadro (projetar fig `m2_fig21_lgr_deformado.png`):**

```
Acrescentando C(s) = (s+a)/(s+b)  (zero em −a, polo em −b, a < b):
 o LGR SE DEFORMA NA DIREÇÃO DO POLO do controlador
 (zero atrai, polo repele — lembra dos exemplos C/D do LGR?)
 zero sozinho puxaria demais; o polo "segura" e posiciona
AVANÇO DE FASE: zero mais perto da origem que o polo (a < b)
 "avanço" = contribui FASE POSITIVA no ponto desejado
```

**Fala sugerida:** "O nome assusta, mas a ideia é geométrica: queremos um ponto fora do LGR? Colocamos um par polo-zero que dobra o LGR até passar por ele. O zero atrai os ramos; o polo define a curvatura."

---

## Q2 — A contribuição do controlador (20 min)

**Quadro:**

```
Para □d ser polo de MF com C(s)G(s):  ∠C(□d)·G(□d) = −180°

CONTRIBUIÇÃO DO CONTROLADOR:
 ∠C(□d) = −∠G(□d) − 180°     [fase que falta para completar −180°]

Ex.: requisitos → □d = −3,14 + 3,2j ;  ∠G(□d) = −209,5°
 → ∠C(□d) = 209,5° − 180° = 29,5° de AVANÇO
 geometricamente: ∠(zero→□d) − ∠(polo→□d) = 29,5°
```

**Fala:** "Tradução: medimos quanto falta de fase no ponto desejado e mandamos o par polo-zero contribuir exatamente essa diferença. Só que há infinitos pares que fazem isso…"

---

## Q3 — Infinitas soluções, três padrões e o ganho exato (25 min)

**Quadro (projetar fig `m2_fig22_tres_solucoes.png`):**

```
INFINITAS SOLUÇÕES para o mesmo avanço φ = 29,5°. As 3 mais adotadas:

1. ZERO EMBAIXO DE □d (Re(zero) = Re(□d)):
   fase do zero = 90° → fase do polo = 90° − φ
   ex.: a = 3,14...→ a = 5, b = 8,3

2. BISSETRIZ: o segmento zero–polo simétrico em relação à vertical por □d
   minimiza o ganho |C| necessário
   ex.: a = 3,4, b = 6,6

3. CANCELAMENTO: o zero cancela um polo da planta
   (NUNCA o polo da origem — derruba o tipo do sistema!)
   ex.: a = 4 cancela o −4 da planta

GANHO EXATO (condição de módulo com C·G, A incluído!):
 k = (1/A)·Π dist(□d→polos de CG) / Π dist(□d→zeros de CG)
 solução 1: k = 6,77 | solução 2 (bissetriz): k = 6,12 (menor! ✓)
```

**Fala:** "Mesmo avanço, ganhos diferentes. A bissetriz é a mais econômica — mas o cancelamento costuma ser o mais prático, porque simplifica a planta. Cada caso é um caso: projeto de controle tem arte."

---

## Q4 — O PD e o projeto para 2ª ordem tipo 1 (25 min)

**Quadro (projetar fig `m2_fig23_pd_filtro.png`):**

```
PD: C = k(s+a) = kd·s + kp   →  avanço com o polo no INFINITO
 contribui fase ∠(zero→□d) direto (sem subtrair polo)
PROBLEMA: PD é IMPRÓPRIO → derivador ideal → degrau na entrada vira
 IMPULSO na saída: pico de "trilhões de volts" → satura o atuador
SOLUÇÃO: PD COM FILTRO  k(s+a)/(s+b), b grande
 ⇒ isto É um avanço de fase! PD real = avanço com polo distante

PROJETO 2ª ORDEM TIPO 1 (fig m2_fig24_avanco_2estagios.png):
 G = 1/(s(s+10))... C = 48,4(s+10)/(s+20)  →  T = 484/(s²+20s+484)
 ωn = 22, ξ = 0,455 → Mp = 20,1 % ✓
 tp: 0,321 s (antes) → 0,160 s (depois) — METADE do tempo de pico!
```

---

## Q5 — Projeto para 3ª ordem e a regra dos 40° (25 min)

**Quadro (projetar fig `m2_fig25_avanco_3a_ordem.png`):**

```
G = 20(s+15)/(s(s+10)(s+20));  requisitos Mp = 25 %, tp = 150 ms
 ξ = 0,404, ωd = π/0,15 = 21 → □d = −9,3 + 21j
 ∠G(□d) = −190,2° → contribuição 10,2° (pequena!)
 solução por bissetriz: zero em −7,4, polo em −11,2
 C = 26,1(s+7,4)/(s+11,2)
 simulação: Mp = 23,2 %, tp = 148 ms ✓ (3ª ordem ≠ 2ª: aproximação!)

REGRA DOS 40°:
 avanço por estágio ≤ 40°. Precisa de mais? → DOIS estágios em cascata
 (ou repense os requisitos)
 Analogia: Fusca × Ferrari — se a planta é um Fusca, nenhum controlador
 a transforma em Ferrari sem custo: avanço demais = ganho alto, polo
 distante, ruído amplificado, atuador saturado.
```

**Fala:** "A simulação deu 23,2 % e não 25 %: as fórmulas são de 2ª ordem e a planta é de 3ª. Projetamos, simulamos, ajustamos. E o limite de 40° não é capricho: além dele, o ganho e o polo explodem — o Fusca não vira Ferrari."

---

**Ponte:** "Avanço resolve o transitório. Mas e o erro em regime, que depende do ganho? Semana que vem: o controlador de atraso de fase — e por que o PI é o controlador mais usado da indústria."

**Lab 07:** função `projetar_avanco(G, sd, modo)`, PD × PD com filtro (o pico!), verificação da regra dos 40°.
