# Nota de Aula 2.1 — Regiões de Desempenho no Plano-s e Aproximações

> **Documento do professor** — guia de quadro, pronto para transcrição linha a linha, com falas sugeridas.
> Duração prevista: 2 h (semana 5). Lab associado: **Lab 05**.

**Mapa dos vídeos deste tópico (não mostrar aos alunos):**

| Vídeo | Título | Uso na aula |
|---|---|---|
| 01 | Fórmulas da resposta ao degrau | Revisão das fórmulas de 2ª ordem (Q1) |
| 02 | O Plano-s | Mapa de polos e zeros; σ, ωd, β; própria × imprópria; sistema adivinho (Q1) |
| 03 | Requisito de Overshoot no Plano-s | β = arccos ξ; setor no plano-s (Q2) |
| 04 | Requisitos de Instante de Pico e de Tempo de Acomodação no Plano-s | Faixa ωd ≥ π/X; semirreta σ ≥ 3/Y, 4/Y, 4,6/Y (Q2) |
| 05 | Requisito de Tempo de Subida no Plano-s | Aproximações de tr; círculo ωn ≥ 1,6/X ou 2,4/Y; região combinada (Q3) |
| 06 | Aproximação de Segunda ordem por Primeira Ordem | Manter o ganho DC; y(t) = 1 − a/(a−1)·e^−t + 1/(a−1)·e^−at (Q4) |
| 07 | Aproximação de Terceira ordem por Segunda ordem | Regra dos 5×; ξ real; ωn real; comportamento com p3 = 10, 3, 1, 0,5 (Q4) |
| 08 | Aproximação de Sistema com Zero por Sistema sem Zero | y1 = y + ẏ/a; zero RHP → undershoot; quase-cancelamento (Q5) |

---

## Q1 — Revisão das fórmulas e o plano-s (25 min)

**Quadro:**

```
REVISÃO (2ª ordem padrão): T(s) = ωn² / (s² + 2ζωn s + ωn²)
 Mp = e^(−ζπ/√(1−ζ²)) · 100 %          tp = π / ωd
 ts ≈ 3/σ (5 %) · 4/σ (2 %) · 4,6/σ (1 %)   [σ = ζωn]
 tr(10–90 %) ≈ 1,6/ωn      tr(0–100 %) ≈ 2,4/ωn   [valores para ξ = 0,5]

Formas dependentes de ξ (consulta; tabela de validade na teoria §2.1.5):
 tr(10–90%) ≈ (1,8ξ³ − 0,4ξ² + ξ + 1)/ωn   [ξ ∈ [0,35; 0,65]: erro < 5 %]
 tr(0–100%) ≈ (2,3ξ² − 0,08ξ + 1,1)/ωn    [mesmo intervalo]
 constantes (2ξ+0,65)/ωn e (3ξ+1)/ωn → só para ξ ≈ 0,5

O PLANO-S: eixo horizontal σ (real), eixo vertical jω (imaginário)
 polo: ×     zero: ○     par complexo: −σ ± jωd
 |p| = ωn     β = ângulo com o eixo real negativo:  cos β = σ/ωn = ξ
 ponto qualquer: □ = parte real + j·parte imaginária
```

**Quadro (conta-âncora, resolver no quadro com a turma):**

```
EXERCÍCIO: ξ = 0,45 e ωn = 2  →  calcule Mp, tp, ts(5 %), tr(10–90 %)
 Mp = e^(−0,45π/√(1−0,2025))·100 ≈ 20,5 %
 tp = π/(ωn√(1−ξ²)) = π/1,79 ≈ 1,76 s
 ts(5 %) = 3/(0,9) ≈ 3,33 s     tr ≈ 1,6/2 = 0,8 s
 polos: −0,9 ± 1,79 j   →  MARQUE NO PLANO-S (desenhar ×)
```

**Fala sugerida:** "Essas fórmulas são o alfabeto do módulo. Daqui pra frente a pergunta muda de lugar: não é mais 'dado o sistema, qual a resposta?' — é 'quero ESSA resposta; ONDE os polos precisam estar?'"

**Quadro (propriedade da FT):**

```
G(s) = A·(s+z1)(s+z2)… / (s+p1)(s+p2)…
 PRÓPRIA: grau(num) ≤ grau(den)  — todo sistema físico real
 IMPRÓPRIA: grau(num) > grau(den) — não existe na natureza
 (responderia a sinais que ainda nem chegaram; útil como peça matemática — veremos o PD)
Se eu te der a FT, você me dá os polos e zeros; se eu te der polos, zeros
E O GANHO, você me dá a FT. Sem o ganho: infinitos sistemas com o mesmo mapa
(SISTEMA ADIVINHO não existe — e adivinhar pela resposta = regressão, outro curso)
```

---

## Q2 — Requisitos de overshoot, pico e acomodação no plano-s (25 min)

**Quadro (projetar figs `m2_fig02_regiao_mp.png` e `m2_fig03_regiao_tp_ts.png`):**

```
OVERSHOOT → SETOR
 Mp = e^(−ζπ/√(1−ζ²))  depende SÓ de ξ   e   ξ = cos β
 Mp ≤ 20 %  ⇔  ξ ≥ 0,456  ⇔  β ≤ arccos(0,456) = 62,9°
 ⇒ polos DENTRO do setor de abertura 2·β em torno do eixo real negativo
 (quanto MENOR o β, MENOR o overshoot; β = 0 → polos reais → Mp = 0)

INSTANTE DE PICO → FAIXA HORIZONTAL em ωd
 tp = π/ωd ≤ X  ⇔  ωd ≥ π/X
 ⇒ polos ACIMA da reta ωd = π/X (e abaixo de −π/X)

TEMPO DE ACOMODAÇÃO → SEMIRRETA VERTICAL em σ
 ts(5 %) ≤ Y ⇔ σ ≥ 3/Y ;  ts(2 %) ⇔ σ ≥ 4/Y ;  ts(1 %) ⇔ σ ≥ 4,6/Y
 ⇒ polos À ESQUERDA da reta vertical σ = cte
```

**Fala:** "Cada requisito vira uma REGIÃO do plano-s. Overshoot vira setor — Mp só depende do ângulo. Pico vira faixa — depende só da parte imaginária. Acomodação vira semirreta — depende só da parte real. Decorem o desenho, não a frase."

**Atividade (5 min):** "Mp ≤ 20 %, tp ≤ 3,14 s, ts(2 %) ≤ 8 s. Quais as três fronteiras? Desenhem no caderno." → β ≤ 62,9°, ωd ≥ 1, σ ≥ 0,5.

---

## Q3 — Tempo de subida e a região combinada (20 min)

**Quadro (projetar figs `m2_fig05_regiao_tr.png`, `m2_fig06_tr_aproximacoes.png` e `m2_fig04_regiao_combinada.png`):**

```
TEMPO DE SUBIDA → CÍRCULO
 tr(10–90 %) ≤ X ⇔ ωn ≥ 1,6/X  ;  tr(0–100 %) ≤ Y ⇔ ωn ≥ 2,4/Y
 ⇒ polos FORA do círculo de raio ωn mínimo centrado na origem
 (constantes 1,6 e 2,4 valem para ξ ≈ 0,5 — longe disso, usar as formas
  dependentes de ξ da tabela; no lab vocês vão RECRIAR essas curvas)

REGIÃO COMBINADA = INTERSEÇÃO de todas as regiões
 Ex.: Mp ≤ 20 %, tp ≤ 3,14 s, ts(2 %) ≤ 8 s
   β ≤ 62,9°  ∩  ωd ≥ 1  ∩  σ ≥ 0,5
 ⇒ região delimitada no SPE — polos dominantes de MF devem cair AQUI
```

**Fala:** "Juntando tudo: o projeto todo se resume a colocar os polos de malha fechada dentro de uma região. O resto do módulo é aprender as ferramentas para MOVER os polos até lá."

---

## Q4 — Aproximações: 2ª por 1ª, 3ª por 2ª (25 min)

**Quadro:**

```
APROXIMAÇÃO 2ª → 1ª (projetar fig m2_fig07_aprox_2por1.png)
 T(s) = a / ((s+1)(s+a))  →  y(t) = 1 − [a/(a−1)]e^(−t) + [1/(a−1)]e^(−at)
 REGRA DE OURO: MANTER O GANHO DC  (T(0) = 1 nos dois)
 a grande → o termo rápido morre logo → T ≈ 1/(s+1)
 Quando vale? a ≥ 5 (polo rápido 5× mais distante que o lento)

APROXIMAÇÃO 3ª → 2ª (projetar fig m2_fig08_aprox_3por2.png)
 T(s) = ωn²·p3 / ((s² + 2ξωn s + ωn²)(s+p3))
 REGRA DOS 5×: p3 ≥ 5·|Re(par dominante)| ⇒ comportamento ≈ 2ª ordem
 p3 = 10·σ: praticamente idêntico | p3 = 3·σ: começa a sentir
 p3 ≈ σ: overshoot MORRE (Mp → 0) — o polo real domina a resposta
 ξ real = |Re|/|polo dominante|    ωn real = |polo dominante|
```

**Fala:** "Por que aproximar? Porque TODAS as nossas fórmulas de desempenho são de 2ª ordem. O projeto inteiro será: projetar como se fosse 2ª ordem, conferir que os polos extras estão longe o bastante — e se não estiverem, iterar."

---

## Q5 — O efeito do zero (20 min)

**Quadro (projetar fig `m2_fig09_efeito_zero.png`):**

```
SISTEMA COM ZERO: T1(s) = ((s+a)/a) · T(s)   [ganho DC preservado!]
 No tempo:  y1(t) = y(t) + (1/a)·ẏ(t)
 ⇒ o zero SOMA A DERIVADA à resposta:
   zero perto (a pequeno) → derivada pesa → MAIS overshoot, mais rápido
   zero longe (a grande) → derivada irrelevante → ≈ sistema sem zero

ZERO NO SEMIPLANO DIREITO (fase não mínima):
 y1 = y − |1/a|·ẏ → resposta primeiro vai pro lado ERRADO = UNDERSHOOT
 ex.: avião subindo: primeiro afunda o bico

QUASE-CANCELAMENTO: zero colado num polo ⇒ efeito quase nulo
 (resíduo do polo ≈ 0 → o polo "some" da resposta — base do cancelamento
  polo-zero dos projetos de controlador)
```

**Fala:** "Zero no SPE é tempero: um pouco acelera, muito estraga. Zero no SPD é o avião que afunda antes de subir. E zero EM CIMA de polo é borracha. Guardem essas três imagens — o módulo inteiro vai usá-las."

---

**Ponte:** "Na próxima aula: como os polos de malha fechada se MOVEM quando variamos o ganho. É o Lugar Geométrico das Raízes — a ferramenta central do curso."

**Lab 05:** recriar os gráficos tr·ωn × ξ (as aproximações!), regiões no plano-s, validar regra dos 5× e o efeito do zero por simulação.
