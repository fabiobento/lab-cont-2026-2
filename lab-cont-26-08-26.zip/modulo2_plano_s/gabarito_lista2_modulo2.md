# Gabarito — Lista 2 (Módulo 02)

> **Documento do professor** — divulgar aos alunos somente após o prazo de entrega.
> Resolução detalhada, passo a passo, com referências ao local da teoria para consulta (`teoria_modulo2.md`). Valores de simulação conferidos numericamente.

---

## Questão 1 — Regiões de desempenho

**Consulte:** teoria §2.1.3 (overshoot → setor), §2.1.4 (pico → faixa; acomodação → semirreta), §2.1.5 (subida → círculo), §2.1.6 (região combinada); Exercício 2.1.1 dos exercícios resolvidos.

**a)** Fronteiras, uma por requisito:
1. $M_p \leq 10\% \Rightarrow \zeta \geq 0{,}591 \Rightarrow \beta \leq \arccos(0{,}591) = 53{,}8°$ (**setor**);
2. $t_p = \pi/\omega_d \leq 2 \Rightarrow \omega_d \geq \pi/2 = 1{,}57$ rad/s (**faixa** horizontal);
3. $t_s(5\%) = 3/\sigma \leq 3 \Rightarrow \sigma \geq 1$ (**semirreta** vertical);
4. $t_r(10\text{–}90\%) \approx 1{,}6/\omega_n \leq 0{,}4 \Rightarrow \omega_n \geq 4$ rad/s (**círculo**).

A região combinada é a interseção das quatro (esboço: setor de abertura $\approx 2 \times 53{,}8°$, acima de $\omega_d = 1{,}57$, à esquerda de $\sigma = 1$, fora do círculo de raio 4).

**b)** Par em $-1{,}5 \pm 2j$: $\sigma = 1{,}5 \geq 1$ ✓; $\omega_d = 2 \geq 1{,}57$ ✓; $\beta = \mathrm{arctg}(2/1{,}5) = 53{,}1° \leq 53{,}8°$ ✓; **mas** $\omega_n = \sqrt{1{,}5^2 + 2^2} = 2{,}5 < 4$ ✗ — **falha no tempo de subida** ($t_r \approx 1{,}6/2{,}5 = 0{,}64$ s > 0,4 s). Moral: atender três fronteiras não basta — a interseção exige as quatro.

---

## Questão 2 — Aproximação de 3ª por 2ª ordem

**Consulte:** teoria §2.1.8 (regra dos 5×, dominância); Exercício 2.1.2 dos exercícios resolvidos.

**a)** Par dominante: $-1 \pm 1{,}73j$ ($\zeta = 0{,}5$, $\omega_n = 2$). Regra dos 5×: $p_3 = 12 \geq 5 \times 1 = 5$ ✓ **autorizada**. Estimativas de 2ª ordem: $M_p = e^{-0{,}5\pi/\sqrt{0{,}75}} = 16{,}3\%$ e $t_p = \pi/1{,}73 = 1{,}81$ s. (Simulação com $p_3 = 12$: $M_p = 16{,}1\%$, $t_p = 1{,}90$ s — confirma.)

**b)** $p_3 = 2 < 5$: a regra **falha** — o polo real está perto do par e passa a dividir (ou tomar) a dominância. Espera-se **overshoot bem menor** que 16,3 % e resposta mais lenta (o polo real "puxa" a resposta para o comportamento de 1ª ordem). (Simulação: $M_p = 8{,}1\%$, $t_p = 2{,}46$ s.) As fórmulas de 2ª ordem **não valem mais** — é preciso simular.

**c)** O ganho DC determina o valor de regime ($y(\infty) = T(0) \times$ amplitude do degrau). Acrescentar o polo sem o fator $p_3$ no numerador faria o sistema aproximado convergir para **outro valor de regime** — a comparação de transitórios ficaria sem sentido. Regra de ouro (§2.1.7): mexeu nos polos, preserve $T(0)$.

---

## Questão 3 — Condição de ângulo e de módulo

**Consulte:** teoria §2.2.3 (condição de ângulo) e §2.2.4 (condição de módulo — "não esqueça do $A$!"); Exercício 2.2.1 dos exercícios resolvidos.

**a)** $\square_a = -2+2j$: vetor do polo $0$: $180° - 45° = 135°$; do polo $-4$: $\mathrm{arctg}(2/2) = 45°$. $\angle G(\square_a) = -(135° + 45°) = -180°$ ✓ **pertence**. Ganho: $k = \dfrac{1}{A}\prod d_{polos} = \dfrac{\sqrt{8} \times \sqrt{8}}{2} = \dfrac{8}{2} = \mathbf{4}$.

**b)** $\square_b = -1+3j$: vetor do polo $0$: $180° - \mathrm{arctg}(3/1) = 108{,}4°$; do polo $-4$: $\mathrm{arctg}(3/3) = 45°$. Soma $= 153{,}4° \neq 180°$ ✗ **não pertence ao LGR para nenhum $k$** — não se calcula ganho.

**c)** LGR de $\dfrac{1}{s(s+4)}$: trecho $(-4, 0)$ no eixo real; encontro em $-2$ ($k = a^2/4 = 4$ com $A = 1$); ramos sobem/descem na **vertical em $-2$**. $\square_a$ está sobre a vertical ✓; $\square_b$ está à esquerda dela, fora do LGR ✓ — coerente com (a) e (b).

---

## Questão 4 — Esboço completo de LGR

**Consulte:** teoria §2.2.6 (as 8 regras) e §2.2.7 (exemplos-âncora); Exercícios 2.2.3 e 2.2.4 dos exercícios resolvidos.

**a)** Polos: $-2, -4, -6$; sem zeros ($n = 3$, $m = 0$).
- **Trechos no eixo real (regra 3):** em $(-4, -2)$ há 1 polo à direita (ímpar) ✓; em $(-\infty, -6)$ há 3 (ímpar) ✓. Trechos: $(-4, -2)$ e $(-\infty, -6)$.
- **Assíntotas (regra 5):** $n - m = 3$ → ângulos $60°$, $180°$, $300°$.
- **Centroide (regra 6):** $\sigma_a = \dfrac{-2-4-6}{3} = -4$.

**b)** Característico: $(s+2)(s+4)(s+6) + k = s^3 + 12s^2 + 44s + (48 + k)$.
Routh — linha $s^1$: $\dfrac{12 \times 44 - (48 + k)}{12} = 0 \Rightarrow \mathbf{k_{crit} = 480}$.
Equação auxiliar: $12s^2 + 528 = 0 \Rightarrow s = \pm j\sqrt{44} = \pm \mathbf{6{,}63j}$.

**c)** Saída (regra 8): $-\dfrac{1}{G} = -(s^3 + 12s^2 + 44s + 48)$ → derivada $-(3s^2 + 24s + 44) = 0 \Rightarrow s = -2{,}84$ e $s = -5{,}15$.
Teste das trechos: $-2{,}84 \in (-4, -2)$ ✓ **válido**; $-5{,}15 \in (-6, -4)$, que **não** é trecho do LGR (2 polos à direita: par) ✗ **descartado**.

**d)** Estável para $\mathbf{0 < k < 480}$ (linha $s^0$ exige $48 + k > 0$; linha $s^1$, $k < 480$).

---

## Questão 5 — Projeto de avanço de fase

**Consulte:** teoria §2.3.3 (contribuição), §2.3.4 (soluções-padrão — cancelamento), §2.3.5 (ganho exato); Exercício 2.3.1 dos exercícios resolvidos.

**a)** $M_p = 16{,}3\% \Rightarrow \zeta = 0{,}5$; $\omega_d = 5 \Rightarrow \omega_n = \omega_d/\sqrt{1-\zeta^2} = 5/0{,}866 = 5{,}77$; $\sigma = \zeta\omega_n = 2{,}89$ → $\square_d = -2{,}89 + 5j$.

**b)** Fase da planta: vetor do polo $0$: $180° - \mathrm{arctg}(5/2{,}89) = 120°$; do polo $-2$: $\mathrm{arctg}(5/0{,}89) = 79{,}9°$. $\angle G(\square_d) = -199{,}9°$ → **contribuição = $199{,}9° - 180° = 19{,}9° \approx 20°$** (≤ 40° ✓).

**c)** **Cancelamento:** zero sobre o polo $-2$ ($a = 2$) → o zero contribui $79{,}9°$; o polo do controlador deve contribuir $79{,}9° - 20° = 59{,}9°$:
$$\mathrm{tg}(59{,}9°) = \frac{5}{b - 2{,}89} \Rightarrow b = 2{,}89 + \frac{5}{1{,}72} = 5{,}8$$
Ganho (com o cancelamento, $CG = \dfrac{k}{s(s+5{,}8)}$): $k = |\square_d| \cdot |\square_d + 5{,}8| = 5{,}77 \times 5{,}78 = \mathbf{33{,}4}$.
$$C(s) = 33{,}4\frac{s+2}{s+5{,}8}$$

**d)** Com o cancelamento, o sistema compensado é de **2ª ordem exata** → as fórmulas valem: $M_p \approx 16{,}3\%$, $t_p = \pi/5 = 0{,}63$ s. (Simulação: polos de MF $-2{,}9 \pm 5j$ e $-2$ — este último quase cancelado pelo zero — $M_p = 16{,}2\%$, $t_p = 0{,}628$ s ✓.) **Ajuda**: o cancelamento elimina a ordem extra, então a previsão de 2ª ordem é quase exata (§2.3.7).

---

## Questão 6 — Projeto de atraso de fase

**Consulte:** teoria §2.4.2 (mecanismo), §2.4.3 (procedimento, regra do 1/10, trade-off); Exercícios 2.4.1 e 2.4.2 dos exercícios resolvidos.

**a)** Tipo 1: $k_v = \lim_{s\to0} s \cdot \dfrac{20}{s(s+4)} = \dfrac{20}{4} = 5$ → $e_{ss}(\text{rampa}) = 1/5 = \mathbf{0{,}2}$.

**b)** Reduzir à metade ($e_{ss} = 0{,}1$) ⇒ dobrar $k_v$ ⇒ **fator 2**. Zero pela regra do 1/10: $|\mathrm{Re}(\square_d)|/10 = 2/10 = 0{,}2$; polo $= 0{,}2/2 = 0{,}1$:
$$C(s) = 20\frac{s+0{,}2}{s+0{,}1} \quad\Rightarrow\quad k_v = 5 \times 2 = 10,\ \ e_{ss} = 0{,}1\ ✓$$

**c)** Contribuição de fase no ponto $-2+4j$: $\angle(\square_d + 0{,}2) - \angle(\square_d + 0{,}1) = 114{,}2° - 115{,}4° = \mathbf{-1{,}2°}$. Efeito: pequeno roubo de fase → overshoot **sobe alguns pontos** (simulação: de $20{,}8\%$ para $23{,}7\%$). Se ficasse inaceitável: reprojetar o avanço/P com folga (§2.5.2).

**d)** O terceiro polo fica **colado no zero do atraso, perto de $-0{,}2$** (simulação: $-0{,}204$; os dominantes migram só um pouco: $-1{,}95 \pm 3{,}98j$). Efeito: uma **cauda lenta** na resposta — o erro converge ao novo valor de regime, mas devagar (§2.4.2).

---

## Questão 7 — PI para planta tipo 0

**Consulte:** teoria §2.4.4 (PI: quando usar), §2.4.6 (projeto de PI para 3ª ordem tipo 0 — mesmo procedimento); Exercício 2.4.3 dos exercícios resolvidos.

**a)** A planta é **tipo 0** e o requisito é erro **nulo** ao degrau. O atraso comum só multiplica $k_p$ por um fator finito — reduz o erro, nunca o zera. Só o **PI** (polo na origem) sobe o tipo do sistema para 1 e zera o erro. "Só use PI se estritamente necessário" — aqui é o caso.

**b)** Soma de fases em $\square_d = -1{,}73+3j$ (polo do PI na origem + polos da planta):
- do polo $0$: $180° - \mathrm{arctg}(3/1{,}73) = 120°$;
- do polo $-2$: $\mathrm{arctg}(3/0{,}27) = 84{,}9°$;
- do polo $-6$: $\mathrm{arctg}(3/4{,}27) = 35{,}1°$.
Soma $= 240°$. Falta para $-180°$: o **zero do PI deve contribuir $+60°$**:
$$\mathrm{tg}(60°) = \frac{3}{z - 1{,}73} \Rightarrow z = 1{,}73 + \frac{3}{1{,}73} = 3{,}46$$
Ganho: $k = \dfrac{|\square_d| \cdot |\square_d+2| \cdot |\square_d+6|}{4 \cdot |\square_d+3{,}46|} = \dfrac{3{,}46 \times 3{,}01 \times 5{,}22}{4 \times 3{,}46} = \mathbf{3{,}92}$.

**c)** $C(s) = 3{,}92\dfrac{s+3{,}46}{s} = 3{,}92 + \dfrac{13{,}6}{s}$ → $\mathbf{k_p = 3{,}92}$, $\mathbf{k_i = 13{,}6}$.

**d)** **Maior.** O zero do PI soma a derivada à resposta ($y_1 = y + \dot y/a$, §2.1.9) — e $a = 3{,}46$ não é desprezível frente a $\omega_d = 3$: overshoot acima dos 16,3 % projetados. (Simulação: polos de MF $-1{,}73 \pm 2{,}99j$ ✓ e $-4{,}53$; $M_p = 20{,}7\%$, erro → 0 ✓.) Ajuste fino: afastar ou aproximar o zero e re-simular — a arte do ajuste (§2.4.6).

---

## Questão 8 — Atraso de transporte

**Consulte:** teoria §2.5.4 (modelo, Padé) e §2.5.5 (fronteira $k = a + 2/\tau$); Exercício 2.5.3 dos exercícios resolvidos.

**a)** Padé de 1ª ordem com $\tau = 0{,}25$: $e^{-0{,}25s} \approx -\dfrac{s - 8}{s + 8}$ (pois $2/\tau = 8$). Logo
$$G_a(s) = -\frac{1}{s+2}\cdot\frac{s-8}{s+8} = \frac{-s+8}{(s+2)(s+8)}$$
Zero no semiplano direito em $\mathbf{+8}$ (fase não mínima — lembrar do undershoot, §2.1.9).

**b)** $k_{crit} = a + 2/\tau = 2 + 8 = \mathbf{10}$.

**c)** $k = 5 < 10$ → malha fechada **estável**; $k = 15 > 10$ → **instável** (a saída diverge). Sem o atraso, essa planta de 1ª ordem seria estável para **qualquer** $k > 0$ — o atraso criou um teto de ganho.

**d)** O atraso acrescenta fase negativa proporcional a $\omega\tau$ (no modelo de Padé: o zero RHP e o polo extra em $-2/\tau$), o que aproxima a malha da condição de $-180°$ com ganho > 1 — reduzindo a margem. Implicação: em sistemas com transporte longo, o ganho (e portanto a velocidade de resposta) fica **limitado pelo atraso**: ou se projeta com margem (avanço compensando a fase do atraso, §2.5.5), ou se reduz o atraso fisicamente (sensor/atuador mais perto, tubulação menor).

---

## Questão 9 — Conceitos de projeto

**Consulte:** teoria §2.5.1 (receita de 10 passos), §2.3.8 (regra dos 40°), §2.5.3 (PID real).

**a)** $\angle G(\square_d)$ **maior** que $-180°$ com folga: o LGR já passa pela região — **apertar os requisitos** (mais $\zeta$ e/ou $\omega_n$) e aproveitar a folga, ou aceitar um ponto melhor que o pedido. **Menor** que $-220°$: seria necessário avanço $> 40°$ — fora do limite prático: usar **dois estágios de avanço em cascata** ou repensar os requisitos/a arquitetura.

**b)** Avanço grande exige o polo do controlador muito à esquerda do zero ($b \gg a$): o ganho necessário explode, a banda passante amplifica ruído de medição, o sinal de controle satura o atuador e a deformação do LGR joga os outros polos de malha fechada para regiões ruins. "Fusca não vira Ferrari": o limite de 40° é o preço físico da deformação.

**c)** O termo derivativo puro é **impróprio** (responderia antes da entrada) e sua derivada do degrau é um impulso — picos gigantescos de controle, saturação e amplificação brutal de ruído. A forma implementada é
$$C(s) = P + \frac{I}{s} + D\frac{N}{1 + N/s}$$
com polo de filtro em $-N$ — ou seja, o que roda na prática é um **PI-Lead** (PI + avanço de fase).

---

## Bônus — Desafio de Beakman

**Consulte:** teoria §2.4.6 (desafio) e Lab 08, Parte 4.

Característico com $C = k\dfrac{s+0{,}5}{s}$: $s(s-1)(s+2)(s+10) + 20k(s+0{,}5) = s^4 + 11s^3 + 8s^2 + (20k-20)s + 10k = 0$.
Routh: linha $s^2$: $(108-20k)/11$; linha $s^1$ (numerador): $-400k^2 + 1350k - 2160$.
Discriminante: $1350^2 - 4 \times 400 \times 2160 = -1{,}633 \times 10^6 < 0$ → a parábola (concavidade para baixo) é **sempre negativa** → nenhum $k > 0$ estabiliza.
**Geometria (LGR):** o ramo que nasce no polo $+1$ permanece no semiplano direito para todo $k$ — o zero em $-0{,}5$ não é capaz de puxá-lo de volta (assíntotas em $\pm 60°$ e $180°$ a partir da centroide $-3{,}5$ não cruzam a origem ao encontro desse ramo). O LGR já anunciava o que Routh confirmou.
(Curiosidade — não exigida: com o zero em $-0{,}123$ existe faixa estável $1{,}22 < k < 4{,}44$, mas a resposta tem overshoot de quase 200 %: estabilidade não é desempenho.)
