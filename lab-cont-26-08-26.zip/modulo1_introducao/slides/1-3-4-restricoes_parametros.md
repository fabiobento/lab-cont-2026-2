---
marp: true
theme: default
paginate: true
math: katex
---

# Restrições sobre Parâmetros para a Estabilidade

**Encontrando a faixa de valores que mantém o sistema BIBO estável**

*Sistemas de Controle — Domínio de Laplace*

---

## Objetivo da seção

Dada a Função de Transferência de um sistema com um ou mais **parâmetros indeterminados**, determinar para quais condições desses parâmetros o sistema é **BIBO estável**.

---

## Por que isso importa?

- A estabilidade é determinada pela parte real dos pólos — raízes do denominador da Função de Transferência;
- Com o denominador numérico, já sabemos usar o critério de Routh-Hurwitz;
- Mas e se o denominador tiver um parâmetro que pode variar — por exemplo, o **ganho**?

> Saber para quais valores do parâmetro o sistema é estável permite **projetar o controlador longe da instabilidade** e, ao testar o sistema real, **saber quais valores evitar**.

---

## O método

Construímos a Tabela de Routh tratando o parâmetro variável como se fosse um número real qualquer, e impomos condições sobre esse parâmetro para que **todos os elementos da primeira coluna tenham o mesmo sinal** — exatamente como fizemos nos exemplos literais de 2ª e 3ª ordem.

---

## Exemplo introdutório

$$
\mathrm{Den}(s) = s^3+6s^2+11s+6+k
$$

| | col 1 | col 2 |
|---|---|---|
| $s^3$ | $1$ | $11$ |
| $s^2$ | $6$ | $6+k$ |
| $s^1$ | $\dfrac{60-k}{6}$ | |
| $s^0$ | $6+k$ | |

$$
s^1 = \frac{6\cdot 11 - 1\cdot(6+k)}{6} = \frac{60-k}{6}
$$

Para estabilidade: $\dfrac{60-k}{6}>0$ e $6+k>0 \ \Longrightarrow\ -6<k<60$.

---

## O que acontece nas fronteiras?

**Em $k=60$:** $\mathrm{Den}(s)=s^3+6s^2+11s+66 = (s+6)(s+\sqrt{11}\,i)(s-\sqrt{11}\,i)$

$$
(s+\sqrt{11}i)(s-\sqrt{11}i) = s^2-(\sqrt{11})^2i^2 = s^2-11(-1) = s^2+11
$$

Par de pólos complexos conjugados **sobre o eixo imaginário** &rarr; sistema instável.

**Em $k=-6$:** $\mathrm{Den}(s)=s^3+6s^2+11s = s(s^2+6s+11)$

Uma raiz é $s=0$ &rarr; sistema também instável.

> Fora do intervalo $(-6,60)$: para $k>60$ há **duas** trocas de sinal (duas raízes com parte real positiva); para $k<-6$ há **uma** troca de sinal (uma raiz positiva).

---

## Revisitando as vantagens (e riscos) da realimentação

Na seção anterior vimos que a realimentação pode **estabilizar** um sistema instável em malha aberta — mas também pode **instabilizar** um sistema estável em malha aberta. Em alguns casos, o ganho adequado estabiliza, e o ganho inadequado desestabiliza de novo. Vamos ver três exemplos com Routh-Hurwitz.

---

## Exemplo 1 — instável em malha aberta, estabilizável

$$
G(s) = \frac{1}{s^2+2s-3} \qquad\qquad T(s)=\frac{k}{s^2+2s-3+k}
$$

Pólos de $G(s)$: $1$ e $-3$ &rarr; **instável em malha aberta** (o ganho, sozinho, não alteraria isso).

| | col 1 | col 2 |
|---|---|---|
| $s^2$ | $1$ | $-3+k$ |
| $s^1$ | $2$ | |
| $s^0$ | $-3+k$ | |

Estável $\iff -3+k>0 \iff k>3$.

> Sistema instável em malha aberta, estabilizável em malha fechada com **controle proporcional**, desde que $k>3$.

---

## Exemplo 2 — estável em malha aberta, pode instabilizar

$$
G(s) = \frac{10}{s^3+8s^2+12s+10} \qquad\qquad T(s)=\frac{10k}{s^3+8s^2+12s+10+10k}
$$

O denominador de $G(s)$ não tem troca de sinal na 1ª coluna da tabela de Routh &rarr; **estável em malha aberta**.

| | col 1 | col 2 |
|---|---|---|
| $s^3$ | $1$ | $12$ |
| $s^2$ | $8$ | $10+10k$ |
| $s^1$ | $\dfrac{43-5k}{4}$ | |
| $s^0$ | $10+10k$ | |

Estável $\iff k<8{,}6$ (e $k>-1$).

> Sistema estável em malha aberta que **fica instável em malha fechada** se usarmos ganho $k \geq 8{,}6$.

---

## Exemplo 3 — instável em malha aberta, estável só numa faixa

$$
G(s) = \frac{10}{s^3+11s^2+8s-20} \qquad\qquad T(s)=\frac{10k}{s^3+11s^2+8s-20+10k}
$$

O coeficiente negativo já indica pelo menos uma raiz com parte real positiva — **instável em malha aberta** (nem precisamos verificar).

| | col 1 | col 2 |
|---|---|---|
| $s^3$ | $1$ | $8$ |
| $s^2$ | $11$ | $-20+10k$ |
| $s^1$ | $\dfrac{108-10k}{11}$ | |
| $s^0$ | $-20+10k$ | |

Estável $\iff 2<k<10{,}8$.

> Note que em $k=0$ o denominador malha fechada coincide com o malha aberta — instável, como esperado. Este sistema **só é estabilizável dentro de uma faixa específica** de ganhos.

---

## E se houver mais de um parâmetro?

O procedimento é o mesmo: construímos a Tabela de Routh carregando as variáveis literais e, ao final, impomos que todos os elementos da primeira coluna tenham o mesmo sinal. O resultado pode ser uma restrição sobre cada variável **isoladamente**, ou uma restrição que as relaciona **em conjunto**.

---

## Exemplo com dois parâmetros — k e $k_t$

$$
T(s) = \frac{k}{s^2-s-2+k_t s+k}
$$

| | col 1 | col 2 |
|---|---|---|
| $s^2$ | $1$ | $-2+k$ |
| $s^1$ | $k_t-1$ | |
| $s^0$ | $-2+k$ | |

Estável $\iff k_t>1 \ \text{ e } \ k>2$.

Neste caso, as duas condições são **independentes** — uma variável não afeta a restrição da outra.

---

## Exemplo com dois parâmetros — a e b

$$
T(s) = \frac{as+b}{s^3+3s^2+2s-1+as+b}
$$

| | col 1 | col 2 |
|---|---|---|
| $s^3$ | $1$ | $2+a$ |
| $s^2$ | $3$ | $-1+b$ |
| $s^1$ | $\dfrac{7+3a-b}{3}$ | |
| $s^0$ | $-1+b$ | |

Estável $\iff b>1 \ \text{ e } \ a>\dfrac{b-7}{3}$.

> Diferente do caso anterior, aqui a escolha de **uma** variável afeta a faixa admissível da **outra**.

---

## Exemplo com dois parâmetros — k e a

$$
T(s) = \frac{ks+a}{s^3+3s^2+2s+k(s+a)}
$$

| | col 1 | col 2 |
|---|---|---|
| $s^3$ | $1$ | $2+k$ |
| $s^2$ | $3$ | $ka$ |
| $s^1$ | $\dfrac{6+3k-ka}{3}$ | |
| $s^0$ | $ka$ | |

Estável $\iff ka>0 \ \text{ e } \ 3k-ka>-6$.

---

## Vendo o acoplamento na prática

Fixando valores de $a$, a faixa de $k$ estável muda:

- Com $a=2$: precisamos de $k>0$;
- Com $a=4$: precisamos de $0<k<6$.

> As duas condições, $ka>0$ e $3k-ka>-6$, acoplam as variáveis — a faixa estável de $k$ depende do valor escolhido para $a$, e vice-versa.

---

## Nem sempre é possível estabilizar

$$
T(s) = \frac{k}{s^2-s-6+k(s-1)}
$$

Tente encontrar um valor de $k$ que deixe este sistema estável — construa a Tabela de Routh e verifique as condições impostas na 1ª coluna.

> Este é um lembrete importante: para alguns sistemas, **nenhum** valor do parâmetro é capaz de garantir a estabilidade.

---

## Síntese

- Com **um** parâmetro: montamos a Tabela de Routh e impomos que todos os elementos da 1ª coluna tenham o mesmo sinal &rarr; obtemos a faixa de valores estável;
- Com **mais de um** parâmetro: mesmo procedimento — as restrições resultantes podem ser independentes ou podem acoplar as variáveis entre si;
- Nas fronteiras da faixa estável, o polinômio tem raízes sobre o eixo imaginário (ou na origem) — o sistema está na iminência da instabilidade;
- Em alguns sistemas, **nenhum** valor do(s) parâmetro(s) garante estabilidade.
