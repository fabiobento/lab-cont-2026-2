---
marp: true
theme: default
paginate: true
math: katex
---

# O Critério de Routh-Hurwitz

**Verificando a BIBO estabilidade sem calcular os pólos**

*Sistemas de Controle — Domínio de Laplace*

---

## Objetivo da seção

Dada a Função de Transferência de um sistema, verificar se ele é ou não **BIBO estável** — sem a necessidade de calcular ou explicitar os pólos.

---

## Motivação: por que não simplesmente calcular os pólos?

- A BIBO estabilidade é determinada pela parte real dos pólos — raízes do denominador da Função de Transferência;
- Para BIBO estabilidade, **todos** os pólos devem ter parte real negativa;
- Calcular todos os pólos funciona, mas é trabalhoso para polinômios de grau elevado.

> O **Método (ou Critério) de Routh-Hurwitz** — abreviado RH — permite concluir isso analisando apenas os **coeficientes** do polinômio.

---

## Aquecendo: 1ª e 2ª ordem já fatoradas

Lembre-se: os fatores são do tipo $(s-p)$, então $s+1$ corresponde a pólo $-1$, e $s-1$ a pólo $+1$.

| $\dfrac{1}{s+1}$ | $\dfrac{1}{s}$ | $\dfrac{1}{s-1}$ |
|---|---|---|
| Estável (pólo $-1$) | Instável (pólo $0$) | Instável (pólo $+1$) |

Fatorado de 2ª ordem: basta que **todos os fatores sejam positivos**.

| $\dfrac{1}{(s+1)(s+2)}$ | $\dfrac{1}{s(s+1)}$ | $\dfrac{1}{(s+1)(s-2)}$ |
|---|---|---|
| Estável | Instável | Instável |

---

## Construindo a Tabela de Routh — regras gerais

- A tabela tem $n+1$ linhas, de $s^n$ até $s^0$, onde $n$ é o grau do polinômio;
- As duas primeiras linhas recebem os coeficientes do polinômio, da esquerda para a direita, **alternando** entre as linhas (começando pela primeira);
- As linhas seguintes são preenchidas por **multiplicação cruzada** das duas linhas anteriores, dividida pelo **pivô** (primeiro elemento da linha anterior);
- Elementos inexistentes são considerados $0$.

---

## Exemplo — 2ª ordem: Den(s) = s² + 3s + 2

| | col 1 | col 2 |
|---|---|---|
| $s^2$ | $1$ | $2$ |
| $s^1$ | $3$ | $0$ |
| $s^0$ | $2$ | |

$$
s^0 = \frac{3\cdot 2 - 1\cdot 0}{3} = 2
$$

1ª coluna: $1,\,3,\,2$ — todos positivos.

> O polinômio é **Hurwitz**: todas as raízes têm parte real negativa. Se for o denominador de $G(s)$, o sistema é **BIBO estável**.

---

## Exemplo — 2ª ordem: Den(s) = s² + s − 2

| | col 1 | col 2 |
|---|---|---|
| $s^2$ | $1$ | $-2$ |
| $s^1$ | $1$ | $0$ |
| $s^0$ | $-2$ | |

$$
s^0 = \frac{1\cdot(-2) - 1\cdot 0}{1} = -2
$$

1ª coluna: $1,\,1,\,-2$ — **troca de sinal**.

> O polinômio **não** é Hurwitz — o sistema **não é estável**.

---

## Generalizando — 2ª ordem: Den(s) = s² + as + b

| | col 1 | col 2 |
|---|---|---|
| $s^2$ | $1$ | $b$ |
| $s^1$ | $a$ | $0$ |
| $s^0$ | $b$ | |

$$
s^0 = \frac{a\cdot b - 1\cdot 0}{a} = b
$$

> Hurwitz $\iff a>0 \text{ e } b>0$.

Coerente com o fato de que, se todas as raízes têm parte real negativa, todos os coeficientes do polinômio devem ser positivos.

---

## Exemplo — 3ª ordem: Den(s) = s³ + 6s² + 11s + 6

| | col 1 | col 2 |
|---|---|---|
| $s^3$ | $1$ | $11$ |
| $s^2$ | $6$ | $6$ |
| $s^1$ | $10$ | $0$ |
| $s^0$ | $6$ | |

$$
s^1=\frac{6\cdot 11-1\cdot 6}{6}=10 \qquad s^0=\frac{10\cdot 6-6\cdot 0}{10}=6
$$

1ª coluna: $1,\,6,\,10,\,6$ — todos positivos.

> Polinômio **Hurwitz** — sistema **BIBO estável**.

---

## Exemplo — 3ª ordem: Den(s) = s³ + 6s² + 11s + 72

| | col 1 | col 2 |
|---|---|---|
| $s^3$ | $1$ | $11$ |
| $s^2$ | $6$ | $72$ |
| $s^1$ | $-1$ | $0$ |
| $s^0$ | $72$ | |

$$
s^1=\frac{6\cdot 11-1\cdot 72}{6}=-1 \qquad s^0=\frac{-1\cdot 72-6\cdot 0}{-1}=72
$$

1ª coluna: $1,\,6,\,-1,\,72$ — **duas trocas de sinal**.

> Não é Hurwitz — se for o denominador de $G(s)$, o sistema **não é BIBO estável**.

---

## Generalizando — 3ª ordem: Den(s) = s³ + as² + bs + c

| | col 1 | col 2 |
|---|---|---|
| $s^3$ | $1$ | $b$ |
| $s^2$ | $a$ | $c$ |
| $s^1$ | $\dfrac{ab-c}{a}$ | |
| $s^0$ | $c$ | |

$$
s^0 = \frac{\left(\frac{ab-c}{a}\right)c - a\cdot 0}{\frac{ab-c}{a}} = c
$$

> Hurwitz $\iff a>0,\ c>0 \text{ e } ab>c$.

---

## Exemplo — 4ª ordem: Den(s) = s⁴ + 2s³ + 4s² + 10s + 5

| | col 1 | col 2 | col 3 |
|---|---|---|---|
| $s^4$ | $1$ | $4$ | $5$ |
| $s^3$ | $2$ | $10$ | |
| $s^2$ | $-1$ | $5$ | |
| $s^1$ | $20$ | $0$ | |
| $s^0$ | $5$ | | |

$$
s^2:\ \frac{2\cdot4-1\cdot10}{2}=-1,\quad \frac{2\cdot5-1\cdot0}{2}=5
$$

$$
s^1:\ \frac{-1\cdot10-2\cdot5}{-1}=20 \qquad\qquad s^0:\ \frac{20\cdot5-(-1)\cdot0}{20}=5
$$

1ª coluna: $1,\,2,\,-1,\,20,\,5$ — **duas trocas de sinal**.

> Não é Hurwitz. Além disso: **2 trocas de sinal ⇒ 2 raízes com parte real positiva**.

---

## Generalizando: a Tabela de Routh para grau n

$$
\mathrm{Den}(s)=s^n+a_{n-1}s^{n-1}+\cdots+a_2 s^2+a_1 s+a_0
$$

| | | | | |
|---|---|---|---|---|
| $s^n$ | $1$ | $a_{n-2}$ | $a_{n-4}$ | $\cdots$ |
| $s^{n-1}$ | $a_{n-1}$ | $a_{n-3}$ | $a_{n-5}$ | $\cdots$ |
| $s^{n-2}$ | | | | |
| $s^{n-3}$ | | | | |
| $\vdots$ | | | | |
| $s^0$ | | | | |

$n+1$ linhas; coeficientes copiados alternando entre as duas primeiras linhas, começando por $s^n$.

---

## Generalizando (n par): renomeando as duas primeiras linhas

| | | | | | | |
|---|---|---|---|---|---|---|
| $s^n$ | $a_1$ | $a_2$ | $a_3$ | $\cdots$ | $a_{n/2-1}$ | $a_{n/2}$ |
| $s^{n-1}$ | $b_1$ | $b_2$ | $b_3$ | $\cdots$ | $b_{n/2-1}$ | |

Por comodidade, chamamos os elementos da linha $s^n$ de $a_1,a_2,\dots,a_{n/2}$ e os da linha $s^{n-1}$ de $b_1,b_2,\dots,b_{n/2-1}$.

---

## Preenchendo a linha $s^{n-2}$ (elementos c)

$$
c_1=\frac{b_1a_2-a_1b_2}{b_1} \qquad c_2=\frac{b_1a_3-a_1b_3}{b_1} \qquad \cdots
$$

$$
c_{n/2-2}=\frac{b_1a_{n/2-1}-a_1b_{n/2-1}}{b_1} \qquad c_{n/2-1}=\frac{b_1a_{n/2}-a_1\cdot 0}{b_1}=a_{n/2}
$$

Sempre usamos os elementos $a_1$ e $b_1$ (1ª coluna) com os elementos da coluna seguinte à que estamos calculando, nas duas linhas anteriores. O próximo elemento, $c_{n/2}$, seria $0$.

---

## Linha $s^{n-3}$ (elementos d) e o padrão da tabela

$$
d_1=\frac{c_1b_2-b_1c_2}{c_1} \qquad d_2=\frac{c_1b_3-b_1c_3}{c_1} \qquad \cdots
$$

- Mesmo procedimento, agora usando as duas linhas **anteriores** ($s^{n-1}$ e $s^{n-2}$), com pivô $c_1$;
- De uma linha par para uma linha ímpar, a tabela perde uma coluna;
- O último elemento de uma linha par é repetido como último elemento da linha par seguinte;
- Continuamos até a linha $s^0$.

---

## O Critério de Routh-Hurwitz: lendo a primeira coluna

> Se **todos** os elementos da 1ª coluna tiverem o **mesmo sinal**, todas as raízes do polinômio têm parte real negativa (polinômio Hurwitz).

- O número de **trocas de sinal** na 1ª coluna = número de raízes com parte real **positiva**;
- Para BIBO estabilidade precisamos de **zero** trocas de sinal;
- Ao encontrar a primeira troca de sinal, já podemos concluir que o sistema não é BIBO estável — não é preciso terminar a tabela.

---

## Caso especial: elemento nulo na primeira coluna

Um zero na 1ª coluna impede a divisão necessária para continuar a tabela. Ele indica a presença de:

- Raízes sobre o eixo imaginário (incluindo a origem);
- Par de raízes complexas conjugadas com parte real nula;
- Raízes simétricas em relação ao eixo imaginário — mesma parte imaginária, parte real oposta (ex.: $+1$ e $-1$; $+5$ e $-5$).

> Em qualquer um desses casos, o sistema **não** é BIBO estável — para este curso, basta parar a construção da tabela ao encontrar um zero na 1ª coluna.

*Existe uma técnica para contornar o zero e continuar a tabela (ver bibliografia de controle de sistemas lineares), mas foge do escopo deste curso.*

---

## Síntese: o que levar desta sessão

- A Tabela de Routh transforma o teste de estabilidade em uma sequência de operações aritméticas com os coeficientes — sem calcular raízes;
- Todos os sinais iguais na 1ª coluna ⇒ sistema BIBO estável;
- Troca de sinal ou elemento nulo na 1ª coluna ⇒ sistema não é BIBO estável;
- O número de trocas de sinal indica quantas raízes têm parte real positiva.

Pratique construindo a Tabela de Routh para polinômios de sua escolha.