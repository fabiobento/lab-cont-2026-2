---
marp: true
theme: default
paginate: true
math: katex
---

# As Vantagens da Realimentação

**Do sistema malha aberta ao sistema malha fechada**

*Sistemas de Controle — Domínio de Laplace*

---

## Objetivos da seção

- Dada a Função de Transferência **malha aberta** de um sistema, obter a Função de Transferência **malha fechada**;
- Explicar as **vantagens** do controle com realimentação.

---

## Uma simplificação de notação

Neste curso só trabalhamos com **BIBO estabilidade**. Daqui em diante, "estável" / "instável" significa **BIBO estável** / **BIBO instável**.

Em outros cursos você encontrará outros tipos de estabilidade — mas aqui a referência é sempre a BIBO.

---

## O sistema malha fechada

![w:600](diagrama_malha_fechada.png)

$G(s)$ é a Função de Transferência do sistema; o controlador é um ganho simples $k$.

Já sabemos $G(s) = \dfrac{Y(s)}{U(s)}$. Queremos agora $\dfrac{Y(s)}{R(s)}$ — assim podemos calcular $Y(s)$ para diferentes referências e avaliar a estabilidade **malha fechada**.

---

## Escrevendo Y(s) em função de R(s)

Do diagrama de blocos:

$$
U(s) = k\,E(s) \qquad Y(s) = G(s)\,U(s) \qquad E(s) = R(s) - Y(s)
$$

Logo:

$$
Y(s) = G(s)\,k\,E(s) = k\,G(s)\big[R(s) - Y(s)\big]
$$

$$
Y(s) = k\,G(s)\,R(s) - k\,G(s)\,Y(s)
$$

---

## Isolando Y(s)/R(s)

Passando o termo com $Y(s)$ para a esquerda e colocando $Y(s)$ em evidência:

$$
Y(s) + k\,G(s)\,Y(s) = k\,G(s)\,R(s)
$$

$$
\frac{Y(s)}{R(s)} = \frac{k\,G(s)}{1+k\,G(s)}
$$

Essa razão é a **Função de Transferência malha fechada**, comumente denotada $T(s)$:

$$
T(s) = \frac{k\,G(s)}{1+k\,G(s)}
$$

---

## Em termos dos polinômios de G(s)

Escrevendo a malha aberta como razão de polinômios, $G(s)=\dfrac{N_G(s)}{D_G(s)}$:

$$
\frac{Y(s)}{R(s)} = \frac{k\,\dfrac{N_G(s)}{D_G(s)}}{1+k\,\dfrac{N_G(s)}{D_G(s)}}
$$

Simplificando:

$$
T(s) = \frac{k\,N_G(s)}{D_G(s)+k\,N_G(s)}
$$

O sistema malha fechada pode agora ser representado inteiramente por $T(s)$.

---

## Vantagem 1 — estabilizar um sistema instável

Com realimentação e controle proporcional, podemos tornar **estável em malha fechada** um sistema **instável em malha aberta** — isso não vale para todos os sistemas, mas vale para alguns. O controle malha aberta nunca consegue isso: o ganho só altera o numerador, não a estabilidade.

---

## Exemplo — funciona

$$
G(s)=\frac{1}{s-1} \qquad\Longrightarrow\qquad T(s)=\frac{k}{s-1+k}
$$

Malha aberta: pólo em $s=1$ — **instável**.

Malha fechada: pólo em $s = 1-k$. Para $k>1$ (por exemplo $k=2$), o pólo é negativo — o sistema malha fechada é **estável**.

---

## Contraexemplo — nem sempre funciona

$$
G(s)=\frac{1}{s^2-2s-3} \qquad\Longrightarrow\qquad T(s)=\frac{k}{s^2-2s-3+k}
$$

Este sistema malha fechada permanece **instável para qualquer valor de $k$** — verifique com o critério de Routh-Hurwitz.

> Sistemas assim exigem controladores mais elaborados (assunto de outros cursos). Por ora, basta saber que a realimentação **pode** estabilizar alguns sistemas instáveis em malha aberta, mas não todos.

---

## Vantagem 2 — menor sensibilidade a erros de modelagem

Vamos comparar malha aberta e malha fechada quando há erro no modelo. Para simplificar (sem perder generalidade), $G(s) = A$ (um ganho).

![w:600](diagrama_malha_fechada.png)

**Saída nominal** (modelo correto, $A$):

$$
Y_N(s) = k\,A\,R(s) \quad \text{(malha aberta)} \qquad\qquad Y_N(s)=\frac{kA}{1+kA}R(s) \quad \text{(malha fechada)}
$$

---

## Saída real, com erro de modelagem B

Suponha que o valor **correto** do ganho da planta seja $A+B$ (não $A$):

$$
Y_R(s) = k\,(A+B)\,R(s) \quad \text{(malha aberta)}
$$

$$
Y_R(s) = \frac{k(A+B)}{1+k(A+B)}\,R(s) \quad \text{(malha fechada)}
$$

---

## O erro entre saída real e nominal

**Malha aberta:**

$$
Y_R(s)-Y_N(s) = k(A+B)R(s) - kAR(s) = k\,B\,R(s)
$$

**Malha fechada:**

$$
Y_R(s)-Y_N(s) = \frac{k(A+B)}{1+k(A+B)}R(s) - \frac{kA}{1+kA}R(s) = \frac{kB}{\big(1+k(A+B)\big)(1+kA)}\,R(s)
$$

---

## Comparando o erro relativo

Para facilitar a comparação, analisamos o **erro relativo** (erro sobre o valor real):

$$
\text{Malha aberta:} \qquad \frac{Y_R(s)-Y_N(s)}{Y_R(s)} = \frac{B}{A+B}
$$

$$
\text{Malha fechada:} \qquad \frac{Y_R(s)-Y_N(s)}{Y_R(s)} = \frac{1}{1+kA}\cdot\frac{B}{A+B}
$$

> O erro malha fechada é o erro malha aberta multiplicado por $\dfrac{1}{1+kA}$. Se $kA>0$, o erro malha fechada é **sempre menor**.

---

## Exemplo numérico

Erro de modelagem de **20%** ($B = 0{,}2A$):

**Malha aberta:**
$$
\frac{Y_R-Y_N}{Y_R} = \frac{0{,}2A}{1{,}2A} = 0{,}17 \quad (17\%\text{ de variação na saída})
$$

**Malha fechada, com $kA=10$:**
$$
\frac{Y_R-Y_N}{Y_R} = \frac{0{,}17}{1+10} = 0{,}015 \quad (1{,}5\%)
$$

**Malha fechada, com $kA=2$:**
$$
\frac{Y_R-Y_N}{Y_R} = \frac{0{,}17}{1+2} = 0{,}056 \quad (5{,}6\%)
$$

Quanto maior o ganho $k$, menor o efeito dos erros de modelagem na saída.

---

## Vantagem 3 — rejeição de perturbações

A perturbação $N(s)$ representa entradas não manipuladas (rajadas de vento, temperatura ambiente, etc.). Ela se soma à saída do controlador:

![w:600](diagrama_perturbacao.png)

Novamente, para simplificar, $G(s)=A$. As saídas nominais ($N(s)=0$) são as mesmas de antes.

---

## Saída real com perturbação — malha aberta

$$
Y_R(s) = k\,A\,R(s) + A\,N(s)
$$

Basta somar o efeito direto da perturbação à saída nominal.

---

## Saída real com perturbação — malha fechada

Do diagrama de blocos:

$$
E(s) = R(s)-Y(s) \qquad U(s) = k\,E(s)+N(s) \qquad U(s) = k\,R(s)-k\,Y(s)+N(s)
$$

$$
Y_R(s) = \frac{kA}{1+kA}\,R(s) + \frac{A}{1+kA}\,N(s)
$$

---

## Variação da saída devido à perturbação

**Malha aberta:**

$$
Y_R(s) - Y_N(s) = A\,N(s)
$$

**Malha fechada:**

$$
Y_R(s) - Y_N(s) = \frac{1}{1+kA}\,A\,N(s)
$$

> Novamente, para $kA>0$, o efeito da perturbação é **menor em malha fechada** — e quanto maior o ganho, menor esse efeito. Em malha aberta, não há como alterar o efeito da perturbação na saída.

---

## Resumo: vantagens do controle com realimentação

1. Pode **estabilizar** um sistema instável em malha aberta (nem sempre, mas em muitos casos);
2. **Reduz a sensibilidade** a erros de modelagem e de implementação do controlador;
3. **Reduz o efeito de perturbações** externas na saída.

---

## Então por que não usar sempre malha fechada?

- A realimentação exige um **componente a mais**: um sensor, para medir constantemente a saída e subtraí-la da entrada;
- Sensores podem ser **caros** e adicionar complexidade desnecessária;
- Se o sistema já é estável em malha aberta e os erros de modelagem/implementação e as perturbações são toleráveis, o controle **malha aberta** pode ser mais vantajoso;
- Em alguns casos, um ganho **inadequado** pode até tornar o sistema malha fechada **instável**, mesmo com o sistema malha aberta sendo estável — veremos um exemplo na próxima seção.
