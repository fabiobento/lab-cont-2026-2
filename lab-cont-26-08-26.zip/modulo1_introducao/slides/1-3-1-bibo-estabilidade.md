---
marp: true
theme: default
paginate: true
math: katex
---

# BIBO Estabilidade

**Bounded Input → Bounded Output**

*Sistemas de Controle — Domínio de Laplace*

---

## Objetivos da Seção

Ao final você será capaz de:

- Explicar e ilustrar a **BIBO estabilidade**;
- Citar as condições **necessárias e suficientes** para que um sistema seja BIBO estável.

---

## Definição

**BIBO** — *Bounded Input, Bounded Output* — entrada limitada, saída limitada.

> Um sistema é **BIBO estável** se, e somente se, para toda e qualquer entrada limitada, a saída for limitada.

$$
u(t)\ \text{limitada} \ \Longrightarrow\ y(t)\ \text{limitada} \quad \forall\, u(t)
$$

Se existir **uma única** entrada limitada para a qual a saída diverge, o sistema **não** é BIBO estável — a propriedade é do sistema, não de um par entrada/saída específico.

---

## Transformada de Laplace — parte 1: sinais elementares

| Sinal | f(t) | F(s) | |
|---|---|---|---|
| Degrau | $1$ | $\dfrac{1}{s}$ | limitado |
| Rampa | $t$ | $\dfrac{1}{s^2}$ | diverge |
| Parábola | $\dfrac{t^2}{2}$ | $\dfrac{1}{s^3}$ | diverge |
| Exponencial | $e^{at}$ | $\dfrac{1}{s-a}$ | limitado se $a<0$; diverge se $a>0$ |

Rampa e parábola sempre divergem; a exponencial depende do sinal de $a$.

---

## Transformada de Laplace — parte 2: seno, cosseno e modulações exponenciais

| Sinal | f(t) | F(s) |
|---|---|---|
| Seno | $\text{sen}(\omega t)$ | $\dfrac{\omega}{s^2+\omega^2}$ |
| Cosseno | $\cos(\omega t)$ | $\dfrac{s}{s^2+\omega^2}$ |
| Exp. × seno | $e^{at}\,\text{sen}(\omega t)$ | $\dfrac{\omega}{(s-a)^2+\omega^2}$ |
| Exp. × cosseno | $e^{at}\cos(\omega t)$ | $\dfrac{s-a}{(s-a)^2+\omega^2}$ |

Seno e cosseno puros são limitados; multiplicados por exponencial, dependem do sinal de $a$.

---

## Transformada de Laplace — parte 3: multiplicação por t

| Sinal | f(t) | F(s) |
|---|---|---|
| t × seno | $t\,\text{sen}(\omega t)$ | $\dfrac{2\omega s}{(s^2+\omega^2)^2}$ |
| t × cosseno | $t\cos(\omega t)$ | $\dfrac{s^2-\omega^2}{(s^2+\omega^2)^2}$ |
| t × exponencial | $t\,e^{at}$ | $\dfrac{1}{(s-a)^2}$ |

$t\cdot\text{sen}$ e $t\cdot\cos$ sempre divergem; $t\cdot e^{at}$ depende novamente do sinal de $a$.

---

## Padrão: pólos reais e na origem

**Limitado**

$$
\frac{1}{s+a}\ \to\ e^{-at} \qquad \frac{1}{(s+a)^2}\ \to\ t\,e^{-at}
$$

$$
\frac{1}{s}\ \to\ 1\ \ (\text{degrau, pólo simples na origem})
$$

**Diverge** (com $a>0$)

$$
\frac{1}{s-a}\ \to\ e^{at} \qquad \frac{1}{(s-a)^2}\ \to\ t\,e^{at}
$$

$$
\frac{1}{s^2}\ \to\ t \qquad \frac{1}{s^3}\ \to\ \frac{t^2}{2}\ \ (\text{pólos múltiplos na origem})
$$

---

## Padrão: pólos complexos conjugados

Fatorando o denominador (fórmula de Bhaskara):

**Limitado**

$$
\frac{\omega}{(s+a-\omega i)(s+a+\omega i)} = e^{-at}\,\text{sen}(\omega t)
$$

**Diverge** (com $a>0$)

$$
\frac{\omega}{(s-a+\omega i)(s-a-\omega i)} = e^{at}\,\text{sen}(\omega t)
$$

Com $a=0$ (pólos sobre o eixo imaginário), o sinal é limitado se o par **não** for repetido — mas diverge se repetido.

---

## Síntese: condições para um sinal ser limitado

- Pólo real **negativo** → sinal limitado; pólo real **positivo** → diverge;
- Pólos complexos conjugados com parte real **negativa** → limitado; parte real **positiva** → diverge;
- Pólo **simples** na origem, ou par **simples** de pólos complexos conjugados com parte real nula → limitado;
- Pólo **repetido** na origem, ou par **repetido** com parte real nula → diverge.

---

## Generalizando: Função de Transferência e entrada fatoradas

$G(s)$ tem $n$ pólos; $U(s)$, a Transformada da entrada, tem $m$ pólos adicionais:

$$
G(s)=\frac{N_G(s)}{(s-p_1)(s-p_2)\cdots(s-p_{n-1})(s-p_n)}
$$

$$
U(s)=\frac{N_U(s)}{(s-p_{n+1})(s-p_{n+2})\cdots(s-p_{n+m-1})(s-p_{n+m})}
$$

---

## Y(s) = G(s)·U(s) em frações parciais

$$
Y(s)=\frac{N_G(s)\,N_U(s)}{(s-p_1)(s-p_2)\cdots(s-p_{n+m-1})(s-p_{n+m})}
$$

$$
Y(s)=\frac{r_1}{s-p_1}+\frac{r_2}{s-p_2}+\cdots+\frac{r_{n+m-1}}{s-p_{n+m-1}}+\frac{r_{n+m}}{s-p_{n+m}}
$$

---

## Separando as frações: pólos de G(s) × pólos de U(s)

$$
Y(s)=Y_G(s)+Y_U(s)
$$

**Referentes a G(s)**
$$
Y_G(s)=\frac{r_1}{s-p_1}+\cdots+\frac{r_n}{s-p_n}
$$

**Referentes a U(s)**
$$
Y_U(s)=\frac{r_{n+1}}{s-p_{n+1}}+\cdots+\frac{r_{n+m}}{s-p_{n+m}}
$$

Os pólos de $Y_U(s)$ são exatamente os de $U(s)$. Como $u(t)$ é limitada por hipótese, $y_U(t)$ também é sempre limitada:

$$
y(t)=y_G(t)+\underbrace{y_U(t)}_{\text{sempre limitado}}
$$

---

## Condição necessária: basta olhar para os pólos de G(s)

Como $y_U(t)$ já é sempre limitada, a limitação de $y(t)$ depende inteiramente de $y_G(t)$: **todas** as frações parciais associadas aos pólos de $G(s)$ precisam corresponder a sinais limitados.

> Se apenas **um** pólo de $G(s)$ tiver parte real positiva, $y_G(t)$ diverge — e portanto $y(t)$ também.

**Mas isso é suficiente?** A Função de Transferência pode ter pólo na origem, ou par de pólos complexos conjugados com parte real nula? Vamos testar com dois exemplos.

---

## Contraexemplo 1 — pólo na origem

$G(s) = 1/s$ com entrada degrau:

$$
G(s)=\frac{1}{s} \qquad\qquad U(s)=\frac{1}{s}\ \ (\text{degrau unitário, limitado})
$$

$$
Y(s)=G(s)\,U(s)=\frac{1}{s}\cdot\frac{1}{s}=\frac{1}{s^2}
$$

$$
y(t)=t \qquad \Rightarrow\ \text{diverge (rampa)}
$$

> Uma entrada limitada gerou uma saída que diverge: pólo (mesmo simples) na origem **não** é admissível em $G(s)$.

---

## Contraexemplo 2 — pólos imaginários puros

$G(s) = 1/(s^2+1)$ com entrada cosseno:

$$
G(s)=\frac{1}{s^2+1}\ \ (\text{pólos } \pm i) \qquad\qquad U(s)=\frac{s}{s^2+1}\ \ (=\mathcal{L}\{\cos t\})
$$

$$
Y(s)=G(s)\,U(s)=\frac{s}{(s^2+1)^2}
$$

$$
y(t)=0{,}5\,t\,\text{sen}(t) \qquad \Rightarrow\ \text{diverge}
$$

> Uma entrada senoidal específica, limitada, também divergiu na saída: par de pólos complexos conjugados com parte real nula **também não** é admissível.

---

## Conclusão: condição necessária e suficiente

> Um sistema é BIBO estável se, e somente se, **todos os pólos da Função de Transferência $G(s)$ têm parte real negativa.**

- Pólos reais → devem ser **negativos**;
- Pólos complexos conjugados → devem ter parte real **negativa**;
- Pólo na origem (mesmo simples) → **não** permitido;
- Par de pólos complexos conjugados com parte real nula → **não** permitido.

---

## Próxima Seção:

É possível verificar a BIBO estabilidade de um sistema **sem calcular todos os seus pólos**, usando alguns truques matemáticos.