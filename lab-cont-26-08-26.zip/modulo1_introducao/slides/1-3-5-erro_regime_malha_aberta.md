---
marp: true
theme: default
paginate: true
math: katex
---

# Erro em Regime Permanente — Malha Aberta

**Calculando o erro para degrau, rampa e parábola sem resolver a resposta completa**

*Sistemas de Controle — Domínio de Laplace*

---

## Objetivo da seção

Dada a Função de Transferência de um sistema, calcular o **erro em regime permanente** para entradas degrau, rampa e parábola — sem precisar calcular a resposta completa do sistema.

---

## Por que degrau, rampa e parábola?

Normalmente queremos que a saída acompanhe a referência com erro nulo ou muito pequeno. Essas três entradas são as referências mais comuns quando há requisito de erro em regime:

- **Degrau** — valor constante a atingir: altura de um drone, temperatura de um forno, apontamento de um radar;
- **Rampa** — velocidade constante a seguir: pouso de uma aeronave, radar acompanhando um satélite, câmera seguindo um corredor;
- **Parábola** — aceleração constante a seguir: perfil de lançamento de um foguete.

---

## Exemplo 1 — entrada degrau unitário

$$
G(s)=\frac{1}{(s+1)(s+2)} \qquad\qquad Y(s)=G(s)\,U(s)=\frac{1}{(s+1)(s+2)}\cdot\frac{1}{s}
$$

Subtraindo a saída da entrada e expandindo em frações parciais:

$$
E(s)=\frac{s^2+3s+1}{(s+1)(s+2)\,s}=\frac{A}{s}+\frac{B}{s+1}+\frac{C}{s+2}
$$

$$
A=\frac{1}{(1)(2)}=0{,}5 \qquad B=\frac{(-1)^2+3(-1)+1}{(-1+2)(-1)}=1 \qquad C=\frac{(-2)^2+3(-2)+1}{(-2+1)(-2)}=-0{,}5
$$

$$
E(s)=\frac{0{,}5}{s}+\frac{1}{s+1}-\frac{0{,}5}{s+2}
$$

---

## O valor final do erro

$$
e(t)=0{,}5+e^{-t}-0{,}5\,e^{-2t}
$$

Quando $t\to\infty$, as duas exponenciais tendem a $0$:

$$
e(t)\ \to\ 0{,}5
$$

Denotamos esse valor final por $e_\infty$ ou $e_{ss}$ (*steady state*):

$$
e_\infty = e_{ss} = 0{,}5
$$

---

## Um atalho importante

Não precisávamos calcular os resíduos $B$ e $C$ — as transformadas inversas das frações com pólos em $-1$ e $-2$ tendem a $0$. **Só o resíduo do termo com denominador $s$ importa.**

Esse resíduo é obtido multiplicando $E(s)$ por $s$ e fazendo $s=0$:

$$
e_\infty = A = s\,E(s)\Big|_{s=0} = \frac{s^2+3s+1}{(s+1)(s+2)}\bigg|_{s=0} = \frac{1}{2}
$$

> **Atenção:** os demais pólos de $E(s)$ precisam ter parte real negativa. Caso contrário, as outras frações não tendem a $0$ e não existe valor final — o erro diverge ou oscila indefinidamente.

---

## O Teorema do Valor Final

$$
\lim_{t\to\infty} f(t) = \lim_{s\to 0} s\,F(s)
$$

Ou seja: calcular apenas o resíduo do termo com denominador $s$ é, no fundo, **aplicar o Teorema do Valor Final** diretamente sobre $E(s)$.

---

## Exemplo 2 — um caso especial

$$
G(s)=\frac{2}{(s+1)(s+2)}
$$

$$
E(s)=U(s)-Y(s)=\frac{1}{s}-\frac{2}{(s+1)(s+2)}\cdot\frac{1}{s} = \frac{s^2+3s+2-2}{(s+1)(s+2)\,s}=\frac{s(s+3)}{(s+1)(s+2)\,s}
$$

O $s$ do numerador cancela com o $s$ do denominador:

$$
E(s)=\frac{s+3}{(s+1)(s+2)}=\frac{A}{s+1}+\frac{B}{s+2}
$$

$$
e(t)=A\,e^{-t}+B\,e^{-2t} \qquad\Longrightarrow\qquad e(t)\to 0
$$

Sem fração com denominador $s$: **erro em regime nulo**.

---

## Um caminho alternativo: erro a partir da saída

Ao invés de obter $E(s)$ e depois $e_\infty$, também podemos obter $y_\infty$ (valor final da **saída**) e depois calcular $e_\infty = r - y_\infty$.

- Exemplo 1: $y_\infty = 0{,}5 \ \Rightarrow\ e_\infty = 1-0{,}5=0{,}5$ ✓
- Exemplo 2: $y_\infty = 1 \ \Rightarrow\ e_\infty = 1-1=0$ ✓

Os dois caminhos levam ao mesmo resultado — escolha o mais conveniente para cada caso.

---

## Exemplo 3 — o atalho mais rápido de todos

$$
G(s)=\frac{s^2+6s+9}{s^3+8s^2+17s+10}
$$

Para entrada degrau, $U(s)=1/s$, e pelo Teorema do Valor Final:

$$
y_\infty = \lim_{s\to0} s\,Y(s) = \lim_{s\to0} s\cdot\frac{G(s)}{s} = \lim_{s\to0} G(s)
$$

O $s$ do teorema cancela com o $1/s$ do degrau — **basta zerar todos os termos com $s$** em $G(s)$:

$$
y_\infty = \frac{9}{10} = 0{,}9 \qquad\qquad e_\infty = 1-0{,}9 = 0{,}1
$$

---

## E se o degrau não for unitário?

O sistema é linear: a saída para $k$ vezes a entrada é $k$ vezes a saída original. Logo, o erro para um degrau de amplitude $k$ é simplesmente $k$ vezes o erro para o degrau unitário.

$$
e_\infty(\text{degrau de amplitude } k) = k\cdot e_\infty(\text{degrau unitário})
$$

---

## Cuidado: nem sempre existe valor final!

$$
G(s)=\frac{s^2+29s+208}{s^3+6s^2+10s+208}
$$

Erro em regime para um degrau de amplitude $10$? **Não é $0$** — é uma pegadinha: este sistema é **BIBO instável** (confirme com Routh-Hurwitz). A saída diverge e **não existe** valor final para o erro.

> O Teorema do Valor Final só pode ser aplicado quando o sinal realmente tende a um valor constante.

---

## Entrada rampa — de volta ao Exemplo 1

$$
G(s)=\frac{1}{(s+1)(s+2)} \qquad\qquad E(s)=\big(1-G(s)\big)\,U(s)
$$

$$
1-G(s)=\frac{s^2+3s+1}{(s+1)(s+2)}
$$

Multiplicando pela transformada da rampa unitária, $U(s)=1/s^2$:

$$
E(s)=\frac{s^2+3s+1}{(s+1)(s+2)\,s^2}=\frac{A}{s}+\frac{B}{s^2}+\frac{C}{s+1}+\frac{D}{s+2}
$$

---

## O termo que muda tudo

$$
e(t)=0{,}5\,t + A + C\,e^{-t}+D\,e^{-2t}
$$

O resíduo do termo $1/s^2$ é $B=0{,}5\neq0$ — isso gera um termo $0{,}5\,t$ que **cresce indefinidamente**.

> Para que o erro tenda a um valor finito com entrada rampa, precisamos ter $B=0$. Como aqui $B\neq0$, o **erro diverge**: a saída não consegue acompanhar a rampa.

---

## Entrada rampa — Exemplo 2 (erro finito)

$$
G(s)=\frac{2}{(s+1)(s+2)} \qquad\qquad 1-G(s)=\frac{s^2+3s}{(s+1)(s+2)}
$$

Multiplicando por $1/s^2$, o $s$ comum se cancela:

$$
E(s)=\frac{s+3}{s(s+1)(s+2)}=\frac{A}{s}+\frac{B}{s+1}+\frac{C}{s+2}
$$

$$
A=\frac{3}{(1)(2)}=1{,}5 \qquad\qquad e_\infty(\text{rampa}) = 1{,}5
$$

Sem termo $1/s^2$: o erro tende a um valor **finito**, $1{,}5$.

---

## Generalizando com uma Função de Transferência literal

$$
G(s)=\frac{as^2+bs+c}{s^3+ds^2+es+f}
$$

$$
E(s)=\big(1-G(s)\big)\,U(s) = \frac{s^3+(d-a)s^2+(e-b)s+(f-c)}{s^3\big(s^3+ds^2+es+f\big)}
$$

para entrada **parábola** ($U(s)=1/s^3$), com expansão:

$$
E(s)=\frac{A}{s}+\frac{B}{s^2}+\frac{C}{s^3}+\frac{D}{s-p_1}+\frac{E}{s-p_2}+\frac{F}{s-p_3}
$$

---

## Eliminando os termos que divergem

Para $C=0$ (elimina o termo $t^2$), precisamos que o numerador não tenha termo constante:

$$
f=c \qquad\Longrightarrow\qquad E(s)=\frac{s^2+(d-a)s+(e-b)}{s^2\big(s^3+ds^2+es+f\big)}
$$

Para também eliminar $B$ (elimina o termo $t$), precisamos zerar o termo em $s$:

$$
e=b \qquad\Longrightarrow\qquad E(s)=\frac{s+(d-a)}{s\big(s^3+ds^2+es+f\big)}
$$

---

## O erro finito para entrada parábola

Com as duas condições satisfeitas ($f=c$ e $e=b$), aplicamos o valor final:

$$
e_\infty(\text{parábola}) = \frac{d-a}{f}
$$

Se, além disso, $a=d$, o erro em regime para entrada parábola é **nulo**.

Note que $c$ e $f$, assim como $b$ e $e$, são os coeficientes de **mesma potência de $s$** no numerador e no denominador de $G(s)$.

---

## A tabela-resumo

$$
G(s)=\frac{as^2+bs+c}{s^3+ds^2+es+f}
$$

$$
e_\infty(\text{degrau}) = \frac{f-c}{f}
$$

$$
c=f \quad\Longrightarrow\quad e_\infty(\text{rampa}) = \frac{e-b}{f}
$$

$$
c=f,\ \ b=e \quad\Longrightarrow\quad e_\infty(\text{parábola}) = \frac{d-a}{f}
$$

Em todos os casos dividimos por $f$: a Função de Transferência não pode ter pólo na origem — na verdade, **o sistema precisa ser estável**.

---

## Lendo a tabela em cascata

- Se $c\neq f$: erro **finito** para degrau ($\frac{f-c}{f}$); erro **infinito** para rampa e parábola;
- Se $c=f$ (erro $0$ no degrau) e $b\neq e$: erro **finito** para rampa ($\frac{e-b}{f}$); erro **infinito** para parábola;
- Se $c=f$ e $b=e$ (erro $0$ na rampa) e $a\neq d$: erro **finito** para parábola ($\frac{d-a}{f}$);
- Se $c=f$, $b=e$ e $a=d$: erro **nulo** também para parábola.

Para entradas diferentes de degrau/rampa/parábola, o mesmo procedimento se aplica.

---

## Um último cuidado

O Teorema do Valor Final só é válido se o sinal **realmente** tende a um valor constante quando $t\to\infty$. Encontrar um valor finito ao aplicar o teorema **não garante**, por si só, que o sinal converge — ele pode ter outras componentes que divergem ou oscilam indefinidamente (é por isso que verificamos os pólos restantes de $E(s)$ ou $Y(s)$).

---

## Síntese

- O erro em regime pode ser calculado sem resolver a resposta completa do sistema — basta o **resíduo do termo com denominador $s^n$** correspondente à entrada, aplicando o Teorema do Valor Final;
- **Degrau:** olhamos os termos independentes de $s$; **rampa:** o próximo coeficiente; **parábola:** o seguinte;
- O sistema precisa ser **estável** para que o valor final exista;
- Compare sempre os coeficientes de **mesma potência de $s$** no numerador e no denominador — é isso que determina se o erro é nulo, finito ou infinito.
