# Nota de Aula 4.3 — Ciclos-Limite, Função Descritiva e o Experimento do Relé

> **Documento do professor** — guia de quadro, pronto para transcrição linha a linha, com falas sugeridas.
> Duração prevista: 40 min dentro da semana 15 (bloco 3 do estudo guiado autônomo). Lab associado: **Lab 16** (Partes 2–4).
> **Módulo autônomo — não há mapa de vídeos** (segue `teoria_modulo4.md` §4.3 e os `exercicios_resolvidos_modulo4.md` 4.3.1–4.3.4).

---

## Q1 — O ciclo-limite: a oscilação que a teoria linear não explica (7 min)

**Quadro:**

```
SISTEMA LINEAR: oscilação permanente senoidal EXIGE polos exatamente sobre o eixo jω
 equilíbrio de ganho perfeito → fio da navalha: qualquer perturbação cresce ou morre
 órbitas fechadas vêm em FAMÍLIAS (cada condição inicial fica na sua)

REALIDADE: termostato oscila há ANOS | robô "treme" em torno do alvo | malha apita

★ CICLO-LIMITE: órbita fechada ISOLADA no espaço de estados
 trajetórias perto CONVERGEM (ciclo estável) ou SE AFASTAM (instável)
 amplitude e período FIXOS, independente da condição inicial

FIGURA: m4_fig08_retrato_fase.png — y(0)=0,6 por fora e y(0)=0,05 por dentro
 convergem para a MESMA órbita (preta). Sistema linear nenhum faz isso.

PERGUNTAS DE ENGENHARIA: qual a amplitude? qual a frequência? é estável?
 → respostas com conta de papel: FUNÇÃO DESCRITIVA
```

**Fala sugerida:** "No Módulo 03, oscilar para sempre exigia um equilíbrio de ganho perfeito — o sistema pendurado no fio da navalha. Mas o termostato da nota passada oscila sem ninguém afinar ganho nenhum. O segredo está na não linearidade: o relé fornece energia na medida certa — nem a mais, nem a menos — e a oscilação se ancora numa amplitude fixa. A pergunta é: qual amplitude? A resposta é uma das ideias mais elegantes do curso."

---

## Q2 — A função descritiva: ganho que depende da amplitude (12 min)

**Quadro (dedução da definição + do relé):**

```
SUPONHA: malha já oscilando, entrada da não linearidade ≈ senoidal: e = A·sen(ωt)
 saída NÃO é senoidal (saturação → achatada; relé → quadrada), mas é PERIÓDICA → Fourier:
 u(t) = U0 + Σ Mn·sen(nωt + φn)

HIPÓTESE DE FILTRAGEM: a planta G(s) é passa-baixas → harmônicos n ≥ 2 morrem
 → só o 1º harmônico "dá a volta" na malha

★ DEFINIÇÃO: N(A) = (a1 + j b1)/A   (ganho complexo entrada senoidal → 1º harmônico)
 a1 = (2/T)∫u·sen(ωt)dt,  b1 = (2/T)∫u·cos(ωt)dt

 N DEPENDE DA AMPLITUDE ← a diferença crucial para o ganho linear
 sem memória (sat, ZM, relé ideal): N real | com memória (histerese): N complexa

DEDUÇÃO DO RELÉ IDEAL (Ex. 4.3.1 — fazer no quadro):
 u = onda quadrada ±d em fase com e → b1 = 0 (ímpar × par)
 a1 = (4/T)∫0→T/2 d·sen(ωt)dt = (4d/T)·(2/ω) = 4d/π
 ★ N(A) = 4d/(πA)   — decresce com A ← mecanismo estabilizador do ciclo
 detalhe: 1º harmônico da quadrada = 1,27·d — MAIOR que a própria onda!

TABELA (deduções análogas — figuras m4_fig05):
 saturação (k, s): N = (2k/π)[arcsen(s/A) + (s/A)√(1−(s/A)²)],  A > s
 zona morta (k, d): N = k − (2k/π)[arcsen(d/A) + (d/A)√(1−(d/A)²)],  A > d
 relé c/ histerese (d, h): N = (4d/πA) ∠(−arcsen(h/A)),  A > h
 checagem: A→∞ saturação → 4ks/(πA) = relé de nível ks ✓
 verificação numérica por Fourier: Lab 16 Parte 2 (erros < 1 %)
```

**Fala sugerida:** "A função descritiva é um truque de físico: fingimos que só o primeiro harmônico existe — e a planta, que é passa-baixas, torna a mentira quase verdade. Decorem a do relé: 4d sobre πA. Ganho que CAI com a amplitude — é por isso que a oscilação para de crescer: cresceu, o ganho caiu, a malha 'desaperta'; encolheu, o ganho sobe, a malha 'aperta'. A oscilação se equilibra sozinha — é o fio da navalha que se segura."

---

## Q3 — Balanço harmônico e o exemplo-âncora completo (12 min)

**Quadro:**

```
CONDIÇÃO DE OSCILAÇÃO AUTO-SUSTENTADA (r = 0): o sinal dá a volta e volta IGUAL
 ★ 1 + N(A)·G(jω) = 0   ⇔   G(jω) = −1/N(A)
 (a versão não linear de L(jω) = −1 do Módulo 03!)

LEITURA GRÁFICA: Nyquist de G(jω) (parâmetro ω) × curva −1/N(A) (parâmetro A)
 cada INTERSEÇÃO = ciclo-limite candidato (lê ω numa, A na outra)
 relé ideal: −1/N = −πA/4d → o SEMI-EIXO REAL NEGATIVO inteiro (0 → −∞)
 → procurar onde o Nyquist cruza o eixo real = o ωf do Módulo 03!

EXEMPLO-ÂNCORA (fazer TUDO no quadro): relé d=1 + G = 1/[s(s+1)(s+2)]
 PASSO 1: G(jω) = 1/[−3ω² + jω(2−ω²)] → Im = 0 em ω = √2 = 1,41 rad/s (T = 4,44 s)
          G(j√2) = −1/6
 PASSO 2: (4/πA)·(1/6) = 1 → A = 4/(6π) = 0,212
 PASSO 3: figura m4_fig06 — interseção em −1/6
 PASSO 4: simulação (Lab 16): A = 0,220, ω = 1,38 → erros 4 % e 2 % (típicos!)
          figura m4_fig07

★ FECHO COM O MÓDULO 03: N(A) = 6 = ganho crítico de Routh (s³+3s²+2s+K: K<6, Lab 12)
 Ku = 4d/(πA) — o ganho último SAI do experimento do relé. Guardem!

ESTABILIDADE DO CICLO (LOEB): percorra −1/N com A crescente
 sai da região ENVOLVIDA para a NÃO ENVOLVIDA → ciclo ESTÁVEL
 (perturbação ↑A → ganho efetivo ↓ → malha "estável" → A volta; e vice-versa)
 âncora: ciclo estável ✓ (confirmado pelo retrato de fase, m4_fig08)
```

**Fala sugerida:** "Olhem a beleza: a condição de oscilação é a mesma do Módulo 03 — 'a volta na malha dá menos um' — só que agora o ganho depende da amplitude, e é essa dependência que fixa A. E o número 6 deveria ser familiar: é o ganho crítico que vocês acharam por Routh no Lab 12. Routh responde 'para que K a malha linear oscila?'; a função descritiva responde 'com que amplitude a malha NÃO linear oscila?' — e as duas contas se encontram no Ku."

---

## Q4 — O experimento do relé e a sintonia ZN (9 min)

**Quadro:**

```
PROBLEMA INDUSTRIAL: ZN em malha fechada = aumentar K até oscilar → PERIGOSO
SOLUÇÃO (Åström–Hägglund): troca o controlador por um RELÉ ±d (às vezes com histerese h)
 a malha entra em ciclo-limite SOZINHA e com AMPLITUDE CONTROLADA (não explode!)

 r ──>( Σ )──e──>[ relé ±d ]──u──>[ planta ]──y (oscilação: amplitude a, período Pu)
        ↑ −

MEDIÇÃO: espere 2–3 ciclos; a = semi-amplitude média; Pu = média de vários períodos
 ★ Ku = 4d/(πa)      ωu = 2π/Pu
 (com histerese: Ku = 4d/(π√(a²−h²)), a > h — imunidade a ruído)

TABELA ZN:      P: kp = 0,5 Ku | PI: kp = 0,45 Ku, Ti = Pu/1,2 | PID: kp = 0,6 Ku, Ti = Pu/2, Td = Pu/8

EXEMPLO-ÂNCORA NUMÉRICO (planta 'desconhecida' = a mesma do Q3):
 relé d=1 → a = 0,212 (previsto) / 0,220 (medido), Pu = 4,44 s → Ku ≈ 6 ✓ Routh
 P: 3,0 | PI: 2,7 / 3,70 s | PID: 3,6 / 2,22 s / 0,555 s

O QUE ESPERAR: ZN = amortecimento 1/4 → Mp 30–70 % em plantas de ordem alta
 ZN É PONTO DE PARTIDA: aplicar → medir → refinar (Lab 16: 72 % → 20 % → 11 % com sat+AW)

LIMITAÇÕES DO MÉTODO (§4.3.9): aproximado (hipótese de filtragem) | pode perder ciclos
 (termostato 1ª ordem!) | só regime, sem transientes | confirme SEMPRE por simulação
```

**Fala sugerida:** "Este é o experimento que vocês farão na bancada do projeto final. Em vez de aumentar o ganho até a planta quase sair voando — nenhum gerente de fábrica autoriza isso —, colocamos um relé de amplitude conhecida: a planta oscila com amplitude LIMITADA, medimos amplitude e período, e o Ku sai de graça: 4d sobre πa. Depois: tabela de Ziegler-Nichols, que entrega uma sintonia agressiva — ponto de partida, não de chegada. O Lab 16 mostra o fluxo inteiro: medir, sintonizar, refinar, proteger com anti-windup. É o roteiro profissional completo, do relé ao firmware."

---

## Fechamento do módulo (5 min)

**Quadro-resumo:**

```
N(A) = ganho do 1º harmônico — depende de A
BALANÇO HARMÔNICO: 1 + N(A)G(jω) = 0 → amplitude e frequência do ciclo-limite
LOEB: A crescente sai da região envolvida → ciclo estável
RELÉ → Ku = 4d/(πa) → tabela ZN → refinamento → PID protegido (anti-windup)

O MÓDULO EM UMA FRASE:
 a teoria linear projeta; as não linearidades cobram — e agora sabemos QUANTO,
 e como nos proteger (anti-windup) e até USÁ-LAS a nosso favor (experimento do relé).
```

**Fala sugerida:** "Fechem o curso com essa imagem: tudo que projetamos nos Módulos 1 a 3 funciona — desde que respeitemos os limites físicos. O Módulo 4 deu o mapa desses limites: a saturação que atrasa e dispara o integrador, a zona morta que trava o eixo, a histerese que oscila — e as duas ferramentas finais: o anti-windup que protege, e o relé que transforma a oscilação indesejada em instrumento de medição. Semana que vem: projeto final na bancada, com tudo isso junto."
