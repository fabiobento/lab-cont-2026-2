# Nota de Aula 4.1 — Não Linearidades Estáticas e Seus Efeitos na Malha

> **Documento do professor** — guia de quadro, pronto para transcrição linha a linha, com falas sugeridas.
> Duração prevista: 40 min dentro da semana 15 (bloco 1 do estudo guiado autônomo). Lab associado: **Lab 15**.
> **Módulo autônomo — não há mapa de vídeos** (a Unidade III do PPC não é coberta pelos vídeos base; esta nota segue `teoria_modulo4.md` §4.1 e os `exercicios_resolvidos_modulo4.md` 4.1.1–4.1.3).

---

## Q1 — Abertura: onde a teoria linear falha? (10 min)

**Quadro:**

```
TUDO que fizemos até aqui: sistemas LINEARES
 superposição vale | FT existe | resposta escala com a entrada | seno entra, seno sai

Mas olhe a bancada (e a indústria):
 1. driver do motor: ±12 V NO MÁXIMO (o PD do Lab 14 "pediu" 836 V!)
 2. motor parado: só gira quando a tensão VENCE o atrito
 3. termostato do chuveiro: liga em 38 °C, desliga em 42 °C — nunca no meio

SATURAÇÃO | ZONA MORTA | HISTERESE  →  os 3 personagens desta aula

VERDADE INCONVENIENTE: sistema linear não existe.
 Existem sistemas QUASE lineares numa faixa de operação.
 Esta aula: o que muda quando saímos da faixa.
```

**Fala sugerida:** "Vocês passaram 14 semanas projetando controladores num mundo ideal onde todo atuador entrega qualquer tensão que a gente pedir. Lembrem do Lab 14: o nosso PD 'pediu' 836 volts de pico num degrau unitário. Alguém aqui tem uma fonte de 836 V na bancada? Então — o que acontece de verdade quando o atuador não obedece? É o que vamos responder hoje. E aviso: a resposta não é 'o sistema fica um pouquinho pior'. Aparecem fenômenos que a teoria linear nem consegue descrever."

---

## Q2 — Saturação: a não linearidade mais importante (12 min)

**Quadro:**

```
SATURAÇÃO (limitador): ganho k até |e| = s; travada em ±u_max = k·s fora

        u │        ╱──── +u_max
          │      ╱
          │    ╱   região linear: u = k·e
          │  ╱
 ─────────┼╱────────── e
          ╱│
       ╱   │
   ╱       │
 ──────────┴──── −u_max

FIGURA: m4_fig01_saturacao.png

DUAS CONSEQUÊNCIAS:
 1. ganho EFETIVO cai com a amplitude (formalizaremos: função descritiva)
 2. desempenho passa a DEPENDER DO TAMANHO DA ENTRADA
    degrau pequeno: resposta projetada ✓
    degrau grande: mais lenta + (com integrador) MAIS sobressinal → windup (próxima nota)

POR QUE NÃO DESTROI A ESTABILIDADE sozinha?
 u limitado + planta BIBO-estável → y limitado. O perigo é a INTERAÇÃO com o integrador.

EXEMPLO NUMÉRICO (Ex. 4.1.1): k = 2, s = 1
 e = 0,5 → u = 1  |  e = 1 → u = 2  |  e = 3 → u = 2 (o TRIPLO não sai!)
 senoide A = 2: ganho efetivo N(2) = (4/π)[arcsen(0,5) + 0,5√0,75] = 1,218 → QUEDA DE 39 %
```

**Fala sugerida:** "Decorem: TODO atuador satura. Driver, DAC, válvula, músculo. Dentro da faixa linear, tudo que vocês aprenderam vale — por isso o curso funcionou até aqui. Fora dela, o atuador vira um 'limitador de potência': ele dá o máximo que tem, e ponto. Reparem no número de 39 %: a mesma peça tem ganho 2 para sinais pequenos e 1,2 para sinais grandes. Isso nunca aconteceria num sistema linear — e é a deixa para a ferramenta da última nota do módulo, a função descritiva."

---

## Q3 — Zona morta: o erro que o ganho não elimina (8 min)

**Quadro:**

```
ZONA MORTA: u = 0 para |e| ≤ d; depois cresce com ganho k
 (atrito estático, folga de engrenagem, limiar de válvula)
FIGURA: m4_fig02_zona_morta_histerese.png (painel esquerdo)

EFEITO NA MALHA (Ex. 4.1.2): controle P, zona morta entre controlador e planta
 equilíbrio: |kp·(r − y)| ≤ d → o eixo FICA ONDE ESTÁ
 faixa estacionária: y ∈ [r − d/kp, r + d/kp]
 com planta G DC=1: yss = (kp·r − d)/(1 + kp) → erro EXTRA = d/(1 + kp)

 kp = 4,  d = 0,5, r = 2 → yss = 1,500 (erro 0,5 rad!)
 kp = 10 → yss = 1,773 (erro extra 0,045)
 faixa estreita com kp, mas NUNCA zera

REMÉDIOS: manutenção/pré-carga | feedforward de atrito | ação integral
 ⚠ integrador + zona morta → CICLO-LIMITE lento ("caça" em torno do alvo)
```

**Fala sugerida:** "Por que o eixo do robô para a 2 mm do alvo e trava lá? Zona morta: o erro virou tão pequeno que o comando não vence mais o atrito — e o motor simplesmente desiste. E olhem a fórmula: d sobre 1 mais kp — a única saída pelo ganho é ganho infinito, que a gente já sabe que não existe. É por isso que robótica vive de compensação de atrito e manutenção de engrenagem, não só de sintonia."

---

## Q4 — Histerese, relé e o termostato: ciclo-limite exato (10 min)

**Quadro:**

```
RELÉ COM HISTERESE: tem MEMÓRIA — só liga em e > +h, só desliga em e < −h
 caso limite h → 0: RELÉ IDEAL (liga-desliga puro)
FIGURA: m4_fig02 (painel direito)
 quase sempre INTENCIONAL: sem histerese, ruído → chaveamento frenético → contator morto

TERMOSTATO (Ex. 4.1.3): G = 1/(10s+1), d = 1, h = 0,5, r = 0
 descida (u = −1), partindo de y = +h:  y(t) = −1 + (1+h)e^(−t/10)
 atinge −h quando  e^(−t/10) = (1−h)/(1+h)
 t_1/2 = 10·ln[(1+h)/(1−h)] = 10·ln 3 = 10,99 s
 ★ T = 20·ln[(1+h)/(1−h)] = 21,97 s   ★ amplitude = h (EXATO!)
 trade-off: h pequeno → ondulação pequena, chaveamento frenético
            h grande  → poucos chaveamentos, ondulação grande

O FENÔMENO NOVO: CICLO-LIMITE — oscilação permanente de amplitude e período FIXOS,
 robusta a perturbações. Nenhum sistema linear faz isso → nota 4.3.
```

**Fala sugerida:** "O ar-condicionado de janela da sala de vocês oscila há anos, e ninguém projetou polos sobre o eixo imaginário com precisão infinita. Essa oscilação é um ciclo-limite — e aqui a gente calculou o período EXATAMENTE, sem aproximação nenhuma: 20 vezes o log de (1+h)/(1−h). Guardem essa conta: é uma das poucas análises exatas de sistema não linear que existem. Na próxima nota, o integrador vai nos dar trabalho; na terceira, vamos prever ciclos-limite em plantas de qualquer ordem — com uma ferramenta aproximada, mas poderosíssima."

---

## Fechamento e ponte (5 min)

**Quadro-resumo:**

```
               efeito dominante              remédio/ferramenta
SATURAÇÃO   resposta lenta + windup      anti-windup (nota 4.2); função descritiva
ZONA MORTA  erro residual ≈ d/(1+kp)     feedforward de atrito; cuidado com integrador
HISTERESE   ciclo-limite (amplitude h)   h por trade-off; função descritiva (nota 4.3)

MUDANÇA DE FERRAMENTA: sem FT → simulação por EQUAÇÕES DE ESTADO (Lab 15)
```

**Fala sugerida:** "Levem para o Lab 15: vocês vão ver com números que a mesma malha tem respostas diferentes para degraus de tamanhos diferentes — a assinatura da não linearidade. E preparem-se para a constatação incômoda: o integrador, nosso herói do erro nulo, é justamente quem mais sofre com a saturação."
