# Nota de Aula 4.2 — Windup do Integrador e Anti-Windup

> **Documento do professor** — guia de quadro, pronto para transcrição linha a linha, com falas sugeridas.
> Duração prevista: 40 min dentro da semana 15 (bloco 2 do estudo guiado autônomo). Lab associado: **Lab 16** (Parte 1).
> **Módulo autônomo — não há mapa de vídeos** (segue `teoria_modulo4.md` §4.2 e os `exercicios_resolvidos_modulo4.md` 4.2.1–4.2.3).

---

## Q1 — O acidente anunciado: integrador + saturação (10 min)

**Quadro:**

```
A MALHA MAIS COMUM DA INDÚSTRIA:  PI + atuador saturado

 r ──>( Σ )──e──>[ PI: u = kp·e + ki·∫e ]──u_PI──>[ sat ±u_max ]──u──>[ planta ]──y──┐
        ↑ −                                                                      │
        └────────────────────────────────────────────────────────────────────────┘

AÇÃO DO INTEGRADOR (em palavras): "enquanto houver erro, continuo somando"

SEQUÊNCIA DO ACIDENTE (degrau de referência):
 1. e grande → PI pede u ENORME → saturação entrega só u_max (é tudo que existe)
 2. planta acelera NO LIMITE FÍSICO (mais devagar que o controlador imaginou)
 3. y < r → e > 0 → integrador CONTINUA SOMANDO
    "subiu menos do que eu pedi? então peço MAIS ainda!"  → carga muito além do necessário
 4. y cruza r: e = 0, mas o integrador está CHEIO
    → u pedido continua alto → planta continua acelerada → SOBRESSINAL
 5. descarga lenta via e < 0 → acomodação LONGA

★ WINDUP = carga excessiva acumulada no integrador durante a saturação
```

**Fala sugerida:** "O integrador é um funcionário dedicado e um pouco teimoso: enquanto houver erro, ele soma. Agora imaginem esse funcionário gritando pedidos cada vez maiores para um atuador que já está no talo. Ele não vê o teto — ele só vê o erro. Quando a saída finalmente chega na referência, ele acumulou uma pilha de pedidos que precisa ser desfeita — erro na direção contrária, por muito tempo. Esse é o windup: o nome vem de 'enrolar' — o integrador enrola como uma mola, e a mola depois desenrola em cima da resposta."

---

## Q2 — A aritmética do windup (exemplo-âncora, 15 min)

**Quadro (conduzir a conta completa — é o coração da aula):**

```
MALHA-ÂNCORA: G = 1/(10s+1),  PI kp = 2, ki = 0,5 (Ti = 4 s),  sat ±1,3,  r = 1

PASSO 1 — subida saturada: u = 1,3 constante → y(t) = 1,3(1 − e^(−t/10))
PASSO 2 — cruzamento: 1 = 1,3(1 − e^(−t*/10)) → e^(−t*/10) = 0,3/1,3 → t* = 10·ln(1,3/0,3) = 14,66 s
PASSO 3 — carga acumulada: e(t) = 1 − y = −0,3 + 1,3·e^(−t/10)
  xi(t*) = ∫0→t* e dt = [−0,3t + 13(1 − e^(−t/10))] = −4,40 + 13×0,769 = 5,6
PASSO 4 — carga de regime: u_ss = 1 (DC=1) → xi_ss = u_ss/ki = 1/0,5 = 2,0
PASSO 5 — diagnóstico: EXCESSO = 3,6 = 180 % da carga de regime!
  enquanto não escoar (e < 0 por muitos segundos), u fica alto → planta acelera → overshoot

OS TRÊS EXPERIMENTOS (Lab 16, Parte 1):
 ┌───────────────────────────────┬─────────┬─────────────┐
 │ PI ideal (sem saturação)      │ Mp 11,5%│ ts = 19,7 s │  ← irreal: pede u(0) = 2 > 1,3
 │ PI + saturação (windup)       │ Mp 23,2%│ ts = 39,3 s │  ← o acidente
 │ PI + saturação + anti-windup  │ Mp  3,2%│ ts = 13,4 s │  ← melhor que o "ideal"!
 └───────────────────────────────┴─────────┴─────────────┘
FIGURAS: m4_fig03_windup_resposta.png, m4_fig04_windup_controle.png

POR QUE O ANTI-WINDUP GANHA ATÉ DO IDEAL?
 subida usa o TETO FÍSICO o tempo todo + integrador chega "na medida" no cruzamento
 saturação bem gerenciada = operação no limite físico (o melhor que a física permite)
```

**Fala sugerida:** "Façam essa conta com carinho, porque ela é o diagnóstico completo do windup: 5,6 contra 2,0. O integrador chega ao cruzamento carregando quase o triplo do que precisa. Esse excesso só sai de um jeito: erro negativo, ou seja, sobressinal — 3,6 de carga para descarregar a 0,5 por segundo de erro... é por isso que a acomodação dobra. E notem a linha 3 da tabela: com anti-windup, a resposta é melhor até que a do sistema sem saturação nenhuma. A moral não é 'saturação estraga tudo'; é 'saturação mal gerenciada estraga tudo'."

---

## Q3 — Anti-windup I: clamping (8 min)

**Quadro:**

```
CLAMPING (congelamento condicional) — a estratégia mais simples:

 dxi/dt = 0    se saturado E o erro empurra para mais fundo na saturação
 dxi/dt = e    caso contrário

PSEUDOCÓDIGO (3 linhas que vão para o firmware do projeto final):
 u_PI = kp*e + ki*xi
 u    = min(max(u_PI, -u_max), u_max)
 se (u_PI >= u_max e e > 0) ou (u_PI <= -u_max e e < 0): dxi = 0  senão: dxi = e

LEITURA: erro CONTRA a saturação integra livre (é ele quem TIRA o atuador do teto)
VANTAGENS: trivial de implementar | nenhum parâmetro novo
```

**Fala sugerida:** "O clamping é a regra do bom senso: 'se você já está pedindo demais e o erro pede mais ainda, pare de anotar'. Três linhas de código. E é a diferença entre 23 % e 3 % de sobressinal — entre um controlador que funciona e um que oscila na bancada. Todo CLP comercial tem isso embutido; no firmware de vocês, vai ser obrigatório."

---

## Q4 — Anti-windup II: back-calculation + notas práticas (7 min)

**Quadro:**

```
BACK-CALCULATION: realimenta o EXCESSO (u − u_PI) à entrada do integrador:

 dxi/dt = e + (1/Tt)·(u − u_PI)

 sem saturação: u = u_PI → integrador normal
 saturado: o termo descarrega o integrador até u_PI ≈ teto
 Tt = "tracking time constant": regra prática  Tt ≈ Ti (PI)  |  Tt ≈ √(Ti·Td) (PID)

EXEMPLOS (Ex. 4.2.2): PI da âncora: Tt = 4 s | PID-ZN (Ti=2,22, Td=0,555): Tt = √1,232 = 1,11 s

CLAMPING × BACK-CALC: binário × suave ajustável — os dois são padrão de indústria

NOTAS PRÁTICAS (ler duas vezes):
 1. SATURE O SINAL DENTRO DO CONTROLADOR (software) — senão o anti-windup não "vê" o corte
 2. rate limiter na referência evita saturação longa (a rampa do Lab 13!)
 3. no PID digital: limitador + anti-windup = 3 linhas — OBRIGATÓRIO
 4. windup existe até sem saturação física: basta o software limitar o PWM/DAC
```

**Fala sugerida:** "A back-calculation é o clamping sofisticado: em vez de congelar, ela mede quanto foi cortado e devolve essa informação ao integrador, que descarrega suavemente na velocidade ditada por Tt. E guardem a nota prática número 1: o limitador tem que estar DENTRO do código do controlador. Se a saturação acontece só no hardware, o integrador carrega cego — o anti-windup precisa enxergar a diferença entre o pedido e o entregue."

---

## Fechamento e ponte (5 min)

**Quadro-resumo:**

```
WINDUP: integrador enche durante a saturação → Mp e ts DOBRAM (âncora: 23,2 % / 39,3 s)
DIAGNÓSTICO: carga no cruzamento (5,6) × carga de regime (2,0) → excesso 180 %
REMÉDIO: clamping (congela) ou back-calculation (descarrega via 1/Tt)
RESULTADO: 3,2 % / 13,4 s — melhor até que o "ideal" sem saturação
REGRA DE OURO: todo PID em software nasce com limitador + anti-windup

PONTE: faltou responder "qual amplitude? qual frequência?" das oscilações
 que não linearidades geram → função descritiva + experimento do relé (nota 4.3)
```

**Fala sugerida:** "Levem três números desta aula: 23 %, 3 % e 180 %. O windup dobra o sobressinal; o clamping devolve a resposta; e a carga extra do integrador é quase o dobro da útil. Na próxima nota, voltamos à pergunta que abriu o módulo: as oscilações que aparecem do nada em malhas não lineares. Vamos aprender a prevê-las com conta de papel — e a usá-las para sintonizar PID sem derrubar a planta."
