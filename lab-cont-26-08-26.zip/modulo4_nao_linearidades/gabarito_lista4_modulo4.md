# Gabarito — Lista de Exercícios 4 — Não Linearidades em Malhas de Controle

**Laboratório de Controle Automático — Engenharia Elétrica — Ifes Campus Guarapari**

> Resolução detalhada, passo a passo, com indicação de onde consultar a teoria em `teoria_modulo4.md`. Valores numéricos conferidos por simulação (python-control; Labs 15 e 16).

---

## Questão 1 — Saturação: característica estática e ganho efetivo

> **Consulte:** teoria §4.1.2 (saturação: característica estática e função descritiva).

**a) Característica e limite linear.** A característica é

$$u(e) = \begin{cases} ke, & |e| \le s \\ \pm 10\ \text{V}, & |e| > s \end{cases}, \qquad s = \frac{u_{\max}}{k} = \frac{10}{5} = 2\ \text{V}.$$

A região linear vale para $|e| \le 2$ V. A **maior amplitude de entrada ainda linear é 2 V** (saída exatamente 10 V).

**b) Saídas.**

- $e = 1{,}5$ V < 2 V → região linear: $u = 5 \times 1{,}5 = \mathbf{7{,}5\ V}$.
- $e = 3$ V > 2 V → saturado: $u = \mathbf{10\ V}$ (sem saturação seria 15 V — o amplificador "perde" 5 V).

**c) Ganho descritivo para $A = 4$ V.** Como $A > s = 2$:

$$N(4) = \frac{2 \times 5}{\pi}\left[\arcsen\left(\tfrac{2}{4}\right) + \tfrac{2}{4}\sqrt{1-\left(\tfrac{2}{4}\right)^2}\right] = \frac{10}{\pi}\left[\arcsen(0{,}5) + 0{,}5\sqrt{0{,}75}\right].$$

Com $\arcsen(0{,}5) = 0{,}5236$ e $0{,}5\sqrt{0{,}75} = 0{,}4330$:

$$N(4) = \frac{10}{\pi}(0{,}5236 + 0{,}4330) = \frac{10}{\pi}(0{,}9566) \approx \mathbf{3{,}045}.$$

**d) Interpretação.** $N(4)/k = 3{,}045/5 = 0{,}609$: o ganho efetivo cai para **60,9% de $k$** (redução de ≈ 39%). Uma malha projetada "contando" com o ganho $k$ terá, para sinais grandes, ganho de malha menor que o projetado — resposta mais lenta e margens alteradas. É por isso que a saturação, em geral, **não desestabiliza** por si só (ela só reduz ganho), mas degrada desempenho e, combinada com integradores, gera windup (§4.2).

---

## Questão 2 — Zona morta e erro de regime

> **Consulte:** teoria §4.1.3 (zona morta) e Lab 15, Parte 3.

**a) Intervalo de regime.** Em regime, o atuador entrega $u_a$ à planta de ganho 1, com $u_a = \phi(k_p e)$, onde $\phi$ é a zona morta:

$$\phi(v) = \begin{cases} v - d, & v > d \\ 0, & |v| \le d \\ v + d, & v < -d \end{cases}$$

Com referência $r > 0$, a saída estabiliza onde o comando $v = k_p e = k_p(r - y)$ está na **fronteira** da zona morta, $v = d$ (qualquer $v < d$ dá $u_a = 0$ e a saída cai; o equilíbrio se dá com o atuador fornecendo o mínimo necessário, $u_a = v - d$):

$$y_{ss} = u_a = k_p(r - y_{ss}) - d \;\;\Rightarrow\;\; y_{ss}(1 + k_p) = k_p r - d \;\;\Rightarrow\;\; y_{ss} = \frac{k_p r - d}{1 + k_p}.$$

Como o equilíbrio pode ocorrer em qualquer ponto da faixa morta ($v \in [-d, d]$ em torno do valor de equilíbrio), o intervalo completo é $\dfrac{k_p r - d}{1+k_p} \le y_{ss} \le \dfrac{k_p r + d}{1+k_p}$, e

$$e_{ss} = r - y_{ss} = \frac{r(1+k_p) - k_p r + d}{1+k_p} = \frac{r + d}{1 + k_p}.$$

**b) $k_p = 6$, $r = 1{,}5$, $d = 0{,}3$:**

$$y_{ss} = \frac{6 \times 1{,}5 - 0{,}3}{7} = \frac{8{,}7}{7} = \mathbf{1{,}243}; \qquad e_{ss} = \frac{1{,}5 + 0{,}3}{7} = \frac{1{,}8}{7} = \mathbf{0{,}257}.$$

(Confere com o Lab 15, Parte 3: $y_{ss} = 1{,}500$ para $k_p=4$, $d=0{,}5$, $r=2$ → erro extra de $d/(1+k_p) = 0{,}100$.)

**c) Ganho para $|e_{ss}| \le 0{,}05$:**

$$\frac{1{,}8}{1 + k_p} \le 0{,}05 \;\;\Rightarrow\;\; 1 + k_p \ge \frac{1{,}8}{0{,}05} = 36 \;\;\Rightarrow\;\; \mathbf{k_p \ge 35}.$$

**Comentário.** A zona morta cria uma **faixa de equilíbrios**: dentro dela o erro não gera ação de controle, logo nenhum ganho finito zera o erro — apenas o reduz a $\sim 1/k_p$. Um **integrador** eliminaria o erro (continua acumulando enquanto $e \neq 0$), mas traz o risco de **windup** quando combinado com saturação (§4.2) e pode produzir ciclos-limite de baixa frequência ao "caçar" dentro da faixa morta.

---

## Questão 3 — Termostato: período exato da oscilação

> **Consulte:** teoria §4.1.4 (histerese — análise exata do termostato) e Lab 15, Parte 4.

**a) Dedução do período.** Planta $\tau = 5$ s, relé $\pm 1$, comutações em $y = \pm h$. Com $u = +1$ partindo de $y(0) = -h$:

$$y(t) = 1 - (1+h)e^{-t/\tau}.$$

A comutação ocorre em $y(t_1) = +h$:

$$h = 1 - (1+h)e^{-t_1/\tau} \;\;\Rightarrow\;\; e^{-t_1/\tau} = \frac{1-h}{1+h} \;\;\Rightarrow\;\; t_1 = \tau\ln\!\frac{1+h}{1-h}.$$

Por simetria, o semiciclo de descida dura o mesmo, logo

$$T = 2\tau\ln\!\frac{1+h}{1-h} = 10\ln\!\frac{1{,}2}{0{,}8} = 10\ln(1{,}5) = 10 \times 0{,}4055 = \mathbf{4{,}055\ s}.$$

**b) $h = 0{,}5$:**

$$T = 10\ln\!\frac{1{,}5}{0{,}5} = 10\ln 3 = \mathbf{10{,}99\ s}.$$

A amplitude da oscilação de temperatura é exatamente $h$ → com $h$ maior, a temperatura **oscila mais** (pior conforto), mas o relé **comuta menos** (menos desgaste do contator). O compromisso prático: $h$ pequeno = conforto térmico × desgaste; $h$ grande = durabilidade × oscilação. (Confere com o Lab 15: para $\tau = 10$, $h = 0{,}2/0{,}5/0{,}8$ → $T = 8{,}11/21{,}97/43{,}94$ s, medido = teoria exata.)

**c) Simulação.** Com `sim_termostato(h, tau=5)`, os períodos medidos coincidem com os valores exatos acima (a simulação por eventos do Lab 15 reproduz a teoria com erro < 0,5%).

---

## Questão 4 — Windup: a aritmética do transbordamento do integrador

> **Consulte:** teoria §4.2.2 (mecanismo do windup, os 4 passos) e Lab 16, Parte 1.

**a) Regime e saturação.** Planta com ganho DC $= 1$: para $y_{ss} = r = 1$ é preciso $u_{ss} = 1$. Como a saturação está em $\pm 1{,}2 > u_{ss}$, em regime não há saturação. Mas durante o transitório sim: antes de saturar, $u_{PI}(t) = k_p e + k_i x_i = e^{-t/5} + 2{,}5\left(1 - e^{-t/5}\right) = 2{,}5 - 1{,}5e^{-t/5}$, que cruza $1{,}2$ em $t \approx 0{,}72$ s. **A saturação é atingida** (e permanece até depois de $t^*$).

**b) Instante $t^*$.** Com $u = 1{,}2$ constante, $y(t) = 1{,}2\left(1 - e^{-t/5}\right)$. Igualando a $r = 1$:

$$1 = 1{,}2\left(1 - e^{-t^*/5}\right) \;\;\Rightarrow\;\; e^{-t^*/5} = 1 - \frac{1}{1{,}2} = \frac{1}{6} \;\;\Rightarrow\;\; t^* = 5\ln 6 = \mathbf{8{,}96\ s}.$$

**c) Excesso do integrador.** Durante a saturação, $\dot{x}_i = e = 1 - y = -0{,}2 + 1{,}2e^{-t/5}$:

$$x_i(t^*) = \int_0^{t^*}\left(-0{,}2 + 1{,}2e^{-t/5}\right)dt = -0{,}2t^* + 6\left(1 - e^{-t^*/5}\right) = -1{,}79 + 6 \times \frac{5}{6} = \mathbf{3{,}21}.$$

O valor necessário em regime seria $x_{i,ss} = u_{ss}/k_i = 1/0{,}5 = 2{,}0$. **Excesso: $3{,}21 - 2{,}0 = 1{,}21$ (≈ 60% acima do necessário).**

**d) Por que há sobressinal.** Em $t^*$, $e = 0$, mas o controlador entrega $u_{PI} = k_p \cdot 0 + k_i \cdot 3{,}21 = 1{,}61 > 1{,}2$: o atuador **continua saturado** mesmo com erro nulo, e $y$ ultrapassa $r$. O integrador só começa a descarregar quando $e < 0$, e precisa "devolver" o excesso 1,21 antes que $u_{PI}$ caia abaixo do valor de regime — daí o sobressinal grande e o atraso extra no estabelecimento. (No Lab 16, o caso-âncora $\tau = 10$, $k_p = 2$, $k_i = 0{,}5$, sat $\pm 1{,}3$ mostra $M_p$ de 11,5% → 23,2% e $t_s$ de 19,7 s → 39,3 s por causa do windup.)

---

## Questão 5 — Anti-windup: conceitos e implementação

> **Consulte:** teoria §4.2.3 (clamping) e §4.2.4 (back-calculation); Lab 16, Partes 1 e 4.

**a) Regra de clamping (PI digital).**

```
u_unsat = kp*e + ki*xi          # saída antes do limitador
u       = saturar(u_unsat)      # saída efetiva
# integração condicional:
se NÃO ( (u_unsat >= u_max e e > 0) ou (u_unsat <= u_min e e < 0) ):
    xi = xi + e*Ts              # integra normalmente
senão:
    xi = xi                     # congela: erro empurraria mais fundo na saturação
```

A integração é congelada **somente quando o atuador está saturado E o erro tem o sinal que aumentaria a saturação**. Se o erro tem sinal oposto (ajuda a dessaturar), a integração é permitida.

**b) Back-calculation.** O termo $\dfrac{1}{T_t}(u - u_{PI})$ realimenta a **diferença entre o sinal efetivamente aplicado e o calculado**: quando não há saturação, $u = u_{PI}$ e o integrador se comporta normalmente; quando satura, a diferença $u - u_{PI}$ "puxa" o estado do integrador para o valor compatível com o limite, com dinâmica de constante $T_t$. Escolhas usuais: $T_t = T_i$ (PI) ou $T_t = \sqrt{T_i T_d}$ (PID). $T_t$ pequeno demais pode reintroduzir o problema; grande demais torna a recuperação lenta.

**c) Limitador dentro do software.** Todo esquema anti-windup precisa **conhecer** a saturação — comparar $u_{PI}$ com $u$. Se o limite existe apenas no hardware do atuador, o controlador não "sabe" que saturou: o integrador continua acumulando como se o comando tivesse sido aplicado, e nem clamping nem back-calculation têm como atuar. Por isso o limitador é implementado no código do controlador, com os mesmos níveis do atuador real. (Lab 16, Parte 4: saturação ±1,0 elevou $M_p$ de 20,4% para 27,8%; com clamping, caiu para 11,5%.)

---

## Questão 6 — Previsão de ciclo-limite por balanço harmônico

> **Consulte:** teoria §4.3.4 (balanço harmônico $1 + N(A)G(j\omega) = 0$), §4.3.2 (FD do relé) e o exemplo-âncora §4.3.5; Lab 16, Parte 3.

**a) Cruzamento de fase.** $\angle G(j\omega) = -90° - \operatorname{arctg}\omega - \operatorname{arctg}(\omega/2)$. Impondo $-180°$:

$$\operatorname{arctg}\omega_c + \operatorname{arctg}\frac{\omega_c}{2} = 90° \;\;\Rightarrow\;\; \omega_c \cdot \frac{\omega_c}{2} = 1 \;\;\Rightarrow\;\; \omega_c = \sqrt{2} = 1{,}414\ \text{rad/s}.$$

$$|G(j\sqrt{2})| = \frac{4}{\sqrt{2}\cdot\sqrt{3}\cdot\sqrt{6}} = \frac{4}{6} = \frac{2}{3}.$$

**b) Amplitude do ciclo-limite.** O balanço harmônico pede $N(A) = -1/G(j\omega_c) = 3/2$ (real positivo, pois $G(j\omega_c) = -2/3$):

$$\frac{4 \times 1}{\pi A} = \frac{3}{2} \;\;\Rightarrow\;\; A = \frac{8}{3\pi} = \mathbf{0{,}849}, \qquad \omega = \sqrt{2},\;\; T = \frac{2\pi}{\sqrt{2}} = 4{,}44\ \text{s}.$$

**c) Coincidência com Routh.** $K_u = \dfrac{4d}{\pi A} = \dfrac{4}{\pi \times 0{,}849} = \mathbf{1{,}5}$. Com ganho $K$ no lugar do relé, o polinômio característico é $s(s+1)(s+2) + 4K = s^3 + 3s^2 + 2s + 4K$; Routh dá $3 \times 2 = 4K_{crit} \Rightarrow K_{crit} = 1{,}5$ — **idêntico**. Não é acidente: no ponto do ciclo-limite, o relé se comporta, para a fundamental, como um ganho $N(A) = K_u$ que torna a malha marginalmente estável ($NG(j\omega_c) = -1$) — exatamente a condição de Routh no limite.

**d) Simulação.** Com `sim_rele` adaptado (planta com o 4 no numerador), mede-se $A \approx 0{,}88$ e $T \approx 4{,}6$ s — erros de 3–4% típicos da aproximação de primeira harmônica (a saída não é senoidal perfeita). No caso-âncora do Lab 16 ($G = 1/[s(s+1)(s+2)]$): previsto $A = 0{,}212$, $\omega = 1{,}414$; medido $A = 0{,}220$, $\omega = 1{,}38$.

---

## Questão 7 — Sintonia Ziegler-Nichols a partir do relé

> **Consulte:** teoria §4.3.8 (experimento do relé e tabela ZN); Lab 16, Parte 4.

Da Q6: $K_u = 1{,}5$ e $P_u = 2\pi/\sqrt{2} = 4{,}443$ s.

**a) P:** $\quad k_p = 0{,}5K_u = \mathbf{0{,}75}$.

**b) PI:** $\quad k_p = 0{,}45K_u = \mathbf{0{,}675}; \qquad T_i = P_u/1{,}2 = \mathbf{3{,}702\ s}$.

**c) PID:** $\quad k_p = 0{,}6K_u = \mathbf{0{,}9}; \qquad T_i = P_u/2 = \mathbf{2{,}221\ s}; \qquad T_d = P_u/8 = \mathbf{0{,}555\ s}$.

**d) Refinamento.** ZN de ciclo-limite sintoniza para razão de decaimento 1/4 → sobressinal tipicamente alto (no Lab 16: 70,5% com PID-ZN). A estratégia usada no laboratório foi **reduzir o proporcional e o integral e reforçar o derivativo**: $k_p \leftarrow 0{,}7k_p$, $k_i \leftarrow 0{,}25k_i$, $k_d \leftarrow 1{,}5k_d$ — o que derrubou o sobressinal de 70,5% para 20,4%, mantendo resposta rápida.

---

## Questão 8 — Saturação não sustenta ciclo-limite em malha linear estável

> **Consulte:** teoria §4.3.3 (FD da saturação), §4.3.4 (critério gráfico: interseção de $G(j\omega)$ com $-1/N(A)$) e Exercício 4.3.4.

**a) Lugar de $-1/N(A)$.** Para a saturação, $N(A)$ é **real e positivo**, com $N = 1$ para $A \le s$ e $N \to 0$ quando $A \to \infty$. Logo $-1/N(A)$ percorre o **eixo real de $-1$ até $-\infty$** (intervalo $(-\infty, -1]$).

**b) $K = 4$.** O Nyquist de $G(j\omega)$ cruza o eixo real em $\omega_c = \sqrt{2}$ (mesma conta da Q6):

$$G(j\sqrt{2}) = -\frac{K}{6} = -\frac{4}{6} = -0{,}667.$$

Como $-0{,}667 > -1$, o cruzamento está **à direita** do intervalo $(-\infty, -1]$ → **não há interseção → não há ciclo-limite**: qualquer amplitude satura e reduz o ganho efetivo, e a malha (estável para $K = 4 < K_{crit} = 6$) permanece estável.

**c) $K = 12$.** Agora $G(j\sqrt{2}) = -2$, que está dentro de $(-\infty, -1]$ → há interseção. A condição é $N(A) = 1/2 = 0{,}5$:

$$\frac{2}{\pi}\left[\arcsen\frac{1}{A} + \frac{1}{A}\sqrt{1 - \frac{1}{A^2}}\right] = 0{,}5 \;\;\xRightarrow{\text{numérico}}\;\; \mathbf{A \approx 2{,}48}, \qquad \omega = \sqrt{2},\;\; T = 4{,}44\ \text{s}.$$

(Resolução numérica por bisseção/`brentq` sobre a FD da saturação — mesma `fd_sat_teo` do Lab 16.)

**d) Interpretação.** A FD da saturação satisfaz $N(A) \le 1$: ela **só reduz** o ganho. Para o balanço $N(A)G(j\omega_c) = -1$ ter solução, é preciso $|G(j\omega_c)| \ge 1$, ou seja, $K \ge K_{crit} = 6$ — a malha **linear** já estaria instável. A saturação então "limita" a amplitude: a oscilação cresce até $N(A)$ cair o suficiente para restaurar o ganho de malha unitário. Conclusão prática: **saturação não cria instabilidade, mas transforma divergência em ciclo-limite.**

---

## Questão bônus — Relé com histerese: cuidado com interseções espúrias

> **Consulte:** teoria §4.3.2 (FD do relé com histerese), §4.3.4 (balanço completo: módulo **e** fase) e §4.3.6 (critério de Loeb).

**a) Lugar de $-1/N(A)$.** Para o relé com histerese, $N(A) = \dfrac{4d}{\pi A}e^{-j\arcsen(h/A)}$. Então

$$-\frac{1}{N(A)} = -\frac{\pi A}{4d}e^{+j\arcsen(h/A)} \;\;\Rightarrow\;\; \mathrm{Im}\left(-\frac{1}{N}\right) = -\frac{\pi A}{4d}\sen\!\big(\arcsen(h/A)\big) = -\frac{\pi h}{4d} = \text{constante}.$$

Com $h = 0{,}2$, $d = 1$: $\mathrm{Im} = -\pi \times 0{,}2/4 = \mathbf{-0{,}157}$. É uma **semirreta horizontal** que parte de $-j0{,}157$ (em $A = h$) e se estende para a **esquerda** ($\mathrm{Re} < 0$) conforme $A$ cresce.

**b) As duas "soluções" e a espúria.** $\mathrm{Im}G(j\omega) = -\dfrac{2\omega}{(1+\omega^2)^2}$ tem mínimo $-0{,}65$ em $\omega = 1/\sqrt{3}$ e vale $-0{,}157$ em **duas** frequências:

- $\omega_1 \approx 0{,}08$ rad/s: $G \approx 0{,}99\angle{-9{,}1°}$ → $\mathrm{Re} > 0$ (4º quadrante);
- $\omega_2 \approx 2{,}02$ rad/s: $G \approx 0{,}197\angle{-127{,}3°}$ → $\mathrm{Re} < 0$ (3º quadrante).

O erro de raciocinar só pela parte imaginária: o balanço harmônico é uma equação **complexa** — exige $G(j\omega) = -1/N(A)$ em módulo **e** fase. Em $\omega_1$, a fase de $G$ é $-9{,}1°$, mas a semirreta $-1/N$ naquele nível de parte imaginária exige fase próxima de $-180° + 9{,}1° = -170{,}9°$ (real negativo): $\angle N + \angle G = -18{,}2° \neq -180°$. **A interseção em $\omega_1$ não existe** — a semirreta ocupa apenas $\mathrm{Re} < 0$ e o ponto de $G$ em $\omega_1$ tem $\mathrm{Re} \approx +0{,}98$. Em $\omega_2$, verifica-se: $\angle N + \angle G = -52{,}75° - 127{,}25° = -180°$ ✓.

**c) Previsão da FD.** Em $\omega_2 = 2{,}02$ rad/s: $|G| = 0{,}197$ e $|N||G| = 1$ dá

$$A = \frac{4d|G|}{\pi} = \frac{4 \times 0{,}197}{\pi} = \mathbf{0{,}251}, \qquad T = \frac{2\pi}{2{,}02} = \mathbf{3{,}12\ s}.$$

**d) Simulação.** A simulação por eventos (histerese + planta de 2ª ordem) converge para **$A = 0{,}256$, $T = 3{,}09$ s ($\omega = 2{,}04$ rad/s)** — confirmando o cruzamento de alta frequência (erro < 3%). O sistema "escolhe" $\omega_2$: pelo critério de Loeb, é a única interseção **estável** (ao aumentar $A$, $-1/N$ sai da região envolvida pelo Nyquist para a não envolvida). Moral: em problemas com histerese, **sempre verifique o balanço complexo completo** e, quando houver mais de um cruzamento candidato, cheque a estabilidade do ciclo — a simulação é a verificação final.

---

**Fim do gabarito.** Números de referência das simulações: Labs 15 (partes 2–4) e 16 (partes 1, 3 e 4), executados com python-control 0.10.2.
