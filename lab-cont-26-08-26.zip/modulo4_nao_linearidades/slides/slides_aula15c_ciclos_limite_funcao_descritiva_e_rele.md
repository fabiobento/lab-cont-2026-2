# Slides — Aula 15c: Ciclos-Limite, Função Descritiva e o Experimento do Relé

> **Documento do professor.** Formato de cada slide: **Tela** (o que aparece), **Figura** (arquivo em `imagens/`), **Roteiro falado** (o que dizer). **Módulo autônomo — sem vídeos base**; preparação: `teoria_modulo4.md` §4.3 e **Lab 16** (Partes 2–4). Bloco 3 da semana 15 (~40 min).

---

### Slide 1 — Abertura

**Tela:** O termostato oscila há anos. Ninguém projetou polos sobre o eixo jω. Como?

**Roteiro:** "No Módulo 03, oscilar para sempre exigia um equilíbrio de ganho perfeito — o fio da navalha. Mas o termostato oscila há anos sem afinar ganho nenhum. Hoje a gente entende esse fenômeno, aprende a prever amplitude e frequência com conta de papel — e, no final, transforma a oscilação em instrumento de sintonia de PID."

---

### Slide 2 — Ciclo-limite: a órbita isolada

**Tela:** definição + retrato de fase: trajetórias por dentro e por fora convergem para a mesma órbita.

**Figura:** m4_fig08_retrato_fase.png

**Roteiro:** "Num sistema linear, cada condição inicial oscila na sua própria amplitude — uma família de órbitas. Aqui não: comece grande, comece pequeno, todo mundo converge para a MESMA órbita fechada. Isso é o ciclo-limite estável — um atrator. É assinatura de não linearidade, e as perguntas de engenharia são: qual amplitude, qual frequência, é estável?"

---

### Slide 3 — A ideia: um ganho que depende da amplitude

**Tela:** e = A·sen(ωt) → saída periódica → hipótese de filtragem → N(A) = (a1 + jb1)/A; depende de A!

**Roteiro:** "A saída da não linearidade a uma senoide não é senoidal — mas é periódica, e a planta, passa-baixas como quase sempre, joga fora os harmônicos altos. Sobrou o primeiro harmônico — e o ganho entre a senoide e ele é a função descritiva. A diferença brutal para o ganho linear: N depende da amplitude. E é essa dependência que ancora a oscilação."

---

### Slide 4 — As fórmulas clássicas

**Tela:** relé N = 4d/πA · saturação e zona morta (fórmulas) · relé com histerese: ganha fase −arcsen(h/A).

**Figura:** m4_fig05_funcoes_descritivas.png

**Roteiro:** "Decorem a do relé: 4d sobre πA — o ganho CAI com a amplitude. Cresceu a oscilação, cai o ganho, a malha desaperta; encolheu, sobe o ganho, a malha aperta. O ciclo se segura sozinho — o fio da navalha que não cai. No Lab 16 vocês verificam TODAS essas fórmulas por Fourier, com erro abaixo de 1 %."

---

### Slide 5 — Balanço harmônico: a condição de oscilação

**Tela:** 1 + N(A)G(jω) = 0 ⇔ G(jω) = −1/N(A); leitura gráfica: Nyquist × −1/N; relé: −1/N é o semi-eixo real negativo.

**Roteiro:** "Para a oscilação se auto-sustentar, o sinal tem que dar a volta na malha e voltar igual — a mesma condição de menos-um do Módulo 03, agora com N(A) no lugar de K. Graficamente: cruza a curva de Nyquist com a curva de menos um sobre N. Para o relé, essa curva é o próprio eixo real negativo — ou seja, procuramos onde o Nyquist cruza o eixo real, o nosso velho ωf."

---

### Slide 6 — Exemplo-âncora: a previsão completa

**Tela:** G = 1/[s(s+1)(s+2)] com relé d = 1: G(j√2) = −1/6 → A = 4/(6π) = 0,212; ω = 1,41 rad/s.

**Figura:** m4_fig06_nyquist_menos_1sobre_N.png

**Roteiro:** "Conta completa em duas linhas: o Nyquist cruza o eixo real em menos um sexto, na frequência raiz de 2; o balanço dá amplitude 0,212. E o número escondido: N(A) = 6 — exatamente o ganho crítico de Routh do Lab 12. A função descritiva e o Routh contam a mesma história por dois caminhos."

---

### Slide 7 — A confirmação

**Tela:** simulação: A = 0,220, ω = 1,38 rad/s — erros de 4 % e 2 %; critério de Loeb para a estabilidade do ciclo.

**Figura:** m4_fig07_ciclo_limite_sim.png

**Roteiro:** "Simulamos e... 0,220 e 1,38 — erros de 4 e 2 por cento. É a precisão típica do método: a hipótese de filtragem é boa, não exata. E a estabilidade do ciclo se lê no gráfico: percorra menos um sobre N com A crescente — se sai da região envolvida para a não envolvida, o ciclo é estável: perturbações são corrigidas, como o retrato de fase confirmou."

---

### Slide 8 — O experimento do relé: sintonia sem derrubar a planta

**Tela:** diagrama: relé ±d na malha → mede a e Pu → Ku = 4d/πa → tabela ZN (P, PI, PID).

**Roteiro:** "Ziegler-Nichols original: aumente o ganho até a beira da instabilidade — nenhuma fábrica autoriza. O experimento do relé de Åström: troque o controlador por um relé de amplitude conhecida — a planta oscila com amplitude LIMITADA, medimos amplitude e período, e o ganho último sai de graça: 4d sobre πa. É assim que os auto-tuners industriais funcionam de verdade."

---

### Slide 9 — Do relé ao PID de bancada: o fluxo completo

**Tela:** âncora: Ku ≈ 6, Pu = 4,44 s → PID-ZN (3,6 / 2,22 / 0,555) → Mp ≈ 72 % → refinado 20 % → sat + anti-windup 11 %.

**Roteiro:** "O Lab 16 executa o roteiro inteiro: mede no relé, calcula Ku, aplica a tabela ZN — e leva um susto: 72 % de sobressinal. Normal: ZN busca amortecimento de um quarto, é só o pontapé. Refinamos — menos ki, mais kd — e caímos para 20 %. Colocamos o atuador real e o anti-windup: 11 %. Do relé ao PID protegido em quatro passos — exatamente o que vocês farão no projeto final."

---

### Slide 10 — Fechamento do curso

**Tela:** "A teoria linear projeta; as não linearidades cobram — agora sabemos quanto, como nos proteger, e até como usá-las a nosso favor."

**Roteiro:** "Fechamos o curso onde a engenharia real começa: os limites físicos. Saturação, zona morta, histerese — agora vocês têm o mapa dos efeitos e as ferramentas: anti-windup para proteger, função descritiva para prever, experimento do relé para sintonizar. Semana que vem é de vocês: o projeto final na bancada, com o curso inteiro dentro."
