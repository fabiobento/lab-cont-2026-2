# Slides — Aula 15a: Não Linearidades Estáticas e Seus Efeitos na Malha

> **Documento do professor.** Formato de cada slide: **Tela** (o que aparece), **Figura** (arquivo em `imagens/`), **Roteiro falado** (o que dizer). **Módulo autônomo — sem vídeos base**; preparação: `teoria_modulo4.md` §4.1 e **Lab 15**. Bloco 1 da semana 15 (~40 min).

---

### Slide 1 — Abertura

**Tela:** Módulo 04 · Unidade III do PPC: o mundo real não é linear — saturação, zona morta, histerese.

**Roteiro:** "Quatorze semanas num mundo ideal: superposição vale, função de transferência existe, seno entra e seno sai. Hoje a gente olha pela janela desse mundo: o driver do motor entrega no máximo 12 V, o motor parado precisa vencer o atrito, o termostato liga e desliga em temperaturas diferentes. Três peças, três não linearidades — e três fenômenos que a teoria linear nem consegue escrever."

---

### Slide 2 — Onde a teoria linear falha

**Tela:** Lista: superposição ✗ · FT ✗ · resposta depende da amplitude ✓ · novos fenômenos: ciclos-limite, windup, erro residual.

**Roteiro:** "Guardem a frase inconveniente: sistema linear NÃO existe — existe sistema quase linear numa faixa. Todo o curso funciona porque trabalhamos dentro da faixa. Esta semana é sobre o que acontece fora dela — e como projetar levando isso em conta, em vez de fingir que não existe."

---

### Slide 3 — Saturação: a peça que está em TODA malha

**Tela:** característica: linear de ganho k até |e| = s; travada em ±u_max.

**Figura:** m4_fig01_saturacao.png

**Roteiro:** "Todo atuador satura — driver, DAC, válvula, músculo. Lembrem o Lab 14: nosso PD pediu 836 V de pico; na bancada, o driver entrega 12. Dentro da faixa, ganho k normal. Fora: o atuador dá o máximo que tem — e o 'ganho efetivo' despenca: uma senoide de amplitude 2 atravessa essa peça de ganho 2 como se o ganho fosse 1,2. Mesma peça, dois ganhos — impossível no mundo linear."

---

### Slide 4 — Zona morta: o erro que o ganho não elimina

**Tela:** característica (zero até ±d); fórmula yss = (kp·r − d)/(1 + kp); exemplos kp = 4 → 1,500; kp = 10 → 1,773.

**Figura:** m4_fig02_zona_morta_histerese.png (painel esquerdo)

**Roteiro:** "A zona morta é o atrito estático, a folga da engrenagem. O efeito é perverso: erros menores que d não geram ação NENHUMA — a malha estaciona numa faixa. A conta mostra: erro extra de d sobre 1 mais kp. Dobrar o ganho ajuda, mas NUNCA zera. É por isso que o robô para a 2 mm do alvo — e por que robótica vive de compensação de atrito, não só de sintonia."

---

### Slide 5 — Histerese e o relé: a peça com memória

**Tela:** relé com histerese (liga em +h, desliga em −h); caso limite h → 0: relé ideal; exemplo: termostato do chuveiro.

**Figura:** m4_fig02_zona_morta_histerese.png (painel direito)

**Roteiro:** "A histerese tem memória: a saída depende de onde a entrada veio. E quase sempre é colocada DE PROPÓSITO: sem ela, qualquer ruído na medição faz o relé chavear a mil hertz — e o contator morre em uma semana. O preço: a saída oscila para sempre. Essa oscilação permanente e robusta tem nome: ciclo-limite."

---

### Slide 6 — O termostato: ciclo-limite com conta EXATA

**Tela:** G = 1/(10s+1), d = 1, h = 0,5: y oscila entre ±h; T = 20·ln[(1+h)/(1−h)] = 21,97 s.

**Roteiro:** "Uma das poucas análises exatas de não linear que existem: na descida, a temperatura cai exponencialmente de +h até −h — meio período é 10 vezes ln 3. Período: 22 segundos; amplitude: exatamente h. E o trade-off de projeto: h pequeno, temperatura lisinha mas contator sofrendo; h grande, poucos chaveamentos mas ondulação grande. Engenharia é escolher o h."

---

### Slide 7 — Os três fenômenos novos

**Tela:** tabela: saturação → windup + resposta lenta; zona morta → erro residual; histerese → ciclo-limite. "Sem FT: simulação por equações de estado."

**Roteiro:** "Resumo da ópera: a saturação degrada e — com integrador — dispara o windup, que é a próxima aula; a zona morta cria erro que ganho nenhum elimina; a histerese oscila em ciclo-limite, que a última aula ensina a prever. E a mudança de ferramenta: sem função de transferência, simulamos as equações de estado diretamente — é o que o Lab 15 faz."

---

### Slide 8 — Lab 15 em uma frase + fechamento

**Tela:** Lab 15: mesma malha, três degraus diferentes, três respostas diferentes. Pergunta: "por que as curvas normalizadas divergem?"

**Roteiro:** "No Lab 15 vocês aplicam degraus de 0,5, 1 e 2 na MESMA malha com saturação e veem três respostas normalizadas diferentes — a assinatura da não linearidade. Tempo de subida que dobra, sobressinal que muda. Guardem a pergunta: se fosse PI em vez de P, o que aconteceria com o sobressinal? Resposta na próxima aula — e o nome disso é windup."
