# Slides — Aula 15b: Windup do Integrador e Anti-Windup

> **Documento do professor.** Formato de cada slide: **Tela** (o que aparece), **Figura** (arquivo em `imagens/`), **Roteiro falado** (o que dizer). **Módulo autônomo — sem vídeos base**; preparação: `teoria_modulo4.md` §4.2 e **Lab 16** (Parte 1). Bloco 2 da semana 15 (~40 min).

---

### Slide 1 — Abertura

**Tela:** O acidente mais comum da indústria: PI + atuador saturado.

**Roteiro:** "A malha mais comum da indústria é PI com atuador real. E o acidente mais comum é o que vamos ver hoje: o integrador enlouquece enquanto o atuador está no teto. Tem nome — windup, 'enrolamento' — e tem remédio de três linhas de código, que vai obrigatoriamente para o firmware do projeto final de vocês."

---

### Slide 2 — A sequência do acidente

**Tela:** 4 passos: ① erro grande → pedido enorme → teto; ② planta acelera no limite físico; ③ integrador continua somando; ④ y cruza r com integrador CHEIO → sobressinal.

**Roteiro:** "O integrador é um funcionário dedicado e teimoso: enquanto houver erro, ele soma. Só que ele não vê o teto do atuador — ele só vê o erro. Enquanto a planta sobe devagar no limite físico, ele acumula pedidos cada vez maiores. Quando a saída cruza a referência, ele está cheio — e a mola desenrola em cima da resposta: sobressinal que não estava no projeto."

---

### Slide 3 — A aritmética do windup

**Tela:** âncora G = 1/(10s+1), PI kp = 2, ki = 0,5, sat ±1,3: carga no cruzamento xi = 5,6 × regime xi = 2,0 → excesso de 180 %.

**Roteiro:** "Façam essa conta comigo: subindo com o teto de 1,3, a saída cruza a referência em 14,7 s; integrando o erro até lá, o integrador carrega 5,6. Mas para segurar o regime ele só precisa de 2,0. Excesso: 180 %. Esse excesso só sai por erro negativo — é o sobressinal de windup e a acomodação longa. Windup não é mistério: é aritmética."

---

### Slide 4 — Os três experimentos

**Tela:** tabela: ideal Mp = 11,5 % / ts = 19,7 s · windup 23,2 % / 39,3 s · anti-windup 3,2 % / 13,4 s.

**Figura:** m4_fig03_windup_resposta.png

**Roteiro:** "Três curvas, três mundos. A tracejada é o projeto linear — irreal, porque pede 2 volts num atuador de 1,3. A vermelha é o acidente: sobressinal dobrado, acomodação dobrada. A azul é com anti-windup: 3 % de sobressinal e acomodação mais rápida que a 'ideal'. Reparem: bem gerenciada, a saturação não é vilã — é o limite físico sendo usado de forma ótima."

---

### Slide 5 — Onde o windup mora: o sinal de controle

**Tela:** u pedido × u entregue, sem e com anti-windup; anotação "integrador continua carregando".

**Figura:** m4_fig04_windup_controle.png

**Roteiro:** "O drama fica explícito olhando o controle: no painel esquerdo, o pedido tracejado dispara para quase 3 enquanto o atuador entrega 1,3 — é o integrador se enchendo. No direito, com clamping, o pedido mal passa do teto: o integrador foi congelado a tempo. Diagnóstico de bancada: sobressinal estranho? Plote o sinal de controle. Sempre."

---

### Slide 6 — Anti-windup I: clamping

**Tela:** regra: saturado E erro a favor → dxi = 0; caso contrário → dxi = e. Pseudocódigo de 3 linhas.

**Roteiro:** "O clamping é o bom senso programado: 'já está pedindo demais e o erro pede mais ainda? Pare de anotar'. Erro contra a saturação integra livre — é ele quem tira o atuador do teto. Três linhas de código, zero parâmetros novos. Todo CLP comercial tem; o firmware de vocês terá."

---

### Slide 7 — Anti-windup II: back-calculation

**Tela:** dxi/dt = e + (1/Tt)(u − u_PI); Tt ≈ Ti (PI) ou √(Ti·Td) (PID); diagrama com realimentação do excesso.

**Roteiro:** "A versão sofisticada: mede a diferença entre o pedido e o entregue e realimenta ao integrador, que descarrega suavemente na velocidade de Tt. Clamping é binário, back-calculation é ajustável — os dois são padrão de indústria. E o detalhe fatal: o limitador tem que estar DENTRO do código — senão o controlador não enxerga o corte e o anti-windup não funciona."

---

### Slide 8 — Regras de ouro + ponte

**Tela:** ① saturou na simulação linear? refaça com a não linearidade; ② limitador + anti-windup em TODO PID digital; ③ rate limiter na referência. Ponte: "e as oscilações que aparecem do nada?"

**Roteiro:** "Três regras para a vida: simulou linear e o controle estourou? A simulação linear MENTIU — refaça com a saturação. Todo PID implementado nasce com limitador e anti-windup. E limitar a velocidade da referência evita meio problema. Na próxima aula: as oscilações que surgem do nada nas malhas não lineares — como prevê-las e como usá-las para sintonizar PID sem derrubar a planta."
