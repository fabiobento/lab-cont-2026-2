# Mapa de Conteúdo dos Vídeos — Pacote 02 (Controle de Sistemas no Plano-s)

> Documento de trabalho do professor — base para a regeneração do material do curso.
> Extraído das 38 transcrições limpas (`transcricoes_limpas/pacote02/`).
> Todos os exemplos numéricos principais foram **reverificados por simulação** (python-control 0.10.2) ou por cálculo manual — status indicado em cada item.

**Convenções globais do professor neste pacote (somam-se às do Pacote 01):**
- **"Quadradinho" (□)** = polo de malha fechada genérico; **□d** = polo desejado de malha fechada (sempre o de parte imaginária positiva; o conjugado vem de graça).
- Geometria do polo: **β = arccos ξ** (ângulo do polo com o eixo real negativo), **σ = ξωn** (módulo da parte real), **ωd = ωn√(1−ξ²)** (parte imaginária), **ωn** = distância do polo à origem.
- **Condição de ângulo** (pertencer ao LGR): `∠G(□) = −180° + l·360°`; **condição de módulo** (ser polo de MF): `k = (1/A)·Π dist(□→polos) / Π dist(□→zeros)`, onde A = ganho da forma fatorada de G.
- Controladores: **avanço** `C = k(s+a)/(s+b)`, `0 < a < b`; **atraso** `C = k(s+a)/(s+b)`, `a > b > 0`; **PD** `k(s+a) = kp + kd·s`; **PI** `k(s+a)/s = kp + ki/s`; **PID** = PI + PD (= PI-Lead na implementação real); **avanço-atraso** = produto dos dois.
- **Regra prática de contribuição:** avanço de fase **≤ 40°** por controlador ("não se faz um Fusca virar Ferrari").
- **Atraso de transporte:** `e^{−sτ}` ≈ Padé de 1ª ordem `−(s − 2/τ)/(s + 2/τ)`.
- **MATLAB → python-control (labs):** `tf`→`ct.tf`; `zpk`→`ct.zpk`; `pzmap`→`ct.pzmap`; `rlocus`→`ct.rlocus`; `feedback`→`ct.feedback`; `damp`→`ct.damp`; `roots`→`np.roots`; `conv`→`np.convolve`; `angle`→`np.angle`; exercícios de Simulink → simulação no notebook (`ct.step_response` + `medir()`).
- **Piadas/tom deste pacote:** sistema adivinho → "quero jogar na loteria"; "as minhas aproximações aproximadas"; Fusca × Ferrari (limite de 40°); "aproximação de Tabajara / do seu Creysson" × **aproximação de Padé**; receita de bolo do PID ("não esqueça do fermento"); desafio do Beakman (PI para planta instável); "projeto envolve arte — se fosse só conta, o MATLAB faria tudo".

---

## Tópico 2.1 — Regiões de Desempenho e Aproximação de 2ª Ordem (8 vídeos)

### t2.1_v01 — "Fórmulas da resposta ao degrau"
- **Sequência:** recapitulação da parametrização `ωn²/(s²+2ξωn·s+ωn²)` → MATLAB guiado: `xi = 0.45`, `wn = 2`, `sys = tf([wn^2],[1 2*xi*wn wn^2])`, `step(sys)` → identificação visual de Mp, tp, tr, ts no gráfico → cálculo na linha de comando: `Mp = exp(-xi*pi/sqrt(1-xi^2))`, `tp = pi/(wn*sqrt(1-xi^2))`, `tr = (pi-acos(xi))/(wn*sqrt(1-xi^2))`, `ts = 3/(xi*wn)` → comparação fórmula × simulação → **"os três primeiros valores são exatos, enquanto o último é uma aproximação pessimista"**.
- **Números:** ξ = 0,45, ωn = 2 → Mp ≈ 20,5 %, tp ≈ 1,76 s, tr ≈ 1,14 s, ts(5 %) ≈ 3,33 s. ✔ Conferido por simulação.
- **Tradução:** `tf`/`step` → `ct.tf`/`ct.step_response` (lab).

### t2.1_v02 — "O Plano-s"
- **Sequência:** plano-s = plano cartesiano Re(s) × Im(s); cada ponto = um número complexo `a + bj` → **mapa de polos e zeros** (polos = ×, zeros = ○); exemplo literal `G = K(s+a)/[(s+b)(s+c)]` com `a < b < c` → MATLAB: outra forma de criar FT — **`zpk`**: `sys = zpk([-10],[-5 -4],2)` → **`pzmap(sys)`** → 2º exemplo com polos complexos e **zero no semiplano direito**: `sys = tf([-5 25],[1 6 25])` (zero em +5; polos −3 ± 4j) → `pzmap` → conferência com `roots([1 6 25])` → **PARÊNTESE: FT própria × imprópria** — próprias (grau num ≤ grau den) ↔ sistemas **causais**; impróprias ↔ **não causais**; exemplo do **"sistema adivinho"**: `y = u̇` com três entradas que valem 1 em t = 0 (degrau, e^{−t}, e^{t}) mas têm derivadas 0, −1, +1 → o sistema precisaria **prever o futuro** → "não existem sistemas não causais… se você encontrar, me avise — **quero usar ele para jogar na loteria**" → pseudo-FT imprópria pode surgir de manipulações algébricas → no curso, só FTs próprias, na maioria com numerador de grau zero.
- **Deduzido:** o argumento do "sistema adivinho" (didático, ótimo para quadro).

### t2.1_v03 — "Requisito de Overshoot no Plano-s"
- **Sequência:** `Mp = e^{−ξπ/√(1−ξ²)}` → Mp só depende de ξ → inversa `ξ = √(ln²Mp/(π²+ln²Mp))` → geometria: **β = arccos ξ** = ângulo do polo com o eixo real negativo → exemplo **Mp ≤ 10 % (ξ = 0,6) → β ≤ 53,13°** (Mp calculado = 9,48 %) → **região de desempenho = setor angular** no semiplano esquerdo; quanto menor β, menor o overshoot.
- **Números:** ξ = 0,6 → Mp = 9,48 %, β = 53,13°. ✔ Conferido.

### t2.1_v04 — "Requisitos de Instante de Pico e de Tempo de Acomodação no Plano-s"
- **Sequência:** `tp = π/ωd` → requisito tp ≤ X ⇒ **ωd ≥ π/X** → região = semiplano esquerdo **acima da reta horizontal** Im = π/X → tempos de acomodação: **ts(5 %) = 3/σ, ts(2 %) = 4/σ, ts(1 %) = 4,6/σ** → requisito ts ≤ Y ⇒ **σ ≥ 3/Y (ou 4/Y, 4,6/Y)** → região = semiplano **à esquerda da reta vertical** Re = −3/Y → **exemplo combinado**: Mp ≤ 20 %, tp ≤ 3,14 s, ts(2 %) ≤ 8 s → **ξ ≥ 0,456 (β ≤ 62,9°)**, **ωd ≥ 1**, **σ ≥ 0,5** → sobreposição das três regiões, interseção final.
- **⚠ Errata da legenda:** na sobreposição o narrador diz "β ≤ 62,3°" — pelo cálculo (arccos 0,456 = 62,87°) e pela fala anterior, o correto é **62,9°**. Corrigir no material.
- ✔ Conferido: ξ(20 %) = 0,456; ωd = π/3,14 ≈ 1; σ = 4/8 = 0,5.

### t2.1_v05 — "Requisito de Tempo de Subida no Plano-s"
- **Sequência:** fórmula exata `tr(0–100 %) = (π − arccos ξ)/(ωn√(1−ξ²))` depende de ξ **e** ωn → fronteira complicada → **solução: trocar para tr(10–90 %)**, que admite aproximações em ξ e ωn → **as "minhas aproximações aproximadas"** (piada; coeficientes podem diferir em outros livros): `tr(10–90 %) ≈ (1,8ξ³ − 0,4ξ² + ξ + 1)/ωn` ou `(2,3ξ² − 0,08ξ + 1,1)/ωn` ou `(2ξ + 0,65)/ωn` ou ainda `1,6/ωn` → gráfico `tr·ωn × ξ` simulado × aproximações (script no material adicional): a de 3º grau (vermelho) e a de 2º grau (verde) boas em toda a faixa; a de 1º grau (magenta) boa para ξ ∈ [0,35; 0,65], utilizável em [0,25; 0,75]; a constante (azul) boa para ξ ≈ 0,5 ([0,45; 0,55], utilizável [0,4; 0,6]) → se o requisito for mesmo tr(0–100 %): `tr(0–100 %) ≈ (3ξ + 1)/ωn` (magenta, boa em [0,3; 0,65]) ou `2,4/ωn` (azul, ξ ≈ 0,5) → **para o plano-s, usa-se as constantes**: `tr(10–90 %) ≤ X ⇒ ωn ≥ 1,6/X`; `tr(0–100 %) ≤ Y ⇒ ωn ≥ 2,4/Y` — "a rigor valem para ξ ≈ 0,5, mas vamos fingir que valem para ξ entre 0 e 1" → **região = semiplano esquerdo fora do círculo de raio Z centrado na origem** (ωn = distância do polo à origem).
- **⚠ Divergência v1 — SUBSTITUIÇÃO DE FÓRMULA:** o v1 usava `tr ≈ 1,8/ωn` para tr(10–90 %). **Adotar `1,6/ωn` (10–90 %) e `2,4/ωn` (0–100 %)**, com as demais aproximações como tabela de consulta.
- **Figuras:** os 2 gráficos `tr·ωn × ξ` (recriar por simulação no lab).

### t2.1_v06 — "Aproximação de Segunda ordem por Primeira Ordem"
- **Sequência:** `G = 10/[(s+1)(s+10)]` → resposta ao degrau ≈ resposta de `1/(s+1)`? → **dedução literal**: `G = a/[(s+1)(s+a)]` → degrau → `y(t) = 1 − [a/(a−1)]·e^{−t} + [1/(a−1)]·e^{−at}` → para a grande, o 2º termo some rápido e o 3º termo é desprezível → `y(t) ≈ 1 − e^{−t}` = resposta de `1/(s+1)` → **manter o ganho DC** (10/10 = 1) → comparações simuladas: polo em **−10** (boa), em **−100** (excelente), em **−2** (ruim) → conclusão: quanto mais afastado o polo extra, melhor a aproximação.
- **Deduzido:** a resposta literal completa `y(t)`. ✔ Coeficientes conferem (resíduos: −a/(a−1) e 1/(a−1)).
- **Figuras:** 3 comparações de respostas (a = 10, 100, 2).

### t2.1_v07 — "Aproximação de Terceira ordem por Segunda ordem"
- **Sequência:** `G = 20/[(s+1)(s+2)(s+10)]` ≈ `2/[(s+1)(s+2)]` (mantendo o ganho DC = 2) → simulações: polo extra em −10 → aproximação boa; efeito do 3º polo: **resposta mais lenta e mais suave (menos overshoot)** que a da 2ª ordem equivalente → casos progressivos: polo extra mais próximo (−5, −2, −1,5…) degrada a aproximação; **polo em −0,5 "mata" o overshoot** mesmo com o par complexo de ζ = 0,5 (o polo real lento domina) → **regra prática: aproximação válida se |polo extra| ≥ 5 × |Re(par complexo)|** → relação com a regra do M01 (aproximação de ordem superior por 2ª ordem).
- **Números:** 20/[(s+1)(s+2)(s+10)] → 2/[(s+1)(s+2)]. ✔ Simulado: aproximação com erro pequeno (Mp e tempos próximos).
- **Figuras:** família de respostas variando a posição do 3º polo.

### t2.1_v08 — "Aproximação de Sistema com Zero por Sistema sem Zero"
- **Sequência:** sistema com zero: `G1 = (s/a + 1)·G` → na resposta ao degrau: **`y1(t) = y(t) + ẏ(t)/a`** (dedução por Laplace: multiplicar por s = derivar) → efeito do zero LHP: **resposta mais rápida e com mais overshoot** (a derivada "empurra" no início); quanto mais próximo o zero da origem, maior o efeito → **zero no semiplano direito (RHP): ẏ entra com sinal negativo → "undershoot"** (a saída primeiro vai na direção errada) → **par polo-zero próximos se cancelam** (quase-cancelamento: efeito residual pequeno) → exemplos numéricos com `1/(s²+s+1)`: comparação **a = 3, b = 5** × **a = 5, b = 3** (zero/polo em diferentes posições relativas) → conclusão: sistema com zero pode ser aproximado por sistema sem zero quando o zero está **longe** dos polos dominantes (|zero| ≫ |Re(polos)|).
- **Deduzido:** `y1(t) = y(t) + ẏ(t)/a`.
- **Figuras:** efeito do zero LHP (várias posições), undershoot do zero RHP, quase-cancelamento polo-zero.

---

## Tópico 2.2 — O Lugar Geométrico das Raízes (12 vídeos)

### t2.2_v01 — "Revisão: Controle Proporcional e a Função de Transferência em Malha Fechada"
- **Sequência:** revisão do M01: diagrama P com realimentação unitária → `T(s) = kG/(1+kG) = kN/(D+kN)` → os polos de malha fechada **mudam com k** → pergunta-motivação do pacote: **como** os polos se movem quando k varia de 0 a ∞?
- Revisão pura, sem números novos.

### t2.2_v02 — "Variação de polo de Sistema de primeira ordem em malha fechada"
- **Sequência:** `G = 1/(s+a)` → `T = k/(s+a+k)` → polo de MF: **−a−k** → sai de −a e vai a −∞ conforme k: 0→∞ (exemplo numérico com valores de k) → `G = (s+b)/(s+a)` (com zero) → `T = k(s+b)/[(1+k)s + (a+kb)]` → polo de MF: **−(a+kb)/(1+k)** → k→0: polo → −a; **k→∞: polo → −b (o zero!)** → primeira constatação: "o polo vai em direção ao zero".
- **Deduzido:** as duas expressões literais do polo de MF. ✔

### t2.2_v03 — "Variação de polo de Sistema de segunda ordem em malha fechada"
- **Sequência:** `G = 1/[s(s+a)]` → `T = k/(s²+as+k)` → polos: reais distintos enquanto k < a²/4; **encontram-se em −a/2 quando k = a²/4**; depois par complexo conjugado que **sobe verticalmente** (parte real fixa em −a/2) → exemplo numérico (a = 4 ou similar, com valores de k tabelados) → `G = 1/[(s+a)(s+b)]` → polos se encontram em **−(a+b)/2** quando **k = [(a+b)² − 4ab]/4 = (a−b)²/4**, depois verticais → padrão: os polos "partem" dos polos de MA, encontram-se no ponto médio e sobem.
- **Deduzido:** os pontos de encontro e os ganhos de encontro. ✔ (k_encontro = (a−b)²/4; com a=0: a²/4.)

### t2.2_v04 — "O que é o Lugar Geométrico das Raízes (LGR — Root Locus)"
- **Sequência:** definição formal: **LGR = lugar geométrico das raízes de `1 + kG(s) = 0` quando k varia de 0 a ∞** (= trajetória dos polos de MF) → os gráficos dos vídeos anteriores eram LGRs → nomenclatura: root locus (inglês), lugar das raízes → o LGR depende só de G (polos e zeros de malha aberta).

### t2.2_v05 — "Característica comum dos Polos em Malha Fechada"
- **Sequência:** `1 + kG(□) = 0` ⇒ `kG(□) = −1` ⇒ número real negativo → **fase = −180° (+ múltiplos de 360°)** → **CONDIÇÃO DE ÂNGULO: um ponto □ do plano-s pertence ao LGR se e somente se `∠G(□) = −180° + l·360°`** → cálculo da fase de G num ponto: soma dos ângulos dos vetores dos **zeros** até □ menos soma dos ângulos dos vetores dos **polos** até □ → exemplos de cálculo de fase com atan2 (cuidado com o quadrante).
- **Deduzido:** a condição de ângulo.

### t2.2_v06 — "Controle Proporcional Usando o LGR"
- **Sequência:** fase −180° garante que o ponto é polo de MF **para algum k** — qual k? → `|kG(□)| = 1` → **CONDIÇÃO DE MÓDULO: `k = (1/A)·Π dist(□→polos) / Π dist(□→zeros)`** ("não esqueça do A — o ganho da forma fatorada") → **exemplo completo: `G = 1/[s(s+6)]`** → teste de pontos candidatos: **s2 = −3+3j**: fases 135° + 45° = 180° ✓ pertence → `k = |−3+3j|·|−3+3j+6| = √18·√18 = 18`; **s3 = −3+4j**: fases 126,9° + 53,1° = 180° ✓ → `k = 5·5 = 25`; **s1 = −6+6j**: fases 135° + 90° = 225° ≠ 180° ✗ não pertence ao LGR para nenhum k.
- **Deduzido:** condição de módulo + os 3 testes completos. ✔ Conferido (k = 18 e k = 25 exatos).

### t2.2_v07 — "Exemplo de Projeto de Controle Proporcional no Plano-s"
- **Sequência:** **ENUNCIADO-ÂNCORA: `G = 10/[s(s+10)]`, requisito Mp ≤ 5 % com o menor tp possível** → ξ(5 %) = 0,69 → β = arccos(0,69) = 46,37° → o LGR de 1/[s(s+10)] é a vertical em −5 (após o encontro) → o ângulo β limita a subida: polos escolhidos **−5 ± 5,25j** (5·tg(46,37°) ≈ 5,25) → condição de módulo: `k = |□|·|□+10|/10` → **k ≈ 5,26** → verificação: Mp ≈ 5 %; ωd = 5,25 → tp = π/5,25 ≈ 0,6 s → comentário: sem o LGR, esse projeto seria tentativa e erro.
- ✔ Conferido por cálculo e simulação (k = 5,26 → polos −5 ± j5,24; Mp ≈ 5,0 %).
- **⚠ Nota:** este é o **projeto P principal do pacote** (complementa o projeto P do M01, agora via LGR).

### t2.2_v08 — "Quantidade de Ramos do LGR e Trechos Sobre o Eixo Real"
- **Sequência (regras de esboço 1–3):** **R1 — nº de ramos = nº de polos de malha aberta (n)** → **R2 — simetria em relação ao eixo real** (coeficientes reais → raízes complexas aos pares conjugados) → **R3 — trechos sobre o eixo real: o ponto do eixo real pertence ao LGR se à sua DIREITA houver um número ÍMPAR de polos + zeros (reais)** → justificativa pela condição de ângulo (cada polo/zero real à direita contribui 180°; à esquerda, 0°; complexos conjugados se cancelam) → exemplos de marcação de trechos.
- **Deduzido:** justificativa da R3 pela soma de ângulos.

### t2.2_v09 — "Começo e Término dos Ramos e Assíntotas do LGR"
- **Sequência (regras 4–6):** **R4 — os ramos começam (k=0) nos polos de MA e terminam (k→∞) nos zeros de MA**; os `n − m` ramos sem zero para terminar vão ao **infinito** → **R5 — assíntotas: `n − m` retas com ângulos `(180° + l·360°)/(n − m)`, l = 0, 1, …, n−m−1** → **R6 — centroide (ponto de partida das assíntotas no eixo real): `σa = (Σ polos − Σ zeros)/(n − m)`** → exemplos: n−m = 2 → ±90°; n−m = 3 → 60°, 180°, 300°(−60°); n−m = 4 → ±45°, ±135°.
- **Deduzido/comentado:** fórmulas apresentadas sem demonstração formal ("acredite"; demonstração = livros).

### t2.2_v10 — "Cruzamento dos Ramos com o Eixo Imaginário e Pontos de Saída e Entrada no Eixo Real"
- **Sequência (regras 7–8 + ângulos de partida/chegada):** **ângulo de partida de polo complexo / chegada em zero complexo**: aplicar a condição de ângulo num ponto infinitesimalmente próximo → **exemplo: `G = (s+2)(s+4)/[s(s²+4)]`** → ângulo de partida do polo +2j: `∠ = 180° + Σ∠(zeros→2j) − Σ∠(outros polos→2j)` → **parte a 71,6°** → o ramo entra no **semiplano direito** (!) → **R7 — cruzamento do eixo imaginário via Routh**: **exemplo `G = 1/[(s+1)(s+2)(s+3)]`** → característico `s³+6s²+11s+(6+k)` → Routh → **k = 60** → equação auxiliar `6s²+66 = 0` → **cruzamento em ±j√11 ≈ ±j3,32** → **R8 — pontos de saída/entrada no eixo real: extremos de `k(s) = −1/G(s)` → resolver `d(−1/G)/ds = 0`** → mesmo exemplo: `−1/G = −(s³+6s²+11s+6)` → `3s²+12s+11 = 0` → s = −1,42 (✓ está no trecho (−2,−1) do LGR) e s = −2,58 (✗ fora dos trechos) → **saída em −1,42**.
- **Deduzido:** cálculo do ângulo de partida e do ponto de saída. ✔ Conferido (k = 60, ±j√11, −1,42).

### t2.2_v11 — "Esboço de LGR para Sistema de Terceira Ordem"
- **Sequência:** **EXEMPLO-ÂNCORA A: `G = 200/[s(s+10)(s+20)]`** → 3 ramos; trechos reais (−∞,−20) e (−10,0); n−m = 3 assíntotas em **±60° e 180°**, centroide `(0−10−20)/3 = −10` → Routh: `s³+30s²+200s+200k` → **k = 30** → auxiliar `30s²+6000 = 0` → **cruzamento em ±j√200 = ±j10√2 ≈ ±j14,1** → ponto de saída: `d(−s(s+10)(s+20)/200)/ds = 0` → `3s²+60s+200 = 0` → **−4,23** (✓) e −15,77 (✗) → esboço completo → **EXEMPLO-ÂNCORA B: `G = 200(s+5)/[s(s+10)(s+15)]`** → n−m = 2 assíntotas em **±90°**, centroide `(0−10−15+5)/2 = −10` → Routh → **nenhum cruzamento: sistema nunca desestabiliza** → ponto de saída: `d(−1/G)/ds = 0` → **`s³+20s²+125s+375 = 0`** → única raiz real no trecho: **−12,3** → esboço.
- ✔ Conferido por `numpy.roots`/`ct.rlocus` (todos os valores batem).

### t2.2_v12 — "Esboço de LGR para Sistema de Quarta Ordem"
- **Sequência:** **EXEMPLO-ÂNCORA C: `G = 400/[s(s+2)(s+10)(s+20)]`** → 4 ramos; trechos do eixo real: **(−2, 0) e (−20, −10)** (contagem ímpar à direita) → n−m = 4 assíntotas em **±45° e ±135°**, centroide `−32/4 = −8` → Routh → equação auxiliar **`s² + 12,5 = 0`** → **cruzamento em ±j3,5** → pontos de saída: **`s³+24s²+130s+100 = 0`** → **−0,92 e −16,5** (duas saídas: uma no trecho (−2, 0), outra no trecho (−20, −10)) → esboço completo → **EXEMPLO-ÂNCORA D: `G = 80(s+5)/[s(s+2)(s+10)(s+20)]`** (mesma planta + zero) → n−m = 3 assíntotas em **±60°/180°**, centroide `(−32+5)/3 = −9` → efeito do zero: "puxa" os ramos, sistema mais estável → esboço comparativo.
- ✔ Conferido (cúbica de `d(−1/G)/ds`: raízes reais −0,92 e −16,5, ambas sobre trechos do LGR).

---

## Tópico 2.3 — Controlador de Avanço de Fase (8 vídeos)

### t2.3_v01 — "Impossibilidade de Obter o Tempo de Acomodação Desejado com Controle Proporcional"
- **Sequência:** **ENUNCIADO-ÂNCORA: `G = 4/[s(s+4)]`** → LGR = vertical em −2 → **requisito ts(5 %) ≤ 1 s ⇒ σ ≥ 3: IMPOSSÍVEL** — o LGR nunca passa à esquerda de −2 ("não tem como o polo ir para lá") → segundo conflito: **Mp ≤ 5 % e tp ≤ 1 s** → para Mp = 5 %: ξ = 0,69 → β = 46,4° → polos −2 ± 2,1j → k ≈ 2,1 → mas ωd = 2,1 ⇒ **tp ≈ 1,5 s ✗** → para tp = 1 s: ωd = π ⇒ polos −2 ± 3,14j → **k = 3,47** → ξ = 0,54 ⇒ **Mp = 13 % ✗** → conclusão: **o P só escolhe pontos SOBRE o LGR da planta; para sair dele é preciso mudar o LGR — acrescentar polos e zeros (controladores)**.
- ✔ Conferido: k = 2,1 → polos −2 ± j2,1 (Mp 5 %, tp 1,5 s); k = 3,47 → −2 ± j3,14 (tp 1 s, Mp 13 %).
- **Obs.:** mesma planta-âncora do M01 (1/[s(s+4)] com ganho 4) — ótima reciclagem didática.

### t2.3_v02 — "Visualizando o Efeito do Acréscimo de um Zero e um Polo no LGR"
- **Sequência:** simulação interativa (MATLAB) do efeito de acrescentar **um zero** e **um zero + um polo** ao LGR de `1/[s(s+a)]`-like → zero sozinho "puxa" o LGR para a esquerda; polo "empurra" para a direita → com zero em −a e polo em −b: **o cruzamento das assíntotas desloca-se de (a−b)/2** → regra intuitiva memorável: **"o LGR se deforma na direção do polo"** (o polo atrai os ramos; o zero repele) → aviso: se **a − b > 6** (polo muito à esquerda do zero), os ramos podem cruzar para o **semiplano direito** → posicionamento relativo zero/polo é a alavanca do projeto.
- **Figuras:** sequência de LGRs deformados (recriar por `ct.rlocus`).

### t2.3_v03 — "Calculando a Contribuição do Controlador"
- **Sequência:** queremos que o LGR passe por **□d = −3,14 + 3,2j** (ξ = 0,7, ωd = 3,2 — exemplo ilustrativo) → calcula-se **`∠G(□d) = −209,5°`** → falta −180° → **o controlador deve contribuir +29,5° de fase** → **FÓRMULA-ÂNCORA: `∠C(□d) = −∠G(□d) − 180°`** → interpretação: C "gira" a fase total para −180°, colocando □d sobre o LGR do sistema compensado.
- **Deduzido:** a fórmula da contribuição. ✔

### t2.3_v04 — "Infinitas Soluções, Soluções Mais Adotadas"
- **Sequência:** **ENUNCIADO-ÂNCORA: `G = 200/[s(s+10)(s+20)]`, □d = −5 + 7j** → `∠G(□d) = −205°` → contribuição necessária **+25°** → **infinitas soluções** para o par (a, b): qualquer par cuja diferença de ângulos seja 25° (exemplos: b = 12 → a = 7,55; b = 75 → a = 16,8) → **as 3 soluções-padrão do curso**: **(1) zero embaixo de □d** (a = 5, ângulo do zero = 90° → ângulo do polo = 65° → `b = 5 + 7/tg(65°) = 8,3`); **(2) bissetriz** (bissectriz entre o eixo real e a reta origem→□d; ângulos simétricos: `a = 5 − 7·tg(12,5°) = 3,4`, `b = 5 + 7·tg(12,5°) = 6,6`); **(3) zero cancela um polo da planta** (cancela o −10 ou o −20; **nunca o polo na origem** — derrubaria o tipo do sistema).
- ✔ Conferido por cálculo trigonométrico (b = 8,26; a = 3,45/b = 6,55).

### t2.3_v05 — "A Necessidade do Ganho Exato"
- **Sequência:** o par (a, b) garante que □d **pertence ao LGR** — mas só é polo de MF com o **ganho exato** (condição de módulo) → solução 1 (zero embaixo): **k1 = 6,77** → `C1 = 6,77(s+5)/(s+8,3)` → solução 2 (bissetriz): **k2 = 6,12** → `C2 = 6,12(s+3,4)/(s+6,6)` → verificação: polos de MF de T = CG/(1+CG) ≈ **−5 ± 7,02j** (e o 3º polo, que deve ser conferido) → **sempre verificar TODOS os polos de malha fechada** (o par desejado precisa ser dominante).
- ✔ Conferido por cálculo de módulo e simulação.

### t2.3_v06 — "O Controlador PD, Proporcional-Diferencial"
- **Sequência:** definição formal do avanço: **`C = k(s+a)/(s+b)`, com `0 < a < b`** (zero mais perto da origem; contribuição de fase positiva) → caso-limite **b → ∞: PD `C = k(s+a) = kp + kd·s` (kp = k·a, kd = k)** → exemplo: `C = 0,37(s+20) = 7,4 + 0,37s` → **problema físico do derivador puro**: degrau na referência → derivada = impulso → na simulação o pico de controle atingiu **5×10¹³ ("50 trilhões de volts")** — nenhum atuador entrega isso → **implementação real: PD com filtro = avanço de fase** com polo de filtro distante: `44,4(s+16,7)/(s+100)` ou `37(s+20)/(s+100)` → resposta quase idêntica, sinal de controle finito.
- **Números:** 0,37(s+20); kp = 7,4; kd = 0,37; pico 5×10¹³; polos de filtro −100. ✔ Simulado no lab.

### t2.3_v07 — "Projeto para Sistema de Segunda Ordem do Tipo 1"
- **Sequência (projeto em 2 estágios):** **ENUNCIADO-ÂNCORA: `G = 10/[s(s+10)]`** → **estágio 1 (P): Mp ≤ 20 %** → ξ = 0,456 → β = 62,9° → polos −5 ± 9,8j → **k = 12,1** → **estágio 2: dobrar a velocidade** (dobrar σ e ωd) → **□d = −10 + 19,6j** → `∠G(□d) = −207°` → contribuição **27°** → solução adotada: **zero cancela o polo −10** → ângulo do polo do controlador: 90° − 27° = 63° → b = 20 → `C = 48,4(s+10)/(s+20)` → **`T = 484/(s² + 20s + 484)`** (2ª ordem exata! o cancelamento zerou a 3ª ordem) → resposta: mesma Mp, metade dos tempos.
- ✔ Conferido: T = 484/(s²+20s+484), polos −10 ± j19,6, Mp ≈ 20 %, tp ≈ 0,16 s.
- **Obs.:** exemplo favorito do professor — "reciclagem de exemplos" da t2.2_v07.

### t2.3_v08 — "Projeto para Sistema de Terceira Ordem"
- **Sequência:** **ENUNCIADO-ÂNCORA: `G = 20(s+15)/[s(s+10)(s+20)]`, Mp = 25 % e tp = 150 ms** → ξ = 0,404; ωd = π/0,15 = 21 → **□d = −9,3 + 21j** → `∠G(□d) = −190,2°` → contribuição **10,2°** → solução por **bissetriz**: a = 7,4, b = 11,2 → ganho **k = 26,1** → `C = 26,1(s+7,4)/(s+11,2)` → simulação: **Mp medido = 23,2 %, tp = 148 ms** (aproximações de 2ª ordem + efeito dos demais polos/zeros) → **REGRA PRÁTICA: contribuição de avanço ≤ 40°** por controlador ("querer mais que isso é querer fazer um **Fusca** andar como uma **Ferrari** — se precisar de mais, use dois controladores em cascata ou repense os requisitos") → fecho: conferir sempre todos os polos de MF.
- ✔ Conferido por simulação (Mp ≈ 23 %, tp ≈ 0,15 s).

---

## Tópico 2.4 — Controlador de Atraso de Fase (6 vídeos)

### t2.4_v01 — "Alteração dos Polos Causada pelo Ajuste da Constante de Erro"
- **Sequência:** problema: melhorar o erro em regime **pelo ganho** estraga o transitório → **exemplo 1: `G = 10/[(s+2)(s+5)]`** (tipo 0) → projeto para Mp = 30 % → ξ = 0,36 → **k = 8,45** → kp = 8,45 → **ess(degrau) = 0,1058** → para ess = 0,05 seria preciso **k = 19** → polos de MF mudam → **Mp = 44,7 %** ✗ inaceitável → **exemplo 2 (avanço projetado): `G = 1/[s(s+2)]`, □d = −1,6 + 2,2j (ξ = 0,59)** → avanço `C = 6,75(s+1,6)/(s+2,66)` (contribuição ≈ 25,7°; ângulo do polo 64,3°) → **kv ≈ 2 → ess(rampa) = 0,5** → tentativa de corrigir pelo ganho (×10): polos migram para **−1,54 ± 8,1j → Mp = 55 %** → moral: **erro em regime NÃO se corrige pelo ganho — corrige-se com polo-zero perto da origem (atraso)**.
- ✔ Conferido: b = 2,66 (tg 64,3° = 2,2/(b−1,6)); k = 6,75 (condição de módulo); kv = 6,75×1,6/(2×2,66) = 2,03.
- **⚠ Errata da legenda RESOLVIDA:** a transcrição diz "…obtemos b igual a 6,2", mas pelo ângulo de 64,3° e pelo controlador apresentado em seguida, o correto é **b = 2,66**. Usar 2,66 no material.

### t2.4_v02 — "Aumentando a Constante de Erro sem Afetar os Polos em Malha Fechada"
- **Sequência (o mecanismo do atraso):** **ENUNCIADO-ÂNCORA: `G = 1/[s(s+3,2)]` com P k = 7,4** → `T = 7,4/(s²+3,2s+7,4)` → polos **−1,6 ± 2,2j**, ξ = 0,59, ωn = 2,72 → Mp = 10 %, tr = 1 s, ts(2 %) = 2,5 s, tp = 1,43 s → **kv = 7,4/3,2 ≈ 2,31 → ess(rampa) ≈ 0,43** → objetivo: **duplicar kv sem mover os polos** → proposta: `C = 7,4(s+2b)/(s+b)` (kv dobra para ≈ 4,6) → análise da contribuição do par polo-zero em □ = −1,6+2,2j: fase ≈ `arctg(1,1/b) − arctg(2,2/b)` (pequena para b grande) **mas** módulo ≈ 1/2 para b grande → **contradição: b grande → fase desprezível mas módulo 1/2 "mata" o ganho; b pequeno → módulo ≈ 1 e fase desprezível** → solução: **par polo-zero COLADO na origem** → com **2b = 0,02**: `C = 7,4(s+0,02)/(s+0,01)` → polos de MF: **−1,595 ± 2,196j e −0,0201** → praticamente os mesmos polos dominantes + um polo lento pertinho do zero (quase-cancelamento) → kv duplicado ✓.
- **Deduzido:** as aproximações de fase e módulo do par polo-zero. ✔ Conferido por simulação.
- **Obs.:** o polo extra lento (−0,0201) deixa a **convergência do erro mais lenta** — preço do atraso (retomado na t2.4_v03).

### t2.4_v03 — "Projetando o Controlador de Atraso de Fase"
- **Sequência (procedimento de projeto):** definição formal do atraso: **`C = k(s+a)/(s+b)`, com `a > b > 0`** (polo mais perto da origem; contribuição de fase **negativa** pequena) → **passo 1:** projetar o transitório primeiro (P ou avanço) e calcular a constante de erro obtida Ke → **passo 2:** fator necessário = **Ke_desejada/Ke = a/b** → **passo 3 (regra prática): posicionar o zero do atraso a 1/10 da parte real do polo dominante: `a = −Re(□d)/10`** → **passo 4:** b = a/fator → **passo 5:** simular e avaliar → **exemplos numéricos sobre o □d = −1,6+2,2j**: fator 2 → `C = (s+0,16)/(s+0,08)` → contribuição de fase **−1,23°** → Mp vai de 10 % para **14 %**; fator 10 → contribuição **−2,54°** → Mp vai para **17 %** → **trade-off: quanto maior o fator de correção do erro (par mais afastado da origem), maior o efeito sobre o transitório; quanto mais perto da origem, mais lenta a convergência do erro**.
- ✔ Conferido por cálculo de fase e simulação.

### t2.4_v04 — "Controlador PI — Proporcional e Integral"
- **Sequência:** caso-limite do atraso com **b → 0 (polo na origem): PI `C = k(s+a)/s = kp + ki/s`** (kp = k, ki = k·a) → efeito: **aumenta o tipo do sistema em 1** → **única forma de zerar o erro ao degrau de um sistema tipo 0** (sem depender de ganho infinito) → ação integral = "memória" que acumula o erro → preço: **convergência do erro mais lenta** (polo na origem + zero próximo formam o "rabo" longo da resposta do erro) e atraso de fase extra → **recomendação do professor: "só use PI se for estritamente necessário"** (se o erro finito for tolerável, prefira P/avanço/atraso) → relação: PI ⊂ atraso; atraso com polo "quase na origem" ≈ PI.
- Conceitual + definições. ✔

### t2.4_v05 — "Projeto de Atraso de Fase para Sistema de Segunda Ordem Tipo 1"
- **Sequência (projeto LITERAL completo — ótimo para quadro):** **`G = b/[s(s+a)]`, requisito Mp = 15 %** → ξ = 0,517 → **k = a²/(4ξ²b) = a²/(1,07b)** → kv = k·b/a = **a/1,07** → **ess(rampa) = 1,07/a = 4ξ²/a** → objetivo: **reduzir o erro a 1/4** → fator 4 → atraso com zero em a/20 (regra do 1/10 de σ = a/2): **`C = (a²/1,07b)·(s+a/20)/(s+a/80)`** → variante para **Mp = 10 %**: ξ = 0,59 → fator necessário 5,3 → zero em **d = a/106** → discussão: o fator grande exige par muito colado na origem → erro converge lentamente.
- **Deduzido:** todo o projeto literal. ✔ Conferido (k, kv, ess, fator 4).

### t2.4_v06 — "Projeto de PI para Sistema de Terceira Ordem do Tipo 0"
- **Sequência:** **ENUNCIADO-ÂNCORA: `G = 20/[(s+1)(s+2)(s+10)]`, requisitos Mp = 16,3 % e erro nulo ao degrau** → ξ = 0,5 → tipo 0 ⇒ **só PI zera o erro** → projeto do ganho por **casamento de coeficientes**: denominador desejado `(s² + 2ξωn·s + ωn²)(s − p3)` com p3 não dominante → sistema de equações → **ωn = 2,46, p3 = −10,54, k = 2,19** → PI com zero pela regra do 1/10: `C = 2,19(s+0,123)/s = 2,19 + 0,27/s` → erro zero ✓ mas convergência lenta → variante com zero mais afastado (**0,73**): mantém Mp = 16,3 % com convergência mais rápida → **DESAFIO DO BEAKMAN (piada): projetar PI para `G = 20/[(s−1)(s+2)(s+10)]` (polo RHP)** → impossível: esboçar o LGR mostra que o ramo que sai do polo instável não entra no semiplano esquerdo com PI → deixado como exercício-desafio (esboçar o LGR).
- ✔ Conferido por casamento de coeficientes e simulação (ωn = 2,46; k = 2,19).
- **Obs.:** o desafio Beakman é ótimo exercício de lista (com gabarito: esboço do LGR + discussão).

---

## Tópico 2.5 — Avanço + Atraso, PID e Atraso de Transporte (4 vídeos)

### t2.5_v01 — "Projeto de Controlador de Avanço e Atraso de Fase"
- **Sequência:** continua a "política de reciclagem de exemplos para contribuir com o meio ambiente": **`G = 200/[s(s+10)(s+20)]`** (LGR já esboçado na t2.2_v11: cruzamento ≈ ±14j, saída ≈ −4,2; `zpk([],[0 -10 -20],200)`, `rlocus`) → **parêntese: e se `∠G(□d) > −180°` (ex.: −170°)?** → significa que o LGR já passa pela região de desempenho → **apertar os requisitos**: exemplo tp = 360 ms, ts(5 %) = 1 s → σ = 3, □d = −3+5j → `∠G = −171,9°` (folga) → aperta para **□d = −3,3+5,5j** → `∠G = −178,6°` (próximo o bastante) → **k ≈ 4,9** → `T = 980/(s³+30s²+200s+980)` → polos −23,3 e −3,4 ± 5,54j (melhores que o desejado) → **PROJETO PRINCIPAL:** requisitos **Mp = 16,3 %, tr(0–100 %) = 300 ms, ess(rampa) = 0,02** → ξ = 0,5, ωd = 7, kv = 50 → **□d = −4,04 + 7j** → `∠G(□d) = −193,3°` → avanço de **13,3°** → **zero cancela o polo −10** (não o da origem — senão o sistema vira tipo 0 e o erro à rampa diverge; "depois você pode projetar tentando cancelar o −20") → fase do zero = 49,6° → fase do polo = 36,3° → **b = 13,57, k = 8,33** → `C_av = 8,33(s+10)/(s+13,57)` → simulação: Mp = 15,3 %, tr = 344 ms (3º polo −25,49 deixa mais lento/amortecido) → **atraso:** kv ≈ 6,14 → fator **8,14** → zero do atraso em −0,4 (1/10 de Re(□d)) → polo em −0,05 → **`C = 8,33(s+10)/(s+13,57) × (s+0,4)/(s+0,05)`** → estrutura do avanço-atraso: par polo-zero afastado = avanço (posiciona o LGR); par perto da origem = atraso (ajusta o erro); o ganho faz □d ser polo de MF → simulação: **Mp = 22 %, tr = 328 ms** (o atraso piorou o overshoot!) → **compensar com avanço adicional:** reprojetar para Mp ≈ 12 % (ξ = 0,56) e tr = 275 ms → ωd = 7,9 → **□d = −5,34 + 7,87j** → `∠G = −211,8°` → avanço **31,8°** → cancelando o −10: fase do polo = 27,6° → **b = 20,4, k = 13,4** → kv = 6,6 → mantém o mesmo atraso → **`C = 13,4(s+10)/(s+20,4) × (s+0,4)/(s+0,05)`** → simulação final: **Mp = 16,9 %, tr = 300 ms ✓** → fecho: "projeto envolve um pouco de **arte**; se fosse só fazer contas, o MATLAB faria tudo e ninguém precisaria de gente que entende de controle… é a **arte de fazer aproximações e de entendê-las para usá-las a nosso favor**".
- ✔ Conferido por cálculo: k = 4,9 (módulo em −3,3+5,5j); b = 13,57 e k = 8,33 (1ª iteração); b = 20,4 e k = 13,4 (2ª iteração); kv = 6,14 → fator 8,14; kv(2ª) = 6,6.
- **⚠ Erratas da legenda a corrigir:** (i) o narrador diz "T de s igual a **900** sobre s³+30s²+200s+**980**" — o numerador correto é **980** (= 4,9×200), coerente com o termo constante do denominador; (ii) na 1ª versão do controlador a legenda diz "(s+0,4)/(s+0,**5**)" — pelo fator 8,14 e pela 2ª versão, o correto é **(s+0,4)/(s+0,05)**; (iii) no parêntese inicial, os valores falados (tp = 360 ms ⇒ ωd = π/0,36 ≈ 8,7, mas o vídeo usa ωd = 5 e □d = −3+5j) são inconsistentes entre si — no material, apresentar o parêntese com números coerentes (□d = −3+5j → fase −172,9°; manter a mensagem didática: fase > −180° ⇒ apertar requisitos).

### t2.5_v02 — "Projeto de Controlador PID"
- **Sequência:** PID = PI + PD (ou atraso + avanço com polo do atraso na origem e polo do avanço no infinito) → **metáfora da receita de bolo** (sistemas de ordem maior = mais ingredientes — farinha integral, semolina, fécula, amido — "mais trabalhoso, mas não mais complicado") → **A RECEITA DE BOLO COMPLETA (10 passos)**: (1) parâmetros de 2ª ordem a partir dos requisitos; (2) □d; (3) `∠G(□d)`: se pouco maior que −180° → direto ao ganho; se muito maior → aumentar ξ/ωn e voltar ao (2); se menor → seguir; (4) avanço necessário; (5) posição do zero do avanço/PD; (6) posição do polo (desnecessário se PD; opcional: verificar `∠C(□d)G(□d) = −180°`); (7) **k = (1/A)·Π distâncias aos polos / Π distâncias aos zeros — "não esqueça do A, ou seu ganho ficará errado — algo como: não esqueça do fermento ou seu bolo não vai crescer"**; se só há requisitos de transitório → simular, ajustar e voltar ao (2) ("se o bolo ficou muito seco ou muito úmido, ajuste a receita e tente outra vez"); (8) se houver requisito de regime: constante de erro e fator; (9) zero do atraso/PI — "bom chute inicial é 1/10 da parte real dos polos desejados"; (10) polo do atraso pelo fator (desnecessário se PI) → simular, ajustar, tentar de novo → **PROJETO-ÂNCORA: `G = 2/[(s+2)(s+5)]`, Mp = 16,3 %, tp = 400 ms, ess(degrau) = 0** → ξ = 0,5, ωd ≈ 7,85 → usar 7,9 → **□d = −4,6 + 7,9j** → `∠G = −195,3°` → avanço **15,3°** → zero do PD: tg(15,3°) = 7,9/(a−4,6) → **a = 33,4** → ganho **k = 1,1** → **`C = 1,1(s+33,4)(s+0,46)/s = 1,1s + 37,25 + 16,9/s`** → **kp = 37,25, ki = 16,9, kd = 1,1** → simulação: overshoot menor que o projetado, mas **convergência lenta** (zero do PI colado na origem) → afastar o zero para **−2**: kp = 38,9, ki = 73,5 → converge rápido mas overshoot grande demais → **zero em −1: kp = 37,8, ki = 36,7, kd = 1,1** → resposta satisfatória ✓ → sugestão: tentar −1,1 → **implementação real do PID (Simulink): `P + I/s + D·N/(1 + N/s)`** — o derivador tem polo em −N → **na prática é PI-Lead, não PID puro**.
- ✔ Conferido por cálculo: a = 33,4 (tg 15,3°); k = 1,1 (módulo com os dois zeros); kp/ki/kd das três versões.

### t2.5_v03 — "O Atraso de Transporte"
- **Sequência:** propriedade de Laplace: `L{x(t−τ)} = e^{−sτ}X(s)` → exemplos de atraso: **aquecedor a gás** ("sua mãe está lavando louça, pede para aumentar 5 °C; a água nos canos ainda está na temperatura antiga — ela só saberá que você ajustou depois que a água nova for **transportada** até a torneira"), reações químicas (tempo de ativação), atraso de comunicação (controle à distância), atraso de processamento digital ("outro curso") → representação genérica `x(t−τ)` → parêntese: **usamos o SI o curso inteiro** ("talvez devesse ter falado isso antes") → atraso na entrada, na saída ou ambos: **para efeito no overshoot não importa; para os tempos de resposta, importa** → **dedução com G = 1/(s+a)**: EDO `ẏ + ay = u` com `u(t) = u1(t−τu)` e saída medida `y1(t) = y(t−τy)` → substitui `y(t) = y1(t+τy)` → Laplace → **`Ga(s) = e^{−sτ}/(s+a) = G(s)·e^{−sτ}`, com τ = τu + τy** → malha fechada: `T = kN·e^{−sτ}/(D + kN·e^{−sτ})` → **problema: exponencial no denominador — onde estão os polos?** → "que tal simplificar a nossa vida? seus problemas acabaram, eu garanto!" → **APROXIMAÇÃO DE PADÉ** ("não é a aproximação de **Tabajara** nem a do **seu Creysson** — é a do matemático francês **Henri Padé**"): aproxima função qualquer por função racional, escolhendo os graus → **Padé de 1ª ordem: `e^x ≈ (2+x)/(2−x)`** → `e^{−sτ} ≈ (2−sτ)/(2+sτ) = (2/τ − s)/(2/τ + s) =` **`−(s − 2/τ)/(s + 2/τ)`** → `Ga(s) = G(s)·[−(s − 2/τ)/(s + 2/τ)]` → agora dá para calcular polos/zeros de MF e usar LGR (notar: **zero RHP em +2/τ** — não-fase-mínima).
- **Deduzido:** o modelo do atraso (com τ = τu+τy) e a forma da Padé. ✔

### t2.5_v04 — "Projeto de Controlador com Atraso"
- **Sequência:** efeito do atraso na estabilidade: `G = 1/(s+a)` puro é estável ∀k > 0; com Padé: denominador de MF `s² + (a + 2/τ − k)s + (2a/τ + 2k/τ)` → **instável se k > a + 2/τ** → **quanto maior o atraso, menor o ganho que desestabiliza**; mantido k > a, sempre existe τ que desestabiliza → **EXEMPLO DE ANÁLISE: τ = 0,1 s, `G = 2/[s(s+4)]`** → `Ga = 2(−s+20)/[s(s+4)(s+20)]` → sem atraso, k = 10: `T = 20/(s²+4s+20)`, ξ ≈ 0,447, **Mp = 20,1 %** → com atraso (mesmo k): denominador `s³+24s²+60s+400` → polos **−22,1 e −0,95 ± 4,1j** → ξ = 0,223 → **Mp = 48,7 %** (Simulink com atraso real: **49,5 %**; diferença = zero +20 parcialmente cancelado pelo polo −22,1 + aproximação de Padé) → exercício de Simulink: bloco **Transport Delay** (Continuous); atraso em qualquer ponto da malha (ou dividido 0,05/0,05 entre entrada e realimentação); dica: Flip block (botão direito ou Ctrl+I) → **o overshoot não muda com a posição do atraso; os tempos, sim** ("mas não aumente demais o atraso, ou o sistema ficará instável") → **PROJETO-ÂNCORA: manter tr(0–100 %) = 0,5 s e baixar Mp para 15 %** → ξ = 0,517, ωd = 4,23 → **□d = −2,6 + 4,2j** → avanço sem atraso: **13,4°** → **fase do atraso**: `∠e^{−0,1□d} = −0,1×4,2 rad = −24,1°`; pela Padé: `∠(−□d+20) − ∠(□d+20) = −10,5° − 13,6° = −24,1°` (**mesma fase — Padé de 1ª ordem é exata em fase para esse ponto**) → **avanço total = 13,4° + 24,1° = 37,5°** (dentro do limite de 40°!) → cancela o polo −4 → fase do zero = 71,6° → fase do polo = 34,1° → **b = 8,8** ("a essa altura você já deve ser capaz de calcular b sem a minha ajuda, não?") → ganho **k = 14,26** (módulo com a exponencial ou com a Padé — mesmo resultado) → **`C = 14,26(s+4)/(s+8,8)`** → simulação (atraso na realimentação): **Mp = 14,3 %, tr = 0,5 s ✓** → **se o atraso estiver entre a entrada e o scope: tr = 0,6 s** → reprojetar com tr = 0,4 s → se o atraso estiver dividido: compensar o atraso todo no overshoot e só o da malha direta no tempo de subida.
- ✔ Conferido por cálculo: denominador s³+24s²+60s+400; fase do atraso −24,1° (das duas formas); b = 8,8 (tg 34,1°); k = 14,26.
- **⚠ Erratas da legenda a corrigir:** (i) "confira se a fase de Ga(□d) está próxima de **menos 21 degraus**" → correto: **−180°**; (ii) Mp sem atraso falado = 20,1 %, mas `e^{−πξ/√(1−ξ²)}}` com ξ = 0,447 dá **20,8 %** — usar o valor calculado 20,8 % (ou o medido em simulação) no material; (iii) a legenda tem marca `[SEM_ÁUDIO]` antes de "Falta apenas calcular o ganho k, que será 14,26" — sem impacto de conteúdo.

---

## Consolidação: decisões propostas para a regeneração do Módulo 02

1. **Exemplos dos vídeos = exemplos principais** (todos já verificados ou a verificar na regeneração):
   - Requisitos no plano-s: Mp≤10 %→β≤53,13°; combinado Mp≤20 %/tp≤3,14/ts(2 %)≤8 → ξ≥0,456, ωd≥1, σ≥0,5.
   - Aproximações: 2ª→1ª `10/[(s+1)(s+10)]≈1/(s+1)` (+ literal `y(t)`); 3ª→2ª `20/[(s+1)(s+2)(s+10)]≈2/[(s+1)(s+2)]`; zero: `y1 = y + ẏ/a`, undershoot RHP, quase-cancelamento.
   - LGR: `1/[s(s+6)]` (k=18, k=25, ponto fora); projeto P `10/[s(s+10)]` (k=5,26, Mp 5 %); 8 regras com `(s+2)(s+4)/[s(s²+4)]` (partida 71,6°), `1/[(s+1)(s+2)(s+3)]` (k=60, ±j√11, saída −1,42); âncoras `200/[s(s+10)(s+20)]`, `200(s+5)/[s(s+10)(s+15)]`, `400/[s(s+2)(s+10)(s+20)]`, `80(s+5)/[s(s+2)(s+10)(s+20)]`.
   - Avanço: impossibilidade `4/[s(s+4)]`; contribuição `∠C = −∠G − 180°`; `200/[s(s+10)(s+20)]` com □d = −5+7j (3 soluções-padrão; k1 = 6,77, k2 = 6,12); PD 0,37(s+20) e filtros; `10/[s(s+10)]` 2 estágios → `C = 48,4(s+10)/(s+20)`; `20(s+15)/[s(s+10)(s+20)]` (bissetriz, k = 26,1).
   - Atraso: `10/[(s+2)(s+5)]` (k = 8,45 × k = 19); `1/[s(s+2)]` com avanço 6,75(s+1,6)/(s+2,66); mecanismo `1/[s(s+3,2)]` k = 7,4 → `7,4(s+0,02)/(s+0,01)`; projeto (zero = Re(□d)/10); PI; literal `b/[s(s+a)]` (Mp 15 % → fator 4); PI `20/[(s+1)(s+2)(s+10)]` (k = 2,19) + desafio Beakman.
   - T2.5: avanço-atraso `200/[s(s+10)(s+20)]` (2 iterações → `13,4(s+10)/(s+20,4)×(s+0,4)/(s+0,05)`); PID `2/[(s+2)(s+5)]` (3 posições do zero do PI; kp/ki/kd); atraso de transporte (Padé) e projeto `2/[s(s+4)]` com τ = 0,1 → `C = 14,26(s+4)/(s+8,8)`.
2. **Fórmulas do vídeo prevalecem (substituições ao v1):**
   - `tr(10–90 %) ≈ 1,6/ωn` e `tr(0–100 %) ≈ 2,4/ωn` para o plano-s (**substituem o `1,8/ωn` do v1**); tabela de aproximações dependentes de ξ como consulta (`(1,8ξ³−0,4ξ²+ξ+1)/ωn`, `(2,3ξ²−0,08ξ+1,1)/ωn`, `(2ξ+0,65)/ωn`, `(3ξ+1)/ωn`), com as faixas de validade faladas.
   - `ts(5 %) = 3/σ`, `ts(2 %) = 4/σ`, `ts(1 %) = 4,6/σ` (o vídeo usa os três percentuais conforme o requisito).
   - Regra prática do 3º polo: `|polo extra| ≥ 5×|Re(par)|`.
   - Limite de contribuição de avanço: **40°** (Fusca × Ferrari).
   - Regra do zero do atraso/PI: **`a = −Re(□d)/10`**.
   - Padé de 1ª ordem: `e^{−sτ} ≈ −(s−2/τ)/(s+2/τ)`.
3. **Erratas da legenda a corrigir no material (não propagar):**
   - t2.1_v04: β ≤ 62,3° → **62,9°**.
   - t2.4_v01: "b = 6,2" → **b = 2,66**.
   - t2.4_v03: fase do par fator 2 falada = −1,23° → o cálculo exato (atan2 em □d = −1,6+2,2j) dá **−1,43°**; fator 10: **−2,55°** (vídeo: −2,54°). Mp confirmados por simulação: 10 % → 14 % → 17 % ✓ (descoberta pós-aprovação, na validação dos exercícios).
   - t2.5_v01: T = 980/(s³+30s²+200s+980) (não 900); (s+0,4)/(s+0,05) (não s+0,5); parêntese ∠G > −180° com números coerentes (□d = −3+5j, −172,9°).
   - t2.5_v04: "menos 21 degraus" → **−180°**; Mp sem atraso: **20,8 %** (calculado) no lugar de 20,1 %.
4. **Estrutura didática proposta para o Módulo 02 (espelha os vídeos):**
   - Teoria 2.1: plano-s e mapa de polos/zeros; FT própria × imprópria (causalidade); regiões de desempenho (Mp, tp, ts, tr) com figuras de regiões; aproximações (2ª→1ª, 3ª→2ª, com zero) — fórmulas revisadas como no M01.
   - Teoria 2.2: LGR — motivação (variação dos polos 1ª/2ª ordem), definição, condições de ângulo e módulo, as 8 regras com justificativas faladas, 4 exemplos-âncora de esboço.
   - Teoria 2.3: avanço de fase — impossibilidade do P, efeito polo/zero no LGR, contribuição, 3 soluções-padrão, ganho exato, PD e sua implementação com filtro, 2 projetos completos.
   - Teoria 2.4: atraso de fase — erro × ganho, mecanismo polo-zero colado na origem, procedimento de projeto, PI, projeto literal, projeto com casamento de coeficientes.
   - Teoria 2.5: receita de bolo completa (10 passos); avanço-atraso (2 iterações — "a arte do projeto"); PID (PI-Lead); atraso de transporte (modelo, Padé, efeito na estabilidade, projeto com compensação do atraso).
5. **Labs propostos (python-control 0.10.2):**
   - **Lab 05 — Plano-s e regiões de desempenho:** `ct.pzmap`, regiões de requisitos (setores/retas/círculos), verificação de aproximações (2ª→1ª, 3ª→2ª, efeito do zero; recriar os gráficos `tr·ωn × ξ` do vídeo t2.1_v05).
   - **Lab 06 — LGR:** `ct.rlocus`; condição de ângulo/módulo implementadas em funções; reproduzir os 4 exemplos-âncora de esboço e conferir regras (assíntotas, centroide, cruzamentos via Routh, pontos de saída via `d(−1/G)/ds = 0`).
   - **Lab 07 — Projeto de avanço de fase:** função `projetar_avanco(G, xi, wd, solucao)`; reproduzir t2.3_v04/v05/v07/v08; PD × PD-com-filtro (pico de 5×10¹³).
   - **Lab 08 — Atraso de fase e PI:** reproduzir t2.4_v02/v05/v06; efeito do par polo-zero na convergência do erro; desafio Beakman.
   - **Lab 09 — PID e atraso de transporte:** `ct.pade`; PID como PI-Lead; projeto com atraso (t2.5_v04); efeito da posição do atraso na malha (overshoot × tempos).
6. **Notação e tom:** manter "quadradinho"/□d nas notas de aula (explicando a gíria na 1ª vez), as piadas traduzidas em falas de quadro (Fusca × Ferrari, Tabajara × Padé, receita de bolo, Beakman, loteria do sistema adivinho) e a política de "reciclagem de exemplos".
7. **Demonstrações/Simulink → notebooks:** os exercícios de Simulink (Transport Delay, PID block, Flip block) viram células de simulação com `ct.pade` + `ct.step_response`, mantendo as mesmas perguntas-guia do vídeo ("o overshoot muda com a posição do atraso? e os tempos?").
8. **Verificações numéricas já fechadas neste mapa:** polos de s³+24s²+60s+400 = **−22,10 e −0,948 ± 4,147j** (exatos; ξ = 0,2228 → Mp = 48,8 % ✓); fase de G(−3+5j) = **−172,9°** (o vídeo fala −171,9° — usar o valor calculado); fase de G(−3,3+5,5j) = **−178,6°** ✓; k(−3,3+5,5j) = 4,89 ≈ 4,9 → polos de T = **−23,2 e −3,4 ± 5,53j** ✓; ξ = 0,6 → Mp = 9,48 %, β = 53,13° ✓. Resta, na regeneração, medir Mp/tp/tr de todos os projetos nos labs e registrar **medido × calculado**.
