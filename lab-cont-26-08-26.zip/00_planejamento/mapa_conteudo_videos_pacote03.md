# Mapa de Conteúdo dos Vídeos — Pacote 03 (Controle Usando a Resposta em Frequência)

> Documento de trabalho do professor — base para a regeneração do material do curso (Módulo 03).
> Extraído das **42 transcrições limpas** (`transcricoes_limpas/pacote03/`), do arquivo bruto `legendas_03.txt`.
> Todos os exemplos numéricos principais foram **reverificados por simulação** (python-control 0.10.2) ou por cálculo — status indicado em cada item.

## Novidades da VERSÃO-3 neste pacote

Comparação das árvores V2 × V3 (40 → 42 vídeos). **Dois vídeos novos**, nenhum removido:

| Vídeo novo V3 | Posição | Conteúdo |
|---|---|---|
| **t3.2_v06** — "Nichols-Black-Bode de 2ª e 3ª ordem. Estender relações entre ωc e ωn e entre ξ e PM de sistema de 2ª ordem do Tipo 1 para qualquer sistema" | Tópico 02 → 02 - Carta de Nichols-Black → vídeo 05 | Estende PM≈100ξ e ωn≈ωc para 2ª ordem tipo 0 e 3ª ordem |
| **t3.3_v09** — "A margem de fase e o efeito do atraso no diagrama de Nyquist." | Tópico 03 → 03 - Atraso de transporte → vídeo 03 | Espiral de Nyquist com atraso; infinitos cruzamentos; instabilização para K grande |

## Convenções globais do professor neste pacote (somam-se às dos Pacotes 01 e 02)

- **Resposta em frequência:** para entrada `A·sen(ωt)`, o regime permanente senoidal é `y(t) = |G(jω)|·A·sen(ωt + ∠G(jω))` — mesma frequência, amplitude e fase dadas por `G(jω)`.
- **Diagrama de Bode:** módulo em dB (`20·log₁₀|G(jω)|`) e fase em graus, ambos × log₁₀(ω).
- **Convenção de esboço assintótico (CONFIRMADA numericamente):** quebras de módulo em ±20 dB/déc por polo/zero; fase interpolada por **reta de ωq/5 a 5·ωq** em torno de cada quebra (na fala, "meia década antes e depois" — na prática ±0,7 década, inclinação ≈64°/déc). **Erro máximo da fase ≈ 11° (0,19 rad)** — exatamente o valor que os vídeos citam; erro de módulo máx. **3 dB** na quebra.
- **Frequências-chave:** **ωc** = cruzamento de 0 dB (|G|=1); **ωf** = fase = −180°. **PM = ∠G(jωc) + 180°**; **GM = −|G(jωf)|dB**.
- **Ponte frequência × tempo (2ª ordem tipo 1 e, com cuidado, qualquer sistema):** **PM ≈ 100·ξ** (boa até ξ ≈ 0,65, erro ~5°); **ωn ≈ ωr ≈ ωc**; fórmula exata `PM = arctan[2ξ/√(√(1+4ξ⁴) − 2ξ²)]`; `Mr = 1/(2ξ√(1−ξ²))` e `ωr = ωn√(1−2ξ²)` (ξ ≤ 0,707). **Folga de 5–10° na PM** para absorver as aproximações (regra repetida em todos os projetos).
- **Carta de Nichols-Black:** fase de MA × módulo de MA, com lugares geométricos de |T| e ∠T de malha fechada; ajuste de ganho = **translação vertical** da curva ("papel transparente").
- **Nyquist:** contorno horário cobrindo o semiplano direito (com **indentação** de raio → 0 em torno de polos na origem); **Z = N + P** (Z = polos de MF instáveis; N = voltas horárias em torno de **−1/K**; P = polos de MA instáveis); metade do diagrama = polar de ω: 0→∞, outra metade = reflexão no eixo real.
- **Atraso de transporte:** `G(s) = Gn(s)·e^{−δs}`; `|e^{−jδω}| = 1` (módulo inalterado), `∠ = −δω` (fase cai sem limite → espiral de Nyquist).
- **Projeto na frequência — receitas:**
  - **Avanço:** `C = K(Ts+1)/(αTs+1)`, α < 1; `sen φmáx = (1−α)/(1+α)`; `ωmáx = 1/(T√α)` (média geométrica zero-polo); ganho do compensador em ωmáx = `1/√α`; `K = √α/|G(jωc)|` (ou `KdB = 10·log α − |G(jωc)|dB`).
  - **Atraso de fase:** `C = (s−z)/(s−p)` com |p| < |z|; ganho DC multiplicado por `z/p`; regra: polo em **ωc/10** (ou ωc/20) para não perturbar a PM.
  - **PD:** `C = kp + kd·s`; `φ = arctan(kd·ωc/kp)`; **fórmulas diretas: `kp = cos φ/|G(jωc)|`, `kd = sen φ/(ωc·|G(jωc)|)`**; polo de filtragem em **100·ωc** (custa ~0,6° de fase); **PD = avanço com polo no ∞**; CUIDADO: derivada do degrau ≈ impulso → sinal de controle enorme.
  - **PI:** `C = kp + ki/s = kp(s−z1)/s` (z1 = −ki/kp); **PI = atraso com polo em 0**; regra: `|z1| ≤ ωc/10`.
  - **PID:** produto PD × PI (`C = kp(1 + (kd/kp)s)/(s/p1 + 1) · (s−z1)/s`); PD cuida do transitório em ωc, PI zera o erro em regime.
- **Tom/personagens:** Desafio do Jackman × professor Rubens (carrinho, overshoot de 30 % sem modelo); laboratório de controle por computador do ITA; circuito RC didático (470 kΩ, 220 nF); "E jadabim, jadabá!"; "Crianças, não tentem isso em casa".

## Erratas da transcrição deste pacote (para corrigir no material regenerado)

| # | Vídeo | Transcrição diz | Correto (verificação) |
|---|---|---|---|
| 1 | t3.1_v06 | "1/√2 ≈ 0,07" (2×) | **0,707** — o próprio vídeo conclui −3 dB corretamente |
| 2 | t3.1_v06 | "duas assíntotas: 0 para altas frequências, e π/2 para altas frequências" | **0 para BAIXAS**, −90° para altas |
| 3 | t3.1_v10 | fórmula da PM exata truncada | `PM = arctan[2ξ/√(√(1+4ξ⁴) − 2ξ²)]` ✔ conferida (ξ=0,5 → 51,8°) |
| 4 | t3.2_v04 | "K vezes G igual a 100 vezes 10.000 sobre s²+4s+29" | `KG = 1000/(s²+4s+29)` (K=10) |
| 5 | **t3.2_v08** | "G = 0,005/[(s+0,03)(s+0,5)(s+**1**)]" | **`(s+0,1)`** no lugar de `(s+1)` — **confirmado por simulação: os 6 âncoras do vídeo só batem com (s+0,1)**; com (s+1) o sistema MF é superamortecido (Mp = 0) e PM = 81° |
| 6 | t3.3_v05 | passagem sobre K₂ < 0 contraditória ("também estabiliza… Z = 0+1 = 1") | texto truncado; **resultado final correto: estável para 0 < K < 1/R** |
| 7 | t3.4_v07 | "p = −ωc/10 = **−2,27**" | **−0,27** (ωc ≈ 2,76 → p = −0,276; z = 2,2·p = 0,61 ✔) |
| 8 | **t3.4_v08** | "p = −ωc/20 ≈ −0,14" e "C₂ = (s+0,14)/(s+0,28)" | p = −ωc/**200** ≈ −0,14; **C₂ = (s+0,28)/(s+0,14)** (zero 2× o polo para dobrar o ganho DC). Simulado: literal → ess = 17,5 % (erra); corrigido → ess ≈ 6 % ✔ |
| 9 | t3.5_v04/v05 | "s **menos** 0,018 sobre s" (zero do PI) | z1 = −0,018 → **`C = (s+0,018)/s`** (notação do curso: `C = (s−z1)/s`) |
| 10 | t3.5_v02 | sinal de controle do PD "cerca de 20 vezes maior" | simulado: pico inicial **≈ 215×** (836 vs 3,9) — a mensagem didática se mantém, com o valor simulado |

---

## Tópico 3.1 — Resposta em Frequência e Diagrama de Bode (11 vídeos)

### t3.1_v01 — "Motivação do estudo de Controle Usando a Resposta em Frequência" *(Desafio do Jackman)*
- **Sequência:** Mr. Bean engenheiro eletricista (tese sobre controle autoajustável) → **Desafio do Jackman** ao professor Rubens: projetar **controlador proporcional** para o carrinho (saída = posição, entrada = tensão do motor) com **overshoot de 30 %**, **sem equações diferenciais nem função de transferência** e **com uma única chance** de fechar a malha — mas podendo testar o sistema **em malha aberta** com quaisquer entradas → professor vence ("E jadabim, jadabá!") → **2º desafio**: mesmo overshoot com **instante de pico reduzido à metade**, agora com controlador mais elaborado → vence de novo → gancho: nas próximas 5 semanas, como projetar sem modelo (controle P, avanço de fase, atraso de fase, PI/PD/PID).
- **Uso didático:** é a **motivação-mestre do módulo** — reproduzir a pergunta "projetar sem modelo?" na abertura da teoria e da aula 10. O carrinho reaparece em t3.1_v03/v04.

### t3.1_v02 — "Introdução"
- **Sequência:** apresentação (professor Rubens; 2º curso da série; pré-requisito = curso 1) → problema: **e quando não há modelo por princípios físicos?** (sistema complexo, subsistemas inacessíveis) → história: técnicas dos **laboratórios Bell, décadas de 1920–40, Black, Nyquist e Bode** (amplificar sinais para cabos transcontinentais; sem computação → projetos **gráficos e experimentais**) → formulação matemática simples e poderosa, ainda das mais usadas na indústria → bônus: ferramentas de **estabilidade e robustez** de malha fechada.
- **Deduzido:** contextualização histórica completa (Bell Labs).

### t3.1_v03 — "A resposta em frequência de sistemas LIT" *(vídeo-âncora teórico)*
- **Sequência:** **ensaio experimental do carrinho** (senoide de 2 V pico a pico; ω = 3 → amplitude de saída ≈ 30 cm, mesma frequência; ω = 6 → amplitude cai e defasagem cresce; ω = 12 → pior) → **dedução completa**: `G(s) = K/Π(s−pi)` estável, entrada `A·sen(ωt)` → expansão em frações parciais → termos dos polos morrem; sobra `a₀e^{jωt} + ā₀e^{−jωt}` → `a₀ = G(jω)·A/(2j)` → **`y(t) = |G(jω)|·A·sen(ωt + ∠G(jω))`** → definição de **regime permanente senoidal** → **exemplo RC**: `G = 1/(0,1034s+1)` (R = 470 kΩ, C = 220 nF) → ω = 1, 10, 100 rad/s → |G| = 0,99 / 0,7 / 0,10; fases −0,1 / −0,8 / −1,47 rad → conferido com simulações das senoides.
- ✔ **Conferido numericamente:** RC em ω=1/10/100 → |G| = 0,995/0,695/0,096; fases −5,9°/−46,0°/−84,5°.
- **Tradução:** simulações de senoides (malha aberta) → `ct.forced_response` no lab.

### t3.1_v04 — "Possibilidades de visualização da resposta em frequência, Diagrama de Bode"
- **Sequência:** dados medidos (amplitudes e Δt) → módulo = razão de amplitudes; fase por **regra de três: Δt/T = ∠G/2π** → tabela cresce → gráfico → frequências de várias ordens de grandeza → **escala logarítmica em ω** → módulo varia muito → **`|G(jω)|dB = 20·log₁₀|G(jω)|`** e fase em graus × log ω = **Diagrama de Bode**.
- Sem números novos; construção conceitual do diagrama a partir da medição.

### t3.1_v05 — "Relação entre o diagrama de Bode e a Função de Transferência"
- **Sequência:** RC revisitado → `|G(jω)| = 1/√((ωRC)²+1)`, `∠G = −arctan(ωRC)` → assíntota de alta frequência: `|G|dB ≈ −20·log(RC) − 20·log ω` (reta) e fase → −π/2 → confirmado no diagrama → mensagem: **da FT ao Bode é só calcular G(jω)**.
- ✔ Coerente com t3.1_v03 (mesmos números).

### t3.1_v06 — "Diagrama de Bode de sistemas de 1ª ordem"
- **Sequência:** `G = K/(s−p₁)`, p₁ < 0 → assíntotas de módulo: `20log|K| − 20log|p₁|` (ω < |p₁|) e reta −20 dB/déc (ω > |p₁|) → **frequência de quebra = |p₁|** → **erro máximo de 3 dB na quebra** (`|G(jp₁)| = |K|/(√2·|p₁|)`) → fase `−arctan(ω/|p₁|)`: assíntotas 0° e −90°, reta de |p₁|/5 a 5·|p₁| passando por −45° na quebra, **tangente à curva exata** → **erro máximo ≈ 0,19 rad ≈ 11°**.
- ✔ **Conferido:** erro de módulo = −3,01 dB; erro de fase da convenção /5–×5 = **11,31° (0,197 rad)** — **a convenção do curso fica assim confirmada** (a fala "meia década" é aproximação retórica do fator 5).
- **⚠ Erratas de transcrição:** "0,07" → **0,707**; "0 para altas frequências" → **0 para baixas**.

### t3.1_v07 — "Diagrama de Bode de sistemas de 2ª ordem com polos reais não-nulos"
- **Sequência:** `G = K/[(s−p₁)(s−p₂)]`, p₁ < p₂ < 0 → **módulo em dB = soma das contribuições** (polos com sinal negativo) → duas quebras: plano → −20 → −40 dB/déc → fase: 0° → −90° → −180°, retas /5–×5 por polo → exemplo gráfico com **p₂ = 100·p₁** (2 décadas) → **erro máximo ≈ 11°**.
- ✔ **Conferido:** com p₂ = 100·p₁, erro máximo de fase da construção /5–×5 = **11,4°**.

### t3.1_v08 — "Diagrama de Bode de sistemas de 2ª ordem do tipo 1"
- **Sequência:** `G = K/[s(s−p₁)]` → a quebra na origem "some" no −∞ do eixo log → **assíntota inicial já é −20 dB/déc** → como posicioná-la: avaliar em ω = |p₁|/10 (`≈ 20log K − 20log ω`) ou, se |p₁| > 1, em ω = 1 (`≈ 20log K`) → após a quebra, −40 dB/déc → **conexão com erro em regime:** tipo 1 → kp = G(0) = ∞ ↔ ganho cresce quando ω → 0; **conclusão do vídeo: assíntota de baixas frequências com inclinação de ao menos −20 dB/déc ⇔ ess = 0 ao degrau** → fase: começa em −90° (integrador) e vai a −180°.
- ✔ Coerente; boa ponte com o M01 (constantes de erro).

### t3.1_v09 — "Definição da margem de fase. Efeito do ajuste do ganho no diagrama de Bode"
- **Sequência:** polos de MF com realimentação unitária: `1+G(s) = 0` ⇔ `G(s) = −1` (módulo 1, fase −180°) → avaliar G(jω) = testar o limiar da estabilidade → **ponto crítico** → definições: **ωc** (|G| = 1 = 0 dB), **ωf** (fase = −180°), **PM = ∠G(jωc)+180° = 77°** no exemplo, **GM = −|G(jωf)|dB = 30 dB** → efeito de multiplicar por K > 0: **módulo translada de 20·log K, fase intacta** → K > 1: ωc ↑, PM ↓ (no exemplo, PM → ~45°); K < 1: o contrário.
- **Números do exemplo:** PM = 77°, GM = 30 dB, PM(K>1) ≈ 45° — **sistema não nomeado na legenda** (aparece só na figura).
- **Consolidação proposta:** recriar a figura com **`G = 0,95/[s(s+1)(s+5)]`** → PM = **77,3°**, GM = **30,0 dB** ✔; com **K = 5** → PM = **44,5°** ✔ (reproduz exatamente os três números do vídeo).

### t3.1_v10 — "Relação da margem de fase em malha aberta com o sobressinal da resposta em malha fechada"
- **Sequência:** `G = ωn²/[s(s+2ξωn)]`, exemplo **ωn = 1, ξ = 0,5** → Bode: **ωc = 0,8 rad/s, PM ≈ 50°** → MF: **Mp ≈ 16 %** ✔ fórmula → **G₂ = 3G**: magnitude sobe 20·log 3 = **9,5 dB** → **PM ≈ 30°** → **Mp ≈ 38 %** (condiz com ξ = 0,3 → 37 %) → **relação exata PM(ξ)** → gráfico PM × ξ ≈ **reta até ξ = 0,65** (erro 5°) → **`PM ≈ 100·ξ`**.
- ✔ **Conferido por simulação:** ωc = 0,786, PM = 51,8°; MF Mp = 16,3 %; 3G: PM = 32,1°, Mp = 38,8 %. Fórmula exata PM(0,5) = 51,8° ✔.

### t3.1_v11 — "Projetando o ganho de controle proporcional com a margem de fase" *(1º projeto do módulo)*
- **Sequência:** com ganho K na malha: ponto crítico vira `G = −1/K` → receita: requisito Mp = 20 % → `ξ = |ln 0,2|/√(π²+ln²0,2) ≈ 0,45` → **PM = 45°** → achar ω onde fase = −135° e fazer **K = 1/|G(jω)|** → **exemplo: `G = 10/[s(s+2)]`**: MF com K=1 tem **Mp ≈ 35 %** ✗ → no Bode, fase = −135° em **ω = 2 rad/s**, onde **|G| ≈ 5 dB = 1,78** → **K = 1/1,78 = 0,56** → novo ωc = 2 rad/s, PM = 45° → **simulado: Mp ≈ 23 %** (erro das aproximações) → **regra prática: adicionar 5–10° à PM desejada** quando o requisito é desigualdade.
- ✔ **Conferido por simulação:** K=1 → Mp = 35,1 %; fase(2) = −135,0°, |G(j2)| = 1,768 (4,95 dB); K = 0,566 → **Mp = 23,3 %** ✔.
- **Uso didático:** é a **solução do 1º Desafio do Jackman** (versão com modelo). Fecha o arco do tópico: projeto de P sem testar em malha fechada.

---

## Tópico 3.2 — Carta de Nichols-Black. Especificação de Desempenho no Domínio da Frequência (8 vídeos)

### t3.2_v01 — "Bode de Sistemas de 2ª ordem subamortecidos"
- **Sequência:** abertura da semana (carta de Nichols-Black virá) → `G = ωn²/(s²+2ξωn s+ωn²)` (ganho unitário em baixas frequências; ganho K só translada) → **pico de ressonância** perto de ωn (exemplo ξ = 0,3, ωn = 1) → **`ωr = ωn√(1−2ξ²)`** (ξ ≤ 0,707) → no exemplo: ωr = √0,82 ≈ **0,9 rad/s** → família de curvas variando ξ: menor ξ → maior pico → **`Mr = 1/(2ξ√(1−ξ²))`** → ponte: Mp ↔ ξ ↔ Mr → gráfico de fase × ω para vários ξ.
- ✔ **Conferido:** ωr = 0,906; Mr = 1,747 (4,85 dB).

### t3.2_v02 — "Bode de malha aberta × Bode de malha fechada: cálculo ponto a ponto?"
- **Sequência:** `T = KG/(1+KG)` → com G(jω) tabelado dá para calcular T ponto a ponto (exemplo **RC, K = 1**: tabela de G e de T) → expressão literal quando se conhece G: `T = K/(sRC+K+1)` → **mas** e se só temos o diagrama medido? → **fórmulas ponto a ponto** (módulo: `|KG|dB − 10·log[(1+|KG|cosφ)² + (|KG|senφ)²]`; fase: `φ_G − arctan[|KG|senφ/(1+|KG|cosφ)]`) → "complicado, não?" → gancho para a carta de Nichols-Black.
- **Deduzido:** as duas fórmulas explícitas (boas para o quadro e para um exercício).

### t3.2_v03 — "A carta de Nichols-Black"
- **Sequência:** definição da carta (fase de MA nas abscissas × módulo de MA nas ordenadas + **lugares geométricos de |T| e ∠T** de MF com realimentação unitária) → perde-se a referência de frequência (marcar pontos) → **exemplo RC, K=1**: quando ∠G = 0° e |G| = 0 dB → **|T| = −6 dB, ∠T = 0°**; quando ∠G → −90° com |G| = −40 dB → **|T| = −40 dB, ∠T = −90°** (T ≈ G quando |G| ≪ 1) → **2º exemplo: `G = 10/[(s+1)(s+10)]`**: (0 dB, 0°) ↔ (−6 dB, 0°) → confronto com os Bodes de G e T.
- ✔ **Conferido:** |T(0)| = −6,02 dB nos dois exemplos.

### t3.2_v04 — "O cruzamento de 0 dB e a PM na Carta de Nichols-Black: efeito do ajuste de ganho"
- **Sequência:** **`G = 100/(s²+4s+29)`** → Bode → curva na carta com frequências marcadas (1, 10, 100 rad/s) → **cruzamento de 0 dB perto de 10 rad/s, fase ≈ −153° → ωc ≈ 10 rad/s, PM ≈ 27°** → **K = 10**: translação de +20 dB na carta → **ωc ≈ 32 rad/s, PM ≈ 7°** → histórico: **papel transparente** para arrastar a curva sobre a carta.
- ✔ **Conferido:** ωc = 10,9 rad/s, PM = 25,9°; K=10: ωc = 31,95 rad/s, PM = 7,3°.
- **⚠ Errata de transcrição:** "100 vezes 10.000" → KG = 1000/(s²+4s+29).

### t3.2_v05 — "Bode e Nichols-Black de 2ª ordem: PM em MA ↔ pico de ressonância em MF; ωc em MA ↔ ωn em MF" *(âncora)*
- **Sequência:** **`G = 2,4/[s(s+1,2)]`** → `T = 2,4/(s²+1,2s+2,4)` → carta: a curva **tangencia o lugar geométrico de 3 dB** → **Mr = 3 dB = 1,41** → `1,41 = 1/(2ξ√(1−ξ²))` → `8ξ⁴ − 8ξ² + 1 = 0` → ξ = 0,38 ou 0,92 (descartada, ξ ≤ 0,7) → **Mp = e^{−π·0,38/√(1−0,38²)} ≈ 0,27** → no zoom: **ωr ≈ ωc ≈ 1,3 rad/s ≈ ωn** → previsão temporal: `tr = (π−arccos 0,38)/(1,3·√(1−0,38²)) ≈ 1,5 s` → **simulação: Mp = 27 % exato; tr = 1,4 s (erro 0,1 s < 7 %)**.
- ✔ **Conferido por simulação:** ωc = 1,336; Mr(MF) = 2,92 dB em ωr = 1,296; MF: **Mp = 26,7 %, tr = 1,38 s**.
- **Nota numérica:** tr previsto = 1,5 s no vídeo; com ωn = ωc = 1,3 dá 1,63 s; com ωn = √2,4 = 1,55 dá 1,37 s. O vídeo usou ωn intermediário (~1,4). No material: apresentar a previsão com ωn ≈ ωc e comparar com o simulado 1,4 s — sem errata, apenas explicitar a cadeia de aproximações.

### t3.2_v06 — "Estender relações de 2ª ordem tipo 1 para qualquer sistema" **★ VÍDEO NOVO V3** *(âncora)*
- **Sequência (parte 1 — 2ª ordem tipo 0):** **`G = 3/[(s+0,02)(s+1)]`** (K = 3, p₁ = −0,02, p₂ = −1) → Bode: **ωc ≈ 1,7 rad/s, fase = −148° → PM = 32°** → fingir que valem as relações do tipo 1: **ξ ≈ 0,32, ωn ≈ 1,7** → **Mp ≈ 0,35, tr ≈ 1,2 s** → **simulado: tr = 1,1 s, Mp ≈ 37 %** ✔ boa aproximação → carta: curva entre os lugares de 3 e 6 dB → admitir **Mr ≈ 5 dB = 1,78** → `12,7ξ⁴ − 12,7ξ² + 1 = 0` → **ξ = 0,3** → **Mp = 0,37** ✔ coerente.
- **Sequência (parte 2 — 3ª ordem):** **`G = 60/[(s+0,02)(s+1)(s+15)]`** (K = 60, p₃ = −15) → Bode: **ωc ≈ 1,8 rad/s, PM = 22°** → **ξ ≈ 0,22, ωn ≈ 1,8** → **Mp ≈ 0,5, tr ≈ 1 s** → **simulado: Mp = 54 %, tr = 1 s** → conclusão: as traduções frequência→tempo **valem com algum cuidado** para 2ª ordem qualquer e mesmo 3ª ordem (precisão limitada).
- ✔ **Conferido por simulação:** tipo 0: ωc = 1,594, PM = 32,8°, MF Mp = 38,1 %/tr = 1,13 s, Mr = 4,96 dB; 3ª ordem: ωc = 1,871, PM = 21,6°, MF **Mp = 54,4 %, tr = 0,97 s**.
- **Consolidação:** este vídeo **oficializa a extensão PM≈100ξ / ωn≈ωc para qualquer sistema** — vira um parágrafo "regra de tradução" na teoria (§ especificações na frequência) e fundamenta os projetos de t3.2_v07/v08.

### t3.2_v07 — "Projeto de sistema de 3ª ordem com requisitos de sobressinal e ganho proporcional" *(âncora de projeto)*
- **Sequência:** mesmo **`G = 60/[(s+0,02)(s+1)(s+15)]`** (Mp = 54 %) → **requisito: Mp < 30 %** → ξ = 0,40 → Mp = 0,25 → **PM = 100·ξ = 40°** → **+5° de segurança → PM = 45°** → no Bode: fase = −135° em **ω = 0,9 rad/s**, onde **|G| = 9,9 dB** → **K = −9,9 dB ≈ 0,32** → previsão: Mp ≈ 25 %; `tr = (π−arccos 0,45)/(0,9·√(1−0,45²)) ≈ 2,5 s` → **simulado: Mp = 25 % exato; tr = 1,9 s** (a estimativa de ωn foi a mais discrepante).
- ✔ **Conferido:** fase(0,9) = −134,1°, |G(j0,9)| = 10,36 dB (vídeo leu 9,9 no gráfico → K = 0,32); com K = 0,32: **Mp = 24,4 %, tr = 1,99 s**.

### t3.2_v08 — "Projeto de sistema com requisitos de ωn e ganho proporcional" *(âncora de projeto)*
- **Sequência:** **`G = 0,005/[(s+0,03)(s+0,1)(s+0,5)]`** (ver errata #5) → com K = 1: **Mp = 17 %, tp = 34 s** → **requisito: tp ≤ 25 s** → `ωd = π/25 ≈ 0,13` → escolher **ωn = 0,13 rad/s** → nessa frequência **PM = 35° → ξ = 0,35** → `ωd = 0,13·√(1−0,35²) ≈ 0,12` (levemente menor que o necessário) → no Bode: **|G(j0,13)| = −7,3 dB** → **K = +7,3 dB ≈ 2,3** → previsão: **Mp = 0,31** → **simulado: tp = 23 s ✔; Mp ≈ 40 % (acima do estimado)** → moral: com 3ª ordem as estimativas pioram; se Mp e tp forem simultâneos e apertados, **ganho puro não basta → compensador** (ponte para as semanas 4–5).
- ✔ **Conferido por simulação:** K=1: **Mp = 17,8 %, tp = 34,2 s**; em ω=0,13: **|G| = −7,09 dB, PM = 36°**; K = 2,3: **Mp = 40,8 %, tp = 23,1 s** — **todos os 6 âncoras confirmados** com `(s+0,1)`.
- **⚠ Errata de transcrição (#5):** `(s+1)` → **`(s+0,1)`**. Com `(s+1)`: MF superamortecido (Mp = 0), |G(j0,13)| = −22,9 dB, PM = 81° — impossível reconciliar com o vídeo.

---

## Tópico 3.3 — Diagrama de Nyquist. Atraso (9 vídeos)

### t3.3_v01 — "O diagrama de Nyquist (resposta em frequência em coordenadas polares)"
- **Sequência:** abertura da 3ª semana (critério de Nyquist; faixas de ganho estáveis) → 3ª representação da resposta em frequência: **diagrama polar** (Re × Im de G(jω)) → fase = ângulo do vetor, módulo = raio → do Bode ao polar é direto → **exemplo `G = 10/[(s+1)(s+10)]`** (módulo sem dB, para ler o raio): ω=0 → ponto (1; 0°); ω=1 → fase ≈ −45°; ω≈3 → |G|≈0,3, −90°; ω=10 → |G|≈0,1, −135°; ω=100 → |G|<0,001, ≈−180° → **converge à origem pela esquerda**.
- ✔ **Conferido:** ω=3 → 0,303/−88,3°; ω=10 → 0,070/−129,3°; ω=100 → 0,001/−173,7° (esboços do vídeo lidos "por cima" — coerentes).

### t3.3_v02 — "O princípio do argumento"
- **Sequência:** base matemática do critério: fase de `G(s) = K(s−z₁)/[(s−p₁)(s−p₂)]` = ∠K + α − β − γ (ângulos dos vetores das raízes ao ponto s) → contorno γ fechado **sem passar por raízes** → raiz fora do contorno: fase volta ao valor inicial sem dar volta → **zero dentro: +360° (volta no mesmo sentido)** → **polo dentro: −360° (sentido oposto)** → **saldo: `N = Z − P`** (N = voltas em torno da origem no sentido do contorno).
- Conceitual puro; ótimo para quadro (desenhar vetores α, β, γ).

### t3.3_v03 — "O contorno de Nyquist e o critério de Nyquist"
- **Sequência:** contorno = eixo imaginário + semicircunferência de raio ∞, **percorrido no sentido horário** → zero em SPD = volta horária, polo = anti-horária → `T = KG/(1+KG)` → polos de MF = zeros de `1+KG` = raízes de `denG + K·numG`; polos de `1+KG` = polos de MA → **`Z = N + P`**: Z = polos de MF no SPD, P = polos de MA no SPD, **N = voltas em torno de −1/K** (horária = +1, anti-horária = −1) → critério: para Z = 0 com P polos instáveis de MA, precisam-se **P voltas anti-horárias** em torno de −1/K.
- **Nota:** o final da transcrição embaralha N/M ("Z = −M + M = 0") — a convenção correta é a do início do vídeo (Z = N+P). Manter uma única notação no material.

### t3.3_v04 — "Análise de Nyquist usando o diagrama obtido a partir do diagrama de Bode"
- **Sequência:** o contorno cobre todo o eixo imaginário → simetria: `G(−jω) = conj(G(jω))` (coeficientes reais) → **traçar ω: 0→∞ e refletir no eixo real** → semicircunferência de raio ∞ (`s = R·e^{jθ}`, θ: +90°→−90°): **estritamente própria** (grau num < grau den) → mapeia na **origem**, convergindo com ângulo `(gnum−gden)·90°`; **própria** (graus iguais) → ponto finito → **exemplo `G = 10/[(s+1)(s+10)]`**: pontos de destaque cor-de-rosa (1∠0°; ~−45°; 0,3∠−90°; 0,1∠−135°; 0∠−180°) → refletir → diagrama completo.
- ✔ Mesmos números de t3.3_v01, conferidos.

### t3.3_v05 — "Esboço do diagrama de Nyquist a partir da Função de Transferência" *(vídeo mais longo; 3 exemplos de estabilidade)*
- **Exemplo 1:** `T = 1/(s−p₁)`, p₁ < 0 → semicírculo no SPE; módulo 1/|p₁| em ω=0, fase 0° → nunca circunda −1/K → **N = 0, P = 0, Z = 0: estável ∀K > 0**.
- **Exemplo 2 (planta instável):** `G = 1/(s−p₁)`, **p₁ > 0** → fase de −180° a −90°, ponto inicial −1/p₁ → **caso A: K > p₁** → −1/K à direita de −1/p₁ → **1 volta anti-horária: N = −1, P = 1, Z = 0 → estável**; **caso B: K < p₁** → N = 0, **Z = 1 → instável** → **moral: planta instável de 1ª ordem exige ganho MÍNIMO**.
- **Exemplo 3:** `G = 1/[s(s−p₁)(s−p₂)]` → **problema: polo na origem está SOBRE o contorno** → solução: **indentação** de raio r→0 (θ: −90°→+90°) → mapeia em **semicircunferência de raio ∞ de +90° a −90°** → **caso A (p₁, p₂ < 0):** fase −90°→−270°, cruza eixo real em **−R** → estável para **0 < K < 1/R** (K < 0: ponto no eixo positivo, 1 volta horária → Z = 1, instável — ver errata #6) → **caso B (p₁, p₂ > 0):** P = 2, fase −450°→−270°, no máximo 1 volta anti-horária → **instável ∀K** (pode haver 1, 2 ou 3 polos de MF no SPD).
- ✔ **Conferido (caso 3A com p₁=−1, p₂=−2):** fase = −180° em ω = √2, |G| = 1/6 → **estável para 0 < K < 6** (= Routh clássico).
- **Fechamento:** programas de computador têm problemas de escala (módulo → 0 ou ∞) — **saber o formato esperado do esboço é essencial para interpretar Nyquist de computador**.

### t3.3_v06 — "A margem de ganho no Diagrama de Nyquist"
- **Sequência:** sistema com zero: **`G = (s−z₁)/[(s−p₁)(s−p₂)]`, z₁ < 0, p₁ < 0, p₂ > 0, |p₁| < |z₁| < |p₂|** → fase inicial −180° (G(0) = −z₁/(p₁p₂) < 0); cai abaixo de −180° após |p₁|, volta a −180° após |z₁|, vai a −90° após |p₂| → **dois cruzamentos do eixo real negativo**: −z₁/(p₁p₂) (em ω=0) e **−R** (a determinar) → **P = 1** → estabilidade exige **N = −1** (1 volta anti-horária): ocorre quando **0 < 1/K < R**, i.e., **K > 1/R — existe limite INFERIOR de ganho** → faixas: `K > 1/R` estável (Z=0); `p₁p₂/z₁ < K < 1/R`: 1 volta horária → Z = 2; `K < p₁p₂/z₁`: N = 0 → Z = 1 → **margens para K fixo na faixa estável: GM superior = ∞; GM inferior = 1/(RK) = −20·log R − 20·log K (dB)**.
- **Consolidação proposta:** o vídeo é todo paramétrico (sem números) → no material, instanciar com um exemplo numérico coerente (ex.: `G = (s+2)/[(s+1)(s−5)]`: G(0) = −0,4; cruzamento −R computado; faixa estável K > 1/R) — a definir na regeneração, mantendo o desenho qualitativo do vídeo.

### t3.3_v07 — "O atraso de transporte, modelagem do atraso usando a função de transferência"
- **Sequência:** atraso puro: `y(t) = u(t−δ)` → Laplace: `Y = e^{−δs}U` → EDO com entrada atrasada → **`G(s) = Gn(s)·e^{−δs}`** → resposta em frequência: **`|e^{−jδω}| = 1`** (módulo inalterado — Euler) e **`∠e^{−jδω} = −δω`** → no Bode, a fase decresce **linearmente com ω** (no eixo log: queda "exponencial", **nunca converge**).
- ✔ Dedução conferida; conecta com o M02 (Padé era a aproximação racional; aqui o atraso é tratado exato na frequência).

### t3.3_v08 — "Efeito do atraso no diagrama de Bode e no desempenho em malha fechada" *(âncora)*
- **Sequência:** **`G = 4/[(s+0,1)(s+1)]·e^{−0,2s}`** → sem atraso: **ωc = 1,9 rad/s, PM = 31°** → ξ ≈ 0,31 → Mp ≈ 0,36, tr ≈ 1 s → **simulado sem atraso: Mp = 0,41, tr = 0,92 s** → com atraso: ωc inalterado (módulo não muda) → **fase cai δωc = 0,2·1,9 ≈ 0,38 rad ≈ 22° → PM ≈ 10°** → ξ ≈ 0,10 → **Mp ≈ 0,73**, tr ≈ 0,88 s → **simulado com atraso: Mp = 0,79, tr = 1,0 s** → resposta muito mais oscilatória; pode levar à **instabilidade** → remédio: reduzir o ganho (ωc ↓ → PM ↑).
- ✔ **Conferido por simulação (Padé ordem 8):** sem atraso: ωc = 1,878, PM = 31,1°, MF **Mp = 41,2 %, tr = 0,95 s**; com atraso: PM ≈ 9,6°, MF **Mp = 78,8 %, tr = 1,05 s** — reproduz o vídeo com precisão.

### t3.3_v09 — "A margem de fase e o efeito do atraso no diagrama de Nyquist" **★ VÍDEO NOVO V3**
- **Sequência:** mesmo sistema `Gn = 4/[(s+0,1)(s+1)]` → Nyquist de Gn: fase 0°→−180°, módulo 40 → 0, **sem cruzamento do eixo real negativo → estável ∀K > 0** → com atraso: fase decresce sem limite enquanto o módulo → 0 → **espiral com infinitas voltas** em torno da origem (metade do diagrama, sem refletir) → onde não havia cruzamentos, **agora há infinitos** → existe K a partir do qual há 1 a ∞ voltas em torno de −1/K → **o sistema que era estável para qualquer ganho é instabilizado para K grande** (e pode ter infinitos polos de MF no SPD) → moral: **o atraso de transporte é uma preocupação central do engenheiro de controle**.
- ✔ Qualitativo conferido (Gn(0) = 40 ✔; Padé 8 reproduz a espiral e a perda de PM).
- **Consolidação:** fecha o arco "atraso" (M02: Padé no plano-s; M03: efeito exato na frequência e em Nyquist) — candidato a figura de capa do tópico.

---

## Tópico 3.4 — Projeto de Controladores no Domínio da Frequência (9 vídeos)

### t3.4_v01 — "Efeito de acrescentar um zero no diagrama de Bode"
- **Sequência:** abertura da 4ª semana (controladores com dinâmica) → `G = Gn(s)(s−z₁)`, z₁ < 0 → módulo: +20log|z₁| em baixas, +20 dB/déc acima de |z₁| → fase: 0° → +90° (reta de **|z₁|/5 a 5|z₁|**, +45° em |z₁|; fórmula da reta: `90·log(5ω/|z₁|)/log 25`) → **adicionar zero aumenta a PM** → **MAS: elemento com zero puro é impróprio → não realizável** (gancho para o polo do próximo vídeo).
- ✔ Convenção /5–×5 reaparece aqui com a fórmula explícita — confirma a leitura da convenção global (ver t3.1_v06).

### t3.4_v02 — "Efeito de acrescentar um polo no diagrama de Bode"
- **Sequência:** `G = Gn(s)/(s−p₁)`, p₁ < 0 → efeito **oposto ao zero**: −20log|p₁| em baixas, −20 dB/déc; fase 0° → −90° (mesma reta /5–×5) → zero e polo na mesma frequência se cancelam ("não há vantagem") → **polo ou par zero-polo é próprio → realizável**.
- ✔ Coerente.

### t3.4_v03 — "Efeito de acrescentar um zero e depois um polo no diagrama de Bode"
- **Sequência:** par `Gn(s)(s−z₁)/(s−p₁)` com **|z₁| < |p₁|** → exemplo com 2 décadas de separação: ganho cai 40 dB em baixas (razão |z₁|/|p₁| = 0,01), sobe +20 dB/déc entre as quebras, **estaciona em 0 dB** → fase sobe até +90° e retorna → **máximo na média geométrica: `ωmáx = √(|z₁|·|p₁|)`** (média aritmética no eixo log) → se zero e polo próximos, o pico < 90° → **nome: avanço de fase; o elemento com ganho = compensador de avanço de fase**.
- ✔ Coerente; a média geométrica é a peça-chave das fórmulas do próximo vídeo.

### t3.4_v04 — "Fórmulas do avanço de fase" *(dedução completa)*
- **Sequência:** parametrização **`Ca(s) = (Ts+1)/(αTs+1)`** (z₁ = −1/T, p₁ = −1/(αT); α < 1 ⇔ zero mais lento) → fase exata `φ = arctan(Tω) − arctan(αTω)` → **`ωmáx = 1/(T√α)`** → substituir e usar tan(a−b) → `tan φmáx = (1/√α − √α)/2` → com cos φmáx = √(1−sen²φmáx) → **`sen φmáx = (1−α)/(1+α)`** → invertendo: **`α = (1−sen φmáx)/(1+sen φmáx)`** → T posiciona ωmáx onde se quer.
- ✔ **Conferido:** com φmáx = 17° → α = 0,548 (vídeo do exemplo seguinte usa 0,54 ✔); com 33° → α = 0,295 ≈ 0,3 ✔.

### t3.4_v05 — "Ajustando ωc e PM com um compensador de avanço de fase" *(a receita)*
- **Sequência (procedimento de 6 passos):** (1) PM e ωc desejados dos requisitos (Mp, tr, tp, ts); (2) verificar a PM do sistema em ωc; (3) **se já for suficiente: só ganho** ("se dá com controlador mais simples, por que complicar?") — excesso de PM é bom (requisitos de Mp são desigualdades); (4) senão: **`φmáx = PMdesejada − ∠G(jωc) − 180°`**, `α = (1−sen φmáx)/(1+sen φmáx)`; (5) **`T = 1/(ωc√α)`** (máximo em ωc); (6) o termo zero-polo introduz ganho `1/√α` em ωc → **`K = √α/|G(jωc)|`**, ou **`KdB = 10·log α − |G(jωc)|dB`**.
- ✔ Fórmula do ganho do compensador em ωmáx = 1/√α conferida algebricamente (|Ca(jωmáx)| = √[(1/α+1)/(α+1)]… = 1/√α).

### t3.4_v06 — "Exemplo de projeto de avanço de fase" **(ÂNCORA PRINCIPAL DO TÓPICO)**
- **Sequência:** **`G = 0,005/[s(s+0,05)]`**; requisitos **tr ≤ 18 s, Mp ≤ 30 %** → **ξ ≥ 0,35, PM > 35°, ωc ≥ 0,11 rad/s** (extremos) → **+5° de folga → PM = 40°** → Bode: em ω = 0,11: **ganho ≈ −9,2 dB, fase ≈ −157° → PM atual = 23°** → impossível só com ganho → **`φmáx = 40 + 157 − 180 = 17°`** → **α = 0,54** → **T = 1/(0,11·√0,54) ≈ 12** → ganho do compensador em ωc: 1/√α = 1,35 → **`KdB = 10·log 0,54 − (−9,2) = −2,7 + 9,2 = 6,5 dB → K = 2,1`** → **`C = 2,1(12s+1)/(6,5s+1)`** → Bodes antes/depois: PM e ωc no alvo → **simulação: Mp = 30 %, tr ≈ 16 s ✔**.
- ✔ **Conferido por simulação:** |G(j0,11)| = −8,49 dB, fase = −155,6° (leituras de gráfico do vídeo: −9,2/−157 — coerentes); compensado: ωc = 0,115, **PM = 40,9°**; MF: **Mp = 29,6 %, tr = 15,5 s**.

### t3.4_v07 — "Ajustando a constante de erro sem alterar (muito) ωc e a PM" *(atraso de fase)*
- **Sequência:** erro em regime ↔ ganho DC; subir o ganho com K destrói ωc/PM → **inverter a ordem do par: |p| < |z|** → ganho sobe `z/p`× abaixo do polo sem mexer nas altas → fase cai entre as quebras → **nome: compensador de atraso de fase** (a fase volta a 0 depois de ~5× a quebra do zero) → **exemplo: `G = 10/[(s+1)(s+2)]`** (tipo 0): kp = 5 → **ess = 1/6 ≈ 16,7 %**; requisito **ess ≤ 10 %** → projeto: reduzir à metade → ess_c = 1/12 ≈ 8,3 % → kpc = 11 → **`z/p = 11/5 = 2,2`** → Bode: **ωc ≈ 2,7 rad/s** → regra **−p ≤ ωc/10 → p = −0,27** → **z = 2,2·0,27 ≈ 0,61** → **`C = (s+0,61)/(s+0,27)`** → Bodes sem/com: ganho alterado só abaixo de ωc, **pequena perda de PM** → **simulação: ess cai à metade ✔; tr: 0,61 → 0,64 s; Mp: 22 % → 23 %**.
- ✔ **Conferido por simulação:** ωc = 2,759; sem C: **ess = 0,167, Mp = 22,1 %, tr = 0,648 s**; com C: **ess = 0,081 (metade ✔), Mp = 22,7 %, tr = 0,665 s**.
- **⚠ Errata de transcrição (#7):** "p = −2,27" → **−0,27** (o próprio z = 0,61 = 2,2·0,276 confirma).

### t3.4_v08 — "Projeto de avanço e atraso, compensando o efeito do atraso" **(ÂNCORA: projeto completo)**
- **Sequência:** **`G = 1/[(s+5)(s+10)]`**; requisitos **Mp < 10 %, tr ≤ 0,1 s, ess ≤ 0,05** → **PM ≥ 59°, ωc ≥ 27 rad/s** (extremos) → em 27 rad/s: **fase = −149° → PM = 31°** → diferença = 28° **+ 5° prevendo a perda do compensador de atraso → φ = 33°** → **α = 0,3** → **T = 1/(27·√0,3) ≈ 0,07** (αT ≈ 0,021) → **`KdB = 10·log 0,3 − (−57,8) = −5,3 + 57,8 = 52,5 dB → K ≈ 420`** → **`C₁ = 420(0,07s+1)/(0,021s+1)`** → kp = 420/50 = **8,4** → **ess = 1/9,4 ≈ 0,11 ✗** → precisa ess = 0,05 = 1/20 → **kp = 19 ≈ dobro** → **p = −ωc/200 ≈ −0,14**, **z = 2p = −0,28** → **`C₂ = (s+0,28)/(s+0,14)`** → **`C = C₁·C₂`** → **simulação: Mp ≈ 10 %, tr ≈ 0,07 s, ess ≈ 5 % ✔ projeto completo**.
- ✔ **Conferido por simulação:** fase(27) = −149,2°, |G(j27)| = −57,96 dB; com C corrigido: **Mp = 7,4 %, tr = 0,075 s, ess = 0,060** (≈5 % — o vídeo diz "aproximadamente 5 %"); com o C₂ literal da transcrição (invertido): **ess = 17,5 %, Mp = 21 %** — erra feio o requisito.
- **⚠ Erratas de transcrição (#8):** "ωc/20" → **ωc/200**; **C₂ está invertido na legenda** — o correto, pela regra enunciada no próprio vídeo (z = 2p) e pela simulação, é **`(s+0,28)/(s+0,14)`**.

### t3.4_v09 — "Visualizando o efeito do avanço e do atraso na carta de Nichols-Black"
- **Sequência:** as 3 curvas do exemplo anterior na carta: **azul (G)**: não cruza 0 dB → MF superamortecido, lento e com erro grande; **verde (C₁·G)**: ωc ≈ 27–30 rad/s, PM ≈ 60° → comportamento de 2ª ordem subamortecido (ξ ≈ 0,6, Mp ≈ 10 %), mas erro em regime inadequado; **vermelha (C₁·C₂·G)**: alteração apenas nas baixas frequências (ganho ↑); perto do cruzamento, **verde e vermelha se unem** → PM e ωc preservados → **síntese visual definitiva: avanço mexe no meio (ωc/PM), atraso mexe em baixas (ganho DC/erro)**.
- ✔ Coerente com os números conferidos de t3.4_v08.

---

## Tópico 3.5 — Controladores PD, PI e PID no Domínio da Frequência (5 vídeos)

### t3.5_v01 — "O controlador PD no domínio da frequência"
- **Sequência:** zero puro já aumenta a fase onde se quer → controlador mais simples que o avanço: **`C = kp + kd·s = kp(1 + (kd/kp)s)`** (PD: termo proporcional + derivada do erro) → projeto: (1) **`φ = arctan(kd·ωc/kp)`** → `kd/kp = tan φ/ωc`, zero `z₁ = kp/kd = ωc/tan φ`; (2) `|C(jωc)| = 1/|G(jωc)|` → desenvolvendo com `1+tan²φ = 1/cos²φ`…: **fórmulas diretas `kp = cos φ/|G(jωc)|` e `kd = sen φ/(ωc·|G(jωc)|)`** → **problema: PD é impróprio** → analogia: **PD = avanço com o polo no ∞** → solução: **polo de filtragem em −P₁, P₁ ≈ 100·ωc** → em ω = P₁/100: módulo ≈ 1, fase ≈ −arctan(0,01) ≈ **−0,6°** → **`C'(s) = kp(1+(kd/kp)s)/(s/P₁+1)`**.
- ✔ Fórmulas conferidas (kp/kd do exemplo seguinte batem); −0,57° ≈ −0,6° ✔.

### t3.5_v02 — "Uma consequência ruim do PD: sinais com variação abrupta" *(âncora: PD × avanço)*
- **Sequência:** **mesmo sistema e requisitos do exemplo de avanço** (`G = 0,005/[s(s+0,05)]`, Mp ≤ 0,3, tr ≤ 18 s → ξ = 0,35, ωc = 0,11, PM = 40°) → |G(jωc)| = 0,35, φ = 17° → **`kp = cos 17°/0,35 = 2,7`**, **`kd = sen 17°/(0,11·0,35) = 7,6`** → **p₁ = 100·ωc = 110** → **`C' = (2,7 + 7,6s)/(s/110 + 1)`** → **simulação: Mp = 30 % exatos, tr = 15 s** (melhor que o necessário) → comparação no mesmo gráfico com o avanço `C = 2,1(12s+1)/(6,5s+1)`: **desempenho quase idêntico** (PD preto × avanço vermelho) → **MAS o sinal de controle**: escalas tão diferentes que precisam de 2 gráficos → derivada do degrau ≈ impulso; mesmo com o polo em 100·ωc, o pico do PD é **muito maior** que o do avanço → sinais de amplitude enorme e duração curta **não são aplicáveis** (atuador) → **moral: usar PD com parcimônia quando a referência muda abruptamente; muitas vezes o avanço vale o trabalho extra**.
- ✔ **Conferido por simulação:** PD: ωc = 0,114, PM = 41,4°, MF **Mp = 29,3 %, tr = 15,1 s**; picos do sinal de controle: **PD = 836 × avanço = 3,9 (≈ 215×)**.
- **⚠ Divergência numérica menor (#10):** o vídeo diz "cerca de 20 vezes maior"; a simulação dá **≈ 215×** no pico inicial (7,6·110 vs 2,1·12/6,5). Manter a mensagem didática com o valor simulado.

### t3.5_v03 — "O controlador PI no domínio da frequência"
- **Sequência:** PD = avanço com polo no ∞ → **PI = atraso com polo em 0** → para **zerar** o erro: ganho DC do controlador → ∞ → `|p₁| = 0` → Bode do controlador: −20 dB/déc até a quebra do zero, plano depois → **`C = (s−z₁)/s`** → com ganho: **`C' = kp(s−z₁)/s = kp − kp·z₁/s = kp + ki/s`** (forma canônica do PI; ki = −kp·z₁) → **único cuidado: `|z₁| = ki/kp` suficientemente menor que ωc** para não comer a PM.
- ✔ Coerente com o PI do M02 (lá no plano-s; aqui a leitura em frequência: PI = atraso limite).

### t3.5_v04 — "O controlador PID no domínio da frequência" **(ÂNCORA: projeto PID)**
- **Sequência:** conjugar PD (transitório) + PI (regime) → **`C = kp(1 + (kd/kp)s)/(s/p₁ + 1) · (s−z₁)/s`** → soma das respostas em frequência; PD dá a PM em ωc, kp acerta o cruzamento, z₁ do PI bem abaixo de ωc → **exemplo: `G = 0,01/[(s+0,05)(s+0,07)]`**; requisitos **Mp ≤ 10 %, tr ≤ 15 s, ess = 0** → **ξ = 0,59, ωc = 0,18 rad/s** → **+5° → PM = 64°** → Bode: em 0,18: **ganho ≈ −11,2 dB (0,275), fase ≈ −144° → PM = 36°** → **φ = 28°** → **`kp = cos 28°/0,275 = 3,2`**, **`kd = sen 28°/(0,18·0,275) = 9,5`** → **p₁ = 100·ωc = 180** → **z₁ = −ωc/10 = −0,018** → **`C = (3,2 + 9,5s)/(s/180 + 1) · (s+0,018)/s`** → **simulação: Mp = 10 % exatos, tr = 12 s, ess = 0 ✔** → "PID é ainda a forma de controle mais usada na indústria".
- ✔ **Conferido por simulação:** |G(j0,18)| = −11,15 dB, fase = −143,2°; compensado: ωc = 0,181, PM = 59,1°; MF: **Mp = 11,2 %, tr = 11,1 s, yss = 1,000**.
- **⚠ Notação (#9):** a legenda escreve "(s − 0,018)/s" — é **`(s+0,018)/s`** (z₁ = −0,018).

### t3.5_v05 — "Visualizando o efeito do PD, do PI e do PID na carta de Nichols-Black"
- **Sequência:** mesmo `G = 0,01/[(s+0,05)(s+0,07)]`: **azul (G)**: ωc ≪ 1 rad/s, PM ≈ 80° → lento; ganho em baixas ≈ 10 dB → erro apreciável → **magenta (PD)**: PM ≈ 63°, pico de ressonância ≈ 0,5 dB, ωc muito mais próximo de 1 → **amarelo (PI)**: PM diminuída, ganho cresce quando ω → 0 → **verde (PID)**: "conjuga os efeitos" — PI + PD: PM levemente menor que a do PD, ganho de baixas infinito.
- ✔ **Conferido:** G: ωc = 0,080, PM = 73,3°, |G(0)| = 9,1 dB; com PD: ωc = 0,181, PM = 64,8°, Mr = 0,19 dB; com PI: PM = 59,8° — todos na casa dos valores lidos no vídeo (leituras de figura).

---

## Consolidação — decisões propostas para a regeneração do Módulo 03

1. **Estrutura do módulo em 5 tópicos** (seguindo a árvore V3, como nos módulos 1 e 2):
   - **T3.1 — Resposta em frequência e diagrama de Bode** (semana 10, aula 10 + lab 10): conceito, dedução `y = |G(jω)|A·sen(ωt+∠G)`, construção do Bode, esboços (1ª, 2ª polos reais, tipo 1), **PM/GM**, efeito do ganho, PM≈100ξ, **projeto de P pela PM** (t3.1_v11 = exemplo principal).
   - **T3.2 — Carta de Nichols-Black e especificações na frequência** (semana 11, aula 11 + lab 11): Bode subamortecido (ωr, Mr), MA→MF, a carta, translação por ganho, **regra de tradução PM↔ξ / ωc↔ωn estendida** (★ V3), projetos de P com requisito de Mp e de tp.
   - **T3.3 — Diagrama de Nyquist e atraso de transporte** (semana 12, aula 12 + lab 12): polar, princípio do argumento, contorno e critério (Z = N+P), esboços (3 exemplos de t3.3_v05), margem de ganho com limite inferior, atraso exato na frequência (Bode + espiral de Nyquist ★ V3).
   - **T3.4 — Projeto de controladores na frequência** (semana 13, aula 13 + lab 13): efeitos zero/polo/par, fórmulas do avanço, receita de 6 passos, **exemplo-âncora avanço** (G = 0,005/[s(s+0,05)]), **atraso** (G = 10/[(s+1)(s+2)]), **avanço+atraso completo** (G = 1/[(s+5)(s+10)]), síntese na carta.
   - **T3.5 — PD, PI e PID na frequência** (semana 14, aula 14 + lab 14): PD (fórmulas diretas, polo em 100ωc), **PD × avanço e o sinal de controle** (âncora), PI como atraso limite, **projeto PID** (G = 0,01/[(s+0,05)(s+0,07)], âncora), síntese na carta.
2. **Correções de conteúdo confirmadas por simulação** (entram no material sem alarde, com nota de rodapé discreta onde didático):
   - t3.2_v08: planta é `0,005/[(s+0,03)(s+0,1)(s+0,5)]` (errata #5).
   - t3.4_v08: `C₂ = (s+0,28)/(s+0,14)` (errata #8).
   - t3.5_v02: razão de picos do sinal de controle ≈ **215×** (não "20×").
3. **Recriações de figuras sem FT na legenda:**
   - t3.1_v09 (PM = 77°, GM = 30 dB): usar **`G = 0,95/[s(s+1)(s+5)]`** (✔ PM = 77,3°, GM = 30,0 dB; K = 5 → PM = 44,5°).
   - t3.3_v06 (margem inferior/superior): instanciar o caso paramétrico com exemplo numérico na mesma geometria (zero entre os dois polos, p₂ > 0).
4. **Convenção de esboço:** adotar oficialmente **retas de fase de ωq/5 a 5·ωq** (erro máx. 11°), explicando que a fala "meia década" dos vídeos se refere a essa construção — mantém coerência com o erro de 0,19 rad citado em t3.1_v06/v07 e com a fórmula explícita de t3.4_v01/v02.
5. **★ Vídeos novos V3 incorporados como conteúdo central** (não apêndice): t3.2_v06 vira o **parágrafo "extensão das traduções frequência↔tempo"** da teoria (com as duas simulações-âncora); t3.3_v09 vira o **fechamento do T3.3** (espiral + instabilização por ganho alto).
6. **Labs (5, semanas 10–14):** lab 10 = resposta em frequência experimental + Bode + PM + projeto de P (t3.1_v11); lab 11 = carta de Nichols-Black + Mr + projetos de t3.2_v07/v08; lab 12 = Nyquist (esboços × `ct.nyquist_plot`, escalas!) + atraso (Padé alta ordem, espiral); lab 13 = projeto avanço + atraso completo (os 3 exemplos de T3.4); lab 14 = PD/PI/PID + sinal de controle (PD × avanço) + carta final.
7. **Sem referências a vídeos nos materiais dos alunos** (regra global); mapa vídeo↔conteúdo só nas notas de aula do professor.
